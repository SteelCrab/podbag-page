//! Single choice: a segmented control (theme picker) and plain radio buttons.

use winit::window::CursorIcon;

use crate::geom::Rect;
use crate::scene::Id;
use crate::ui::Ui;

/// Segments with an optional icon each, filling `rect`. Returns the clicked index.
pub fn segmented(ui: &mut Ui, id: Id, rect: Rect, options: &[(Option<u16>, &str)], selected: usize) -> Option<usize> {
    let t = ui.theme;
    ui.p.bordered(rect, 8., t.sunken, 1., t.line);
    let n = options.len().max(1) as f32;
    let w = (rect.w - 4.) / n;
    let mut out = None;
    for (i, (icon, label)) in options.iter().enumerate() {
        let r = Rect::new(rect.x + 2. + i as f32 * w, rect.y + 2., w, rect.h - 4.);
        let sid = id.with(i);
        let on = i == selected;
        if on {
            ui.p.shadow(r, 6., 2., t.shadow);
            ui.p.rounded(r, 6., t.surface);
        } else if ui.hovered(sid) {
            ui.p.rounded(r, 6., t.hover);
        }
        let style = ui.style().with_size(13.).weight(if on { 600 } else { 500 });
        let text = ui.text(label, style);
        let icon_w = if icon.is_some() { 21. } else { 0. };
        let x = r.x + ((r.w - icon_w - text.width) / 2.).max(4.);
        let fg = if on { t.ink } else { t.ink2 };
        if let Some(icon) = icon {
            ui.p.icon(*icon, Rect::new(x, r.y + (r.h - 15.) / 2., 15., 15.), fg);
        }
        ui.p.label(Rect::new(x + icon_w, r.y, r.right() - x - icon_w, r.h), label, style, fg);
        ui.p.hitbox(r, sid, CursorIcon::Pointer);
        if ui.clicked(sid) && !on {
            out = Some(i);
        }
    }
    out
}

/// A radio button with a label at the left of `rect`. Returns true when chosen.
pub fn radio(ui: &mut Ui, id: Id, rect: Rect, on: bool, label: &str) -> bool {
    let t = ui.theme;
    let b = Rect::new(rect.x, rect.y + (rect.h - 16.) / 2., 16., 16.);
    if on {
        ui.p.rounded(b, 8., t.accent);
        ui.p.rounded(b.center(6., 6.), 3., t.accent_ink);
    } else {
        ui.p.bordered(b, 8., t.surface, 1., t.muted);
    }
    let style = ui.style();
    let w = ui.text(label, style).width;
    ui.p.label(Rect::new(b.right() + 7., rect.y, rect.w - 23., rect.h), label, style, t.ink);
    ui.p.hitbox(Rect::new(rect.x, rect.y, 23. + w, rect.h), id, CursorIcon::Pointer);
    ui.clicked(id) && !on
}
