//! A log view: many monospace lines in a virtual list that can follow the end.

use crate::geom::Rect;
use crate::scene::Id;
use crate::text::TextStyle;
use crate::ui::Ui;
use crate::virtual_list::VirtualList;

const LINE_H: f32 = 19.;
const KEEP: usize = 5000;

pub struct LogView {
    pub lines: Vec<String>,
    pub follow: bool,
    list: VirtualList,
    new_lines: bool,
}

impl Default for LogView {
    fn default() -> Self {
        Self { lines: Vec::new(), follow: true, list: VirtualList::new(LINE_H, LINE_H), new_lines: false }
    }
}

impl LogView {
    /// Append lines; keeps the last 5000 once over 6000.
    pub fn push(&mut self, lines: impl IntoIterator<Item = String>) {
        self.lines.extend(lines);
        if self.lines.len() > KEEP + 1000 {
            let cut = self.lines.len() - KEEP;
            self.lines.drain(..cut);
        }
        self.new_lines = true;
    }

    pub fn clear(&mut self) {
        self.lines.clear();
        self.list.set_offset(0.);
    }
}

/// Paints the lines in a bordered box; `empty` shows while there are none.
pub fn log_view(ui: &mut Ui, id: Id, rect: Rect, view: &mut LogView, empty: &str) {
    let t = ui.theme;
    ui.p.bordered(rect, 8., t.surface, 1., t.line);
    let inner = rect.inset(14., 12., 14., 12.);
    let style = TextStyle::new(12.5).mono().line_height(LINE_H);
    if view.lines.is_empty() {
        ui.p.label(inner.with_h(LINE_H), empty, style, t.ink2);
        return;
    }
    let dy = ui.take_scroll(id, LINE_H * 3.);
    if dy != 0. {
        view.list.scroll_px(dy);
    }
    view.list.layout(inner, view.lines.len());
    if view.follow && view.new_lines {
        view.list.scroll_to_end();
    }
    view.new_lines = false;
    ui.p.scroll_region(rect, id);
    let range = view.list.visible();
    ui.clip(inner, |ui| {
        for i in range {
            let r = view.list.row_rect(i);
            ui.p.label(r, &view.lines[i], style, t.ink);
        }
    });
}

/// Scroll to the end now (e.g. when "follow" is turned on).
pub fn follow_now(view: &mut LogView) {
    view.list.scroll_to_end();
}
