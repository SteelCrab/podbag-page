//! A drop-down select: a button showing the choice, and a menu on the popup layer.

use winit::window::CursorIcon;

use crate::geom::Rect;
use crate::icons;
use crate::scene::{Id, layer};
use crate::ui::Ui;

pub enum Item<'a> {
    Option(&'a str),
    /// A group heading (not choosable).
    Group(&'a str),
}

const ITEM_H: f32 = 28.;

/// Returns the index of the chosen item (options and groups count alike).
pub fn select(ui: &mut Ui, id: Id, rect: Rect, items: &[Item], selected: usize, enabled: bool) -> Option<usize> {
    let t = ui.theme;
    let open = ui.popup_open(id);
    let hovered = enabled && ui.hovered(id);
    let border = if open { t.accent } else { t.line };
    ui.p.bordered(rect, 7., if hovered { t.hover } else { t.surface }, 1., border);
    let current = match items.get(selected) {
        Some(Item::Option(s)) => *s,
        _ => "",
    };
    let style = ui.style();
    let fg = if enabled { t.ink } else { t.ink.with_alpha(0.45) };
    ui.p.label(rect.inset(10., 0., 30., 0.), current, style, fg);
    ui.p.icon(icons::CHEVRON_DOWN, Rect::new(rect.right() - 24., rect.y + (rect.h - 14.) / 2., 14., 14.), t.muted);
    if !enabled {
        return None;
    }
    ui.p.hitbox(rect, id, CursorIcon::Pointer);
    if ui.clicked(id) {
        ui.open_popup(if open { None } else { Some(id) });
        return None;
    }
    if !open {
        return None;
    }
    // The menu, below the button (or above it when there is no room).
    let h = items.len() as f32 * ITEM_H + 8.;
    let bounds = ui.bounds();
    let w = rect.w.max(160.);
    let mut menu = Rect::new(rect.x.min(bounds.right() - w - 8.), rect.bottom() + 4., w, h.min(bounds.h - 16.));
    if menu.bottom() > bounds.bottom() - 8. {
        menu.y = (rect.y - 4. - menu.h).max(8.);
    }
    let popup_layer = if ui.p.current_layer() >= layer::MODAL { layer::MODAL_POPUP } else { layer::POPUP };
    let mut chosen = None;
    ui.p.on_layer(popup_layer, |p| {
        p.shadow(menu, 9., 14., t.shadow);
        p.bordered(menu, 9., t.surface, 1., t.line);
        p.hitbox(menu, id.with("menu"), CursorIcon::Default);
    });
    ui.popup_hitbox(id.with("menu"));
    for (i, item) in items.iter().enumerate() {
        let r = Rect::new(menu.x + 4., menu.y + 4. + i as f32 * ITEM_H, menu.w - 8., ITEM_H);
        let iid = id.with(("item", i));
        let hovered = ui.hovered(iid);
        ui.popup_hitbox(iid);
        let clicked = match item {
            Item::Group(label) => {
                let s = style.with_size(11.5).weight(600);
                ui.p.on_layer(popup_layer, |p| {
                    p.label(r.inset(8., 0., 8., 0.), label, s, t.muted);
                });
                false
            }
            Item::Option(label) => {
                ui.p.on_layer(popup_layer, |p| {
                    if hovered {
                        p.rounded(r, 6., t.accent_soft);
                    }
                    let fg = if hovered { t.accent_text } else { t.ink };
                    p.label(r.inset(26., 0., 8., 0.), label, style, fg);
                    if i == selected {
                        p.icon(icons::CHECK, Rect::new(r.x + 7., r.y + (r.h - 13.) / 2., 13., 13.), t.accent_text);
                    }
                    p.hitbox(r, iid, CursorIcon::Pointer);
                });
                ui.clicked(iid)
            }
        };
        if clicked {
            chosen = Some(i);
        }
    }
    if chosen.is_some() {
        ui.open_popup(None);
    }
    chosen
}
