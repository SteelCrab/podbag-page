//! Window, event loop and event dispatch (winit).
//!
//! Redraws happen only on demand (`ControlFlow::Wait`): after an event that called
//! `Cx::notify`, when the hovered hitbox changes, on resize, for timers the view asked
//! for, or for frame callbacks.

use std::sync::{Arc, OnceLock};
use std::thread::JoinHandle;
use std::time::Instant;

use winit::application::ApplicationHandler;
use winit::dpi::{LogicalPosition, LogicalSize};
use winit::event::{ElementState, Ime, KeyEvent, MouseButton, MouseScrollDelta, StartCause, WindowEvent};
use winit::event_loop::{ActiveEventLoop, ControlFlow, EventLoop, EventLoopProxy};
use winit::keyboard::ModifiersState;
use winit::window::{CursorIcon, Theme, Window, WindowId};

use crate::geom::{Color, Point, Rect};
use crate::gpu::Gpu;
use crate::scene::{FrameCallback, Id, Paint, Scene};
use crate::text::{Fonts, TextSystem, load_fonts};

static START: OnceLock<Instant> = OnceLock::new();

/// Milliseconds since the app started (for debug logs).
pub fn since_start() -> f64 {
    START.get().map_or(0., |s| s.elapsed().as_secs_f64() * 1e3)
}

#[derive(Clone, Copy, Debug)]
pub enum ScrollDelta {
    /// Vertical lines, from a classic mouse wheel.
    Lines(f32),
    /// Vertical logical pixels, from a trackpad.
    Pixels(f32),
}

pub enum Event<'a, M> {
    PointerDown { pos: Point, hit: Option<Id>, shift: bool },
    PointerUp { pos: Point, hit: Option<Id> },
    PointerMove { pos: Point },
    /// `target`: the topmost scroll region under the pointer.
    Scroll { pos: Point, delta: ScrollDelta, target: Option<Id> },
    Key { event: &'a KeyEvent, mods: ModifiersState },
    Ime(&'a Ime),
    Message(M),
    /// A time asked for with `wake_at` was reached.
    Timer,
}

/// The letter of a shortcut such as Cmd+A. Non-Latin layouts (e.g. Korean) report
/// their own letter as the logical key, so fall back to the physical key then.
pub fn shortcut_letter(event: &KeyEvent) -> Option<char> {
    use winit::keyboard::{Key, KeyCode, PhysicalKey};
    if let Key::Character(s) = &event.logical_key
        && let Some(c) = s.chars().next().filter(|c| c.is_ascii_alphabetic())
    {
        return Some(c.to_ascii_lowercase());
    }
    use KeyCode::*;
    const KEYS: [KeyCode; 26] = [
        KeyA, KeyB, KeyC, KeyD, KeyE, KeyF, KeyG, KeyH, KeyI, KeyJ, KeyK, KeyL, KeyM, KeyN, KeyO,
        KeyP, KeyQ, KeyR, KeyS, KeyT, KeyU, KeyV, KeyW, KeyX, KeyY, KeyZ,
    ];
    let PhysicalKey::Code(code) = event.physical_key else { return None };
    KEYS.iter().position(|k| *k == code).map(|i| (b'a' + i as u8) as char)
}

/// The platform's shortcut modifier: Cmd on macOS, Ctrl elsewhere.
pub fn shortcut_modifier(mods: ModifiersState) -> bool {
    if cfg!(target_os = "macos") { mods.super_key() } else { mods.control_key() }
}

/// A screen: paints itself and reacts to events.
pub trait View: 'static {
    type Message: Send + 'static;
    fn paint(&mut self, p: &mut Paint);
    fn event(&mut self, event: Event<'_, Self::Message>, cx: &mut Cx);
    /// Repaint when the hovered hitbox changes after a frame (for views that style
    /// hover by hitbox id rather than by pointer position).
    fn repaint_on_hover_change(&self) -> bool {
        false
    }
    /// The color behind everything.
    fn background(&self) -> Color {
        Color { r: 1., g: 1., b: 1., a: 1. }
    }
}

/// The system clipboard, opened on first use.
#[derive(Default)]
pub struct Clipboard(Option<arboard::Clipboard>);

impl Clipboard {
    pub fn read(&mut self) -> Option<String> {
        self.open().and_then(|c| c.get_text().ok())
    }

    pub fn write(&mut self, text: String) {
        if let Some(c) = self.open() {
            let _ = c.set_text(text);
        }
    }

    fn open(&mut self) -> Option<&mut arboard::Clipboard> {
        if self.0.is_none() {
            self.0 = arboard::Clipboard::new().ok();
        }
        self.0.as_mut()
    }
}

/// Context passed with events.
pub struct Cx<'a> {
    redraw: bool,
    quit: bool,
    focus: &'a mut Option<Id>,
    clipboard: &'a mut Clipboard,
    wake_at: &'a mut Option<Instant>,
}

impl Cx<'_> {
    /// Request a redraw.
    pub fn notify(&mut self) {
        self.redraw = true;
    }

    pub fn quit(&mut self) {
        self.quit = true;
    }

    pub fn focused(&self) -> Option<Id> {
        *self.focus
    }

    /// Focus a text widget. The IME is enabled while something has focus.
    pub fn focus(&mut self, id: Option<Id>) {
        if *self.focus != id {
            *self.focus = id;
            self.redraw = true;
        }
    }

    pub fn clipboard(&mut self) -> &mut Clipboard {
        self.clipboard
    }

    /// Get an `Event::Timer` no later than `at`.
    pub fn wake_at(&mut self, at: Instant) {
        if self.wake_at.is_none_or(|w| at < w) {
            *self.wake_at = Some(at);
        }
    }
}

pub struct WindowOptions {
    pub title: String,
    pub width: f64,
    pub height: f64,
    pub min_size: Option<(f64, f64)>,
    pub focus: Option<Id>,
    /// Timing and frame logs on stderr.
    pub debug: bool,
}

/// Input made up by the app itself, for automated UI checks: it goes through the same
/// hit testing and dispatch as real input, without moving the system's pointer.
#[derive(Clone, Debug)]
pub enum Synthetic {
    Move(Point),
    Click(Point),
    Scroll(Point, f32),
    /// Committed text, as an IME commit.
    Text(String),
}

pub enum UserEvent<M> {
    Message(M),
    Synthetic(Synthetic),
}

pub struct Proxy<M: 'static>(EventLoopProxy<UserEvent<M>>);

impl<M: 'static> Clone for Proxy<M> {
    fn clone(&self) -> Self {
        Proxy(self.0.clone())
    }
}

impl<M: 'static> Proxy<M> {
    /// Send a message to the view (wakes the loop). False once the loop is gone.
    pub fn send(&self, m: M) -> bool {
        self.0.send_event(UserEvent::Message(m)).is_ok()
    }

    /// Feed synthetic input (UI tests).
    pub fn synthetic(&self, s: Synthetic) -> bool {
        self.0.send_event(UserEvent::Synthetic(s)).is_ok()
    }
}

pub struct App<M: 'static> {
    event_loop: EventLoop<UserEvent<M>>,
    fonts: JoinHandle<Fonts>,
}

impl<M: Send + 'static> App<M> {
    /// Starts loading fonts on a thread right away, in parallel with window and GPU setup.
    pub fn new() -> Self {
        START.get_or_init(Instant::now);
        let fonts = std::thread::spawn(load_fonts);
        let event_loop = EventLoop::with_user_event().build().expect("event loop");
        Self { event_loop, fonts }
    }

    pub fn proxy(&self) -> Proxy<M> {
        Proxy(self.event_loop.create_proxy())
    }

    pub fn run<V: View<Message = M>>(self, opts: WindowOptions, build: impl FnOnce() -> V) {
        self.event_loop.set_control_flow(ControlFlow::Wait);
        let mut runner = Runner { opts, build: Some(build), fonts: Some(self.fonts), live: None };
        self.event_loop.run_app(&mut runner).expect("event loop");
    }
}

impl<M: Send + 'static> Default for App<M> {
    fn default() -> Self {
        Self::new()
    }
}

struct Runner<V, B> {
    opts: WindowOptions,
    build: Option<B>,
    fonts: Option<JoinHandle<Fonts>>,
    live: Option<Live<V>>,
}

struct Live<V> {
    view: V,
    gpu: Gpu,
    text: TextSystem,
    scene: Scene,
    scale: f32,
    pointer: Option<Point>,
    mods: ModifiersState,
    focus: Option<Id>,
    ime_allowed: bool,
    ime_area: Option<Rect>,
    hover: Option<Id>,
    hover_layer: usize,
    cursor: CursorIcon,
    dirty: bool,
    wake_at: Option<Instant>,
    dark: bool,
    /// Callbacks registered while painting the frame being presented.
    after_present: Vec<FrameCallback>,
    /// Callbacks to run when the next frame begins.
    at_frame_start: Vec<FrameCallback>,
    clipboard: Clipboard,
    debug: bool,
    // Last, so it is dropped after the GPU surface.
    window: Arc<Window>,
}

impl<V: View, B: FnOnce() -> V> ApplicationHandler<UserEvent<V::Message>> for Runner<V, B> {
    fn resumed(&mut self, el: &ActiveEventLoop) {
        if self.live.is_some() {
            return;
        }
        let t = Instant::now();
        if self.opts.debug {
            eprintln!("{:.1} ms: resumed", since_start());
        }
        let mut attrs = Window::default_attributes()
            .with_title(self.opts.title.clone())
            .with_inner_size(LogicalSize::new(self.opts.width, self.opts.height));
        if let Some((w, h)) = self.opts.min_size {
            attrs = attrs.with_min_inner_size(LogicalSize::new(w, h));
        }
        if let Some(m) = el.primary_monitor() {
            // Center on the primary monitor, like GPUI's Bounds::centered.
            let s = m.scale_factor();
            let (mw, mh) = (m.size().width as f64 / s, m.size().height as f64 / s);
            let (mx, my) = (m.position().x as f64 / s, m.position().y as f64 / s);
            let pos = LogicalPosition::new(mx + (mw - self.opts.width) / 2., my + (mh - self.opts.height) / 2.);
            attrs = attrs.with_position(pos);
        }
        let window = Arc::new(el.create_window(attrs).expect("create window"));
        let t_window = t.elapsed();
        let gpu = Gpu::new(window.clone(), el.owned_display_handle());
        let t_gpu = t.elapsed();
        let fonts = self.fonts.take().unwrap().join().expect("font thread");
        let debug = self.opts.debug;
        if debug {
            eprintln!(
                "{:.1} ms: window {:.1} ms, gpu {:.1} ms ({}), fonts {:.1} ms on a thread: {} faces, family {:?}, {}; waited {:.1} ms",
                since_start(),
                t_window.as_secs_f64() * 1e3,
                (t_gpu - t_window).as_secs_f64() * 1e3,
                gpu.adapter_info,
                fonts.load_ms,
                fonts.faces,
                fonts.family,
                fonts.strategy,
                (t.elapsed() - t_gpu).as_secs_f64() * 1e3,
            );
        }
        let text = TextSystem::new(fonts);
        let view = (self.build.take().unwrap())();
        let focus = self.opts.focus;
        window.set_ime_allowed(focus.is_some());
        window.request_redraw();
        self.live = Some(Live {
            view,
            gpu,
            text,
            scene: Scene::default(),
            scale: window.scale_factor() as f32,
            pointer: None,
            mods: ModifiersState::empty(),
            focus,
            ime_allowed: focus.is_some(),
            ime_area: None,
            hover: None,
            hover_layer: 0,
            cursor: CursorIcon::Default,
            dirty: true,
            wake_at: None,
            dark: window.theme() == Some(Theme::Dark),
            after_present: Vec::new(),
            at_frame_start: Vec::new(),
            clipboard: Clipboard::default(),
            debug,
            window,
        });
    }

    fn new_events(&mut self, el: &ActiveEventLoop, cause: StartCause) {
        if let (StartCause::ResumeTimeReached { .. }, Some(live)) = (cause, &mut self.live)
            && live.wake_at.is_some_and(|w| w <= Instant::now())
        {
            live.wake_at = None;
            live.dispatch(el, Event::Timer);
        }
    }

    fn about_to_wait(&mut self, el: &ActiveEventLoop) {
        let flow = match self.live.as_ref().and_then(|l| l.wake_at) {
            Some(at) => ControlFlow::WaitUntil(at),
            None => ControlFlow::Wait,
        };
        el.set_control_flow(flow);
    }

    fn user_event(&mut self, el: &ActiveEventLoop, ev: UserEvent<V::Message>) {
        let Some(live) = &mut self.live else { return };
        match ev {
            UserEvent::Message(m) => live.dispatch(el, Event::Message(m)),
            UserEvent::Synthetic(s) => live.synthetic(el, s),
        }
    }

    fn window_event(&mut self, el: &ActiveEventLoop, _: WindowId, event: WindowEvent) {
        let Some(live) = &mut self.live else { return };
        match event {
            WindowEvent::CloseRequested => el.exit(),
            WindowEvent::Resized(size) => {
                live.gpu.resize(size.width, size.height);
                live.invalidate();
            }
            WindowEvent::ScaleFactorChanged { scale_factor, .. } => {
                live.scale = scale_factor as f32;
                live.invalidate();
            }
            WindowEvent::ThemeChanged(theme) => {
                live.dark = theme == Theme::Dark;
                live.invalidate();
            }
            WindowEvent::Occluded(false) if live.dirty => live.window.request_redraw(),
            WindowEvent::RedrawRequested => live.frame(el),
            WindowEvent::ModifiersChanged(m) => live.mods = m.state(),
            WindowEvent::CursorMoved { position, .. } => {
                let pos = Point { x: position.x as f32 / live.scale, y: position.y as f32 / live.scale };
                live.pointer = Some(pos);
                live.update_hover();
                live.dispatch(el, Event::PointerMove { pos });
            }
            WindowEvent::CursorLeft { .. } => {
                live.pointer = None;
                live.update_hover();
            }
            WindowEvent::MouseInput { state, button: MouseButton::Left, .. } => {
                let Some(pos) = live.pointer else { return };
                let hit = live.scene.hit(pos).map(|h| h.id);
                let ev = match state {
                    ElementState::Pressed => Event::PointerDown { pos, hit, shift: live.mods.shift_key() },
                    ElementState::Released => Event::PointerUp { pos, hit },
                };
                live.dispatch(el, ev);
            }
            WindowEvent::MouseWheel { delta, .. } => {
                let Some(pos) = live.pointer else { return };
                let delta = match delta {
                    MouseScrollDelta::LineDelta(_, y) => ScrollDelta::Lines(y),
                    MouseScrollDelta::PixelDelta(p) => ScrollDelta::Pixels(p.y as f32 / live.scale),
                };
                let target = live.scene.scroller(pos).map(|h| h.id);
                live.dispatch(el, Event::Scroll { pos, delta, target });
            }
            WindowEvent::KeyboardInput { event, .. } if event.state == ElementState::Pressed => {
                let mods = live.mods;
                live.dispatch(el, Event::Key { event: &event, mods });
            }
            WindowEvent::Ime(ime) => live.dispatch(el, Event::Ime(&ime)),
            _ => {}
        }
    }
}

impl<V: View> Live<V> {
    fn invalidate(&mut self) {
        self.dirty = true;
        self.window.request_redraw();
    }

    fn dispatch(&mut self, el: &ActiveEventLoop, ev: Event<'_, V::Message>) {
        let mut cx = Cx {
            redraw: false,
            quit: false,
            focus: &mut self.focus,
            clipboard: &mut self.clipboard,
            wake_at: &mut self.wake_at,
        };
        self.view.event(ev, &mut cx);
        let (redraw, quit) = (cx.redraw, cx.quit);
        self.sync_ime();
        if redraw {
            self.invalidate();
        }
        if quit {
            el.exit();
        }
    }

    fn synthetic(&mut self, el: &ActiveEventLoop, s: Synthetic) {
        match s {
            Synthetic::Move(pos) => {
                self.pointer = Some(pos);
                self.update_hover();
                self.dispatch(el, Event::PointerMove { pos });
            }
            Synthetic::Click(pos) => {
                self.pointer = Some(pos);
                self.update_hover();
                let hit = self.scene.hit(pos).map(|h| h.id);
                self.dispatch(el, Event::PointerDown { pos, hit, shift: false });
                self.dispatch(el, Event::PointerUp { pos, hit });
            }
            Synthetic::Scroll(pos, dy) => {
                let target = self.scene.scroller(pos).map(|h| h.id);
                self.dispatch(el, Event::Scroll { pos, delta: ScrollDelta::Pixels(dy), target });
            }
            Synthetic::Text(text) => self.dispatch(el, Event::Ime(&Ime::Commit(text))),
        }
    }

    fn sync_ime(&mut self) {
        let allow = self.focus.is_some();
        if allow != self.ime_allowed {
            self.ime_allowed = allow;
            self.window.set_ime_allowed(allow);
        }
    }

    /// Redraw when the topmost hitbox under the pointer changes; update the cursor.
    fn update_hover(&mut self) {
        let hit = self.pointer.and_then(|p| self.scene.hit(p));
        self.hover_layer = hit.map_or(0, |h| h.layer);
        let (id, cursor) = hit.map_or((None, CursorIcon::Default), |h| (Some(h.id), h.cursor));
        if cursor != self.cursor {
            self.cursor = cursor;
            self.window.set_cursor(cursor);
        }
        if id != self.hover {
            self.hover = id;
            self.invalidate();
        }
    }

    fn frame(&mut self, el: &ActiveEventLoop) {
        if self.debug && !self.at_frame_start.is_empty() {
            eprintln!("{:.1} ms: frame callbacks", since_start());
        }
        for f in self.at_frame_start.drain(..) {
            f();
        }
        if !self.dirty {
            return;
        }
        // Occluded windows get no surface texture (wgpu on macOS); Occluded(false) retries.
        let target = match self.gpu.acquire() {
            Ok(t) => t,
            Err(retry) => {
                if self.debug {
                    eprintln!("{:.1} ms: no surface texture (retry {retry})", since_start());
                }
                if retry {
                    self.window.request_redraw();
                }
                return;
            }
        };
        let t = Instant::now();
        let size = self.window.inner_size();
        let bounds = Rect::new(0., 0., size.width as f32 / self.scale, size.height as f32 / self.scale);
        self.scene.clear();
        let mut p = Paint {
            scene: &mut self.scene,
            text: &mut self.text,
            bounds,
            pointer: self.pointer,
            hover: self.hover,
            hover_layer: self.hover_layer,
            focus: &mut self.focus,
            clip: bounds,
            layer: 0,
            next_frame: &mut self.after_present,
            ime_area: None,
            clipboard: &mut self.clipboard,
            repaint: false,
            quit: false,
            wake_at: &mut self.wake_at,
            scale: self.scale,
            dark: self.dark,
        };
        self.view.paint(&mut p);
        let (ime_area, repaint, quit) = (p.ime_area, p.repaint, p.quit);
        let t_paint = t.elapsed();
        let clear = self.view.background();
        self.gpu.render(target, &self.scene, &mut self.text.fonts, self.scale, clear, &self.window);
        self.dirty = false;
        self.text.end_frame();
        self.sync_ime();
        if ime_area != self.ime_area {
            self.ime_area = ime_area;
            if let Some(r) = ime_area {
                self.window.set_ime_cursor_area(LogicalPosition::new(r.x, r.y), LogicalSize::new(r.w, r.h));
            }
        }
        // Content moved under a still pointer (scrolling, new layers): keep hover in sync.
        let hit = self.pointer.and_then(|p| self.scene.hit(p));
        self.hover_layer = hit.map_or(0, |h| h.layer);
        let (id, cursor) = hit.map_or((None, CursorIcon::Default), |h| (Some(h.id), h.cursor));
        if cursor != self.cursor {
            self.cursor = cursor;
            self.window.set_cursor(cursor);
        }
        let hover_changed = id != self.hover;
        self.hover = id;
        if !self.after_present.is_empty() {
            self.at_frame_start.append(&mut self.after_present);
            self.window.request_redraw();
        }
        if repaint || (hover_changed && self.view.repaint_on_hover_change()) {
            self.invalidate();
        }
        if quit {
            el.exit();
        }
        if self.debug {
            eprintln!(
                "{:.1} ms: frame: paint {:.2} ms, render {:.2} ms, {} quads, {} texts",
                since_start(),
                t_paint.as_secs_f64() * 1e3,
                (t.elapsed() - t_paint).as_secs_f64() * 1e3,
                self.scene.layers.iter().map(|l| l.quads.len() + l.overlay.len()).sum::<usize>(),
                self.scene.layers.iter().map(|l| l.texts.len()).sum::<usize>()
            );
        }
    }
}
