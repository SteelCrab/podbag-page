//! Fonts, text shaping and a per-frame layout cache (cosmic-text through glyphon).

use std::collections::HashMap;
use std::path::PathBuf;
use std::rc::Rc;
use std::time::Instant;

use glyphon::cosmic_text::{Ellipsize, EllipsizeHeightLimit};
use glyphon::cosmic_text::{Fallback, PlatformFallback};
use glyphon::{Attrs, Buffer, Cursor, Family, FontSystem, Metrics, Shaping, Weight, Wrap, fontdb};
use unicode_script::Script;

/// GPUI's default line height is 1.618 x font size. Same here, so boxes line up.
pub const LINE_HEIGHT: f32 = 1.618;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TextStyle {
    pub size: f32,
    pub weight: u16,
    /// Line box height in logical px.
    pub line_height: f32,
    pub mono: bool,
}

impl TextStyle {
    pub fn new(size: f32) -> Self {
        Self { size, weight: 400, line_height: size * LINE_HEIGHT, mono: false }
    }

    pub fn weight(mut self, w: u16) -> Self {
        self.weight = w;
        self
    }

    pub fn line_height(mut self, h: f32) -> Self {
        self.line_height = h;
        self
    }

    /// Another size, keeping the line height ratio.
    pub fn with_size(mut self, size: f32) -> Self {
        self.line_height = (self.line_height / self.size * size).round();
        self.size = size;
        self
    }

    pub fn mono(mut self) -> Self {
        self.mono = true;
        self
    }
}

/// Shaped text. Cheap to clone.
#[derive(Clone)]
pub struct TextLayout {
    pub buffer: Rc<Buffer>,
    /// Width of the widest line.
    pub width: f32,
    /// Height of all lines.
    pub height: f32,
    /// Baseline offset of the first line from the top.
    pub baseline: f32,
}

impl TextLayout {
    /// X offset of a byte index (first line).
    pub fn x_for_index(&self, index: usize) -> f32 {
        let Some(run) = self.buffer.layout_runs().next() else { return 0. };
        if index >= run.text.len() {
            return run.line_w;
        }
        run.cursor_position(&Cursor::new(0, index)).unwrap_or(0.)
    }

    /// Closest byte index for an x offset (first line).
    pub fn index_for_x(&self, x: f32) -> usize {
        let lh = self.buffer.metrics().line_height;
        match self.buffer.hit(x, lh / 2.) {
            Some(c) => c.index,
            None => 0,
        }
    }
}

#[derive(Hash, PartialEq, Eq)]
struct Key {
    text: String,
    size: u32,
    weight: u16,
    line_height: u32,
    mono: bool,
    /// Ellipsis width, or u32::MAX.
    max_width: u32,
    /// Wrap width, or u32::MAX.
    wrap: u32,
}

pub struct TextSystem {
    pub fonts: FontSystem,
    family: String,
    mono_family: String,
    cache: HashMap<Key, (TextLayout, u64)>,
    frame: u64,
}

impl TextSystem {
    pub fn new(fonts: Fonts) -> Self {
        Self {
            fonts: fonts.system,
            family: fonts.family,
            mono_family: fonts.mono_family,
            cache: HashMap::new(),
            frame: 0,
        }
    }

    /// Switch the UI language: Han characters then use that language's font
    /// (Japanese vs. Chinese shapes). Clears the layout cache.
    pub fn set_language(&mut self, lang: &str) {
        if self.fonts.locale() == lang {
            return;
        }
        let db = std::mem::replace(&mut self.fonts, FontSystem::new_with_locale_and_db("en".into(), fontdb::Database::new()))
            .into_locale_and_db()
            .1;
        self.fonts = FontSystem::new_with_locale_and_db_and_fallback(lang.into(), db, UiFallback);
        self.cache.clear();
    }

    /// Shape one line. With `max_width`, it ends in an ellipsis when too long.
    pub fn layout(&mut self, text: &str, style: TextStyle, max_width: Option<f32>) -> TextLayout {
        self.shape(text, style, max_width, None)
    }

    /// Shape text wrapped at `width` (any number of lines).
    pub fn layout_wrapped(&mut self, text: &str, style: TextStyle, width: f32) -> TextLayout {
        self.shape(text, style, None, Some(width))
    }

    fn shape(&mut self, text: &str, style: TextStyle, max_width: Option<f32>, wrap: Option<f32>) -> TextLayout {
        let px = |w: Option<f32>| w.map_or(u32::MAX, |w| w.max(0.).round() as u32);
        let key = Key {
            text: text.to_owned(),
            size: style.size.to_bits(),
            weight: style.weight,
            line_height: style.line_height.to_bits(),
            mono: style.mono,
            max_width: px(max_width),
            wrap: px(wrap),
        };
        let frame = self.frame;
        if let Some((layout, used)) = self.cache.get_mut(&key) {
            *used = frame;
            return layout.clone();
        }
        let mut buffer = Buffer::new(&mut self.fonts, Metrics::new(style.size, style.line_height));
        if let Some(w) = wrap {
            buffer.set_wrap(Wrap::WordOrGlyph);
            buffer.set_size(Some(w.max(1.)), None);
        } else {
            buffer.set_wrap(Wrap::None);
            if let Some(w) = max_width {
                buffer.set_size(Some(w.max(0.)), None);
                buffer.set_ellipsize(Ellipsize::End(EllipsizeHeightLimit::Lines(1)));
            }
        }
        let family = if style.mono { &self.mono_family } else { &self.family };
        let attrs = Attrs::new().family(Family::Name(family)).weight(Weight(style.weight));
        buffer.set_text(text, &attrs, Shaping::Advanced, None);
        buffer.shape_until_scroll(&mut self.fonts, false);
        let mut width: f32 = 0.;
        let mut lines = 0;
        let mut baseline = style.line_height * 0.75;
        for run in buffer.layout_runs() {
            if lines == 0 {
                baseline = run.line_y;
            }
            width = width.max(run.line_w);
            lines += 1;
        }
        let height = style.line_height * lines.max(1) as f32;
        let layout = TextLayout { buffer: Rc::new(buffer), width, height, baseline };
        self.cache.insert(key, (layout.clone(), frame));
        layout
    }

    /// Drop layouts that were not used in the last two frames, once the cache is big.
    pub fn end_frame(&mut self) {
        if self.cache.len() > 4096 {
            let keep = self.frame.saturating_sub(1);
            self.cache.retain(|_, (_, used)| *used >= keep);
        }
        self.frame += 1;
    }
}

pub struct Fonts {
    pub system: FontSystem,
    pub family: String,
    pub mono_family: String,
    pub faces: usize,
    pub load_ms: f64,
    pub strategy: &'static str,
}

/// Load the platform UI font, a monospace font and CJK fallbacks (Hangul, Japanese,
/// Simplified Chinese), instead of scanning every system font. Falls back to a full
/// scan if the known files are missing.
pub fn load_fonts() -> Fonts {
    let start = Instant::now();
    let mut db = fontdb::Database::new();
    let mut strategy = "platform files";
    for path in platform_font_files() {
        let _ = db.load_font_file(&path);
    }
    if db.is_empty() {
        db.load_system_fonts();
        strategy = "full system scan";
    }
    let family = pick(&db, &["System Font", ".SF NS", "Segoe UI", "Cantarell", "Noto Sans", "Ubuntu", "DejaVu Sans"]);
    let mono_family = pick(&db, &[".SF NS Mono", "SF Mono", "Consolas", "DejaVu Sans Mono", "Noto Sans Mono", "Liberation Mono"]);
    db.set_sans_serif_family(family.clone());
    db.set_monospace_family(mono_family.clone());
    let faces = db.len();
    let system = FontSystem::new_with_locale_and_db_and_fallback("en".into(), db, UiFallback);
    Fonts { system, family, mono_family, faces, load_ms: start.elapsed().as_secs_f64() * 1000., strategy }
}

/// For comparison: cosmic-text's default, which parses all system fonts.
pub fn full_scan_ms() -> (f64, usize) {
    let start = Instant::now();
    let fs = FontSystem::new();
    (start.elapsed().as_secs_f64() * 1000., fs.db().len())
}

/// The platform's fallback lists, except Han text: it follows the UI language with
/// the fonts loaded above (PingFang, cosmic-text's choice on macOS, is not a plain file).
struct UiFallback;

impl Fallback for UiFallback {
    fn common_fallback(&self) -> &'static [&'static str] {
        PlatformFallback.common_fallback()
    }

    fn forbidden_fallback(&self) -> &'static [&'static str] {
        PlatformFallback.forbidden_fallback()
    }

    fn script_fallback(&self, script: Script, locale: &str) -> &'static [&'static str] {
        if !cfg!(target_os = "macos") || !matches!(script, Script::Han | Script::Bopomofo) {
            return PlatformFallback.script_fallback(script, locale);
        }
        match locale {
            "ja" => &["Hiragino Sans"],
            "ko" => &["Apple SD Gothic Neo", "Hiragino Sans GB"],
            _ => &["Hiragino Sans GB", "Hiragino Sans"],
        }
    }
}

#[cfg(target_os = "macos")]
fn platform_font_files() -> Vec<PathBuf> {
    // SF Pro (variable), SF Mono, Apple SD Gothic Neo (Hangul), Hiragino Sans W3/W6
    // (Japanese), Hiragino Sans GB (Simplified Chinese; PingFang is not a plain file).
    let dir = PathBuf::from("/System/Library/Fonts");
    let mut files: Vec<PathBuf> =
        ["SFNS.ttf", "SFNSMono.ttf", "AppleSDGothicNeo.ttc", "Hiragino Sans GB.ttc"].iter().map(|f| dir.join(f)).collect();
    // Hiragino file names are not ASCII (and may be NFD on disk): match on the stable parts.
    if let Ok(entries) = std::fs::read_dir(&dir) {
        for e in entries.flatten() {
            let name = e.file_name().to_string_lossy().into_owned();
            if name.contains('角') && (name.ends_with("W3.ttc") || name.ends_with("W6.ttc")) {
                files.push(e.path());
            }
        }
    }
    files
}

#[cfg(target_os = "windows")]
fn platform_font_files() -> Vec<PathBuf> {
    // Segoe UI, Consolas, Malgun Gothic (Hangul), Yu Gothic UI (Japanese), Microsoft YaHei.
    let dir = std::env::var_os("WINDIR").map_or("C:\\Windows".into(), PathBuf::from).join("Fonts");
    ["segoeui.ttf", "seguisb.ttf", "segoeuib.ttf", "consola.ttf", "malgun.ttf", "malgunbd.ttf", "YuGothM.ttc", "YuGothB.ttc", "msyh.ttc", "msyhbd.ttc"]
        .iter()
        .map(|f| dir.join(f))
        .collect()
}

#[cfg(not(any(target_os = "macos", target_os = "windows")))]
fn platform_font_files() -> Vec<PathBuf> {
    // No fixed paths on Linux: an empty list makes load_fonts() scan the fontconfig dirs.
    Vec::new()
}

fn pick(db: &fontdb::Database, preferred: &[&str]) -> String {
    let has = |name: &str| db.faces().any(|f| f.families.iter().any(|(n, _)| n == name));
    preferred
        .iter()
        .find(|n| has(n))
        .map(|n| n.to_string())
        .or_else(|| db.faces().next().and_then(|f| f.families.first().map(|(n, _)| n.clone())))
        .unwrap_or_else(|| "sans-serif".into())
}
