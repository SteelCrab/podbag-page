//! An immediate-mode layer over `View`: events are queued, and the app's `ui()` runs
//! each frame, painting widgets that report clicks, drags, keys and scrolls as they
//! are drawn. A frame that consumed input paints once more, so state changed by
//! that input shows (the usual immediate-mode double frame).

use std::collections::HashMap;
use std::time::Instant;

use winit::event::{Ime, KeyEvent};
use winit::keyboard::{Key, ModifiersState, NamedKey};

use crate::app::{Cx, Event, ScrollDelta, View};
use crate::geom::{Color, Point, Rect, rgb};
use crate::scene::{Id, Paint};
use crate::text::{TextLayout, TextStyle};

/// The colors widgets use. The app picks the values (light, dark).
#[derive(Clone, Copy, Debug)]
pub struct Theme {
    pub page: Color,
    pub surface: Color,
    pub sunken: Color,
    pub hover: Color,
    pub ink: Color,
    pub ink2: Color,
    pub muted: Color,
    pub line: Color,
    pub accent: Color,
    pub accent_text: Color,
    pub accent_soft: Color,
    pub accent_ink: Color,
    pub green: Color,
    pub green_soft: Color,
    pub amber: Color,
    pub amber_soft: Color,
    pub red: Color,
    pub red_soft: Color,
    pub danger_bg: Color,
    pub gray_soft: Color,
    pub shadow: Color,
    pub backdrop: Color,
    /// Base text size.
    pub text_size: f32,
}

impl Default for Theme {
    fn default() -> Self {
        Self {
            page: rgb(0xffffff),
            surface: rgb(0xffffff),
            sunken: rgb(0xf2f2f2),
            hover: rgb(0xeeeeee),
            ink: rgb(0x111111),
            ink2: rgb(0x555555),
            muted: rgb(0x777777),
            line: rgb(0xdddddd),
            accent: rgb(0x2a78d6),
            accent_text: rgb(0x1d5fae),
            accent_soft: rgb(0xe5eefa),
            accent_ink: rgb(0xffffff),
            green: rgb(0x1b7f45),
            green_soft: rgb(0xe3f3e9),
            amber: rgb(0x8f5a00),
            amber_soft: rgb(0xfbf0d9),
            red: rgb(0xb8322d),
            red_soft: rgb(0xfbe6e5),
            danger_bg: rgb(0xb8322d),
            gray_soft: rgb(0xeeede8),
            shadow: Color { r: 0., g: 0., b: 0., a: 0.12 },
            backdrop: Color { r: 0., g: 0., b: 0., a: 0.35 },
            text_size: 14.,
        }
    }
}

/// Input queued since the last frame.
#[derive(Default)]
pub struct Input {
    pressed: Option<(Point, Option<Id>, bool)>,
    released: Option<(Point, Option<Id>)>,
    scroll: Vec<(Option<Id>, ScrollDelta)>,
    keys: Vec<(KeyEvent, ModifiersState, bool)>,
    ime: Vec<Ime>,
}

impl Input {
    fn is_empty(&self) -> bool {
        self.pressed.is_none() && self.released.is_none() && self.scroll.is_empty() && self.keys.is_empty() && self.ime.is_empty()
    }
}

/// Widget state kept across frames.
#[derive(Default)]
pub struct Memory {
    /// The widget the pointer went down on, while the button is held.
    active: Option<Id>,
    /// The open popup (select menu) and the hitboxes inside it last frame.
    popup: Option<Id>,
    popup_ids: Vec<Id>,
    popup_ids_next: Vec<Id>,
    /// Measured content heights (dialogs, scroll views), from the last frame.
    pub heights: HashMap<Id, f32>,
    pointer_down: bool,
}

pub struct Ui<'a, 'b> {
    pub p: &'a mut Paint<'b>,
    pub theme: Theme,
    input: &'a mut Input,
    pub mem: &'a mut Memory,
    clicked: Option<Id>,
    pressed: Option<Id>,
    consumed: bool,
}

impl<'a, 'b> Ui<'a, 'b> {
    pub fn bounds(&self) -> Rect {
        self.p.bounds()
    }

    pub fn pointer(&self) -> Option<Point> {
        self.p.pointer()
    }

    /// Pressed and released on `id` (a click), this frame.
    pub fn clicked(&mut self, id: Id) -> bool {
        if self.clicked == Some(id) {
            self.clicked = None;
            self.consumed = true;
            return true;
        }
        false
    }

    /// The pointer went down on `id` this frame. Returns (position, shift).
    pub fn pressed(&mut self, id: Id) -> Option<(Point, bool)> {
        match self.input.pressed {
            Some((pos, Some(hit), shift)) if hit == id && self.pressed == Some(id) => {
                self.pressed = None;
                self.consumed = true;
                Some((pos, shift))
            }
            _ => None,
        }
    }

    /// The pointer is held down on `id`.
    pub fn is_active(&self, id: Id) -> bool {
        self.mem.active == Some(id) && self.mem.pointer_down
    }

    pub fn hovered(&self, id: Id) -> bool {
        self.p.is_hovered(id)
    }

    /// Scrolling aimed at `id` this frame, in pixels (wheel lines become `line_px`).
    pub fn take_scroll(&mut self, id: Id, line_px: f32) -> f32 {
        let mut dy = 0.;
        self.input.scroll.retain(|(target, d)| {
            if *target != Some(id) {
                return true;
            }
            dy += match d {
                ScrollDelta::Lines(l) => l * line_px,
                ScrollDelta::Pixels(px) => *px,
            };
            false
        });
        if dy != 0. {
            self.consumed = true;
        }
        dy
    }

    /// Key presses not yet used by a widget.
    pub fn keys(&self) -> impl Iterator<Item = (usize, &KeyEvent, ModifiersState)> {
        self.input.keys.iter().enumerate().filter(|(_, k)| !k.2).map(|(i, k)| (i, &k.0, k.1))
    }

    pub fn consume_key(&mut self, i: usize) {
        if let Some(k) = self.input.keys.get_mut(i) {
            k.2 = true;
            self.consumed = true;
        }
    }

    /// A named key pressed this frame (and not used yet); uses it up.
    pub fn key_pressed(&mut self, key: NamedKey) -> Option<ModifiersState> {
        let i = self.keys().find(|(_, e, _)| e.logical_key == Key::Named(key)).map(|(i, _, m)| (i, m))?;
        self.consume_key(i.0);
        Some(i.1)
    }

    /// A shortcut letter with the platform modifier (Cmd or Ctrl); uses it up.
    pub fn shortcut(&mut self, letter: char, shift: bool) -> bool {
        let found = self.keys().find(|(_, e, m)| {
            crate::shortcut_modifier(*m) && m.shift_key() == shift && crate::shortcut_letter(e) == Some(letter)
        });
        if let Some((i, _, _)) = found {
            self.consume_key(i);
            return true;
        }
        false
    }

    pub fn take_ime(&mut self) -> Vec<Ime> {
        if !self.input.ime.is_empty() {
            self.consumed = true;
        }
        std::mem::take(&mut self.input.ime)
    }

    pub fn has_focus(&self, id: Id) -> bool {
        self.p.is_focused(id)
    }

    pub fn focus(&mut self, id: Option<Id>) {
        self.p.set_focus(id);
    }

    pub fn repaint(&mut self) {
        self.p.request_repaint();
    }

    pub fn wake_at(&mut self, at: Instant) {
        self.p.wake_at(at);
    }

    /// Run `f` with an extra clip rect.
    pub fn clip<R>(&mut self, rect: Rect, f: impl FnOnce(&mut Self) -> R) -> R {
        let old = self.p.clip;
        self.p.clip = old.intersect(&rect);
        let r = f(self);
        self.p.clip = old;
        r
    }

    /// Run `f` on another layer, with the clip reset to the window.
    pub fn on_layer<R>(&mut self, layer: usize, f: impl FnOnce(&mut Self) -> R) -> R {
        let (old_layer, old_clip) = (self.p.layer, self.p.clip);
        self.p.layer = layer.min(crate::scene::layer::COUNT - 1);
        self.p.clip = self.p.bounds;
        let r = f(self);
        self.p.layer = old_layer;
        self.p.clip = old_clip;
        r
    }

    // ---- popups ----

    pub fn popup_open(&self, id: Id) -> bool {
        self.mem.popup == Some(id)
    }

    pub fn open_popup(&mut self, id: Option<Id>) {
        self.mem.popup = id;
        self.repaint();
    }

    /// Mark a hitbox as part of the open popup (clicks on it keep it open).
    pub fn popup_hitbox(&mut self, id: Id) {
        self.mem.popup_ids_next.push(id);
    }

    // ---- text helpers ----

    pub fn style(&self) -> TextStyle {
        TextStyle::new(self.theme.text_size).line_height((self.theme.text_size * 1.45).round())
    }

    pub fn text(&mut self, text: &str, style: TextStyle) -> TextLayout {
        self.p.layout(text, style, None)
    }

    /// Wrapped text at (x, y); returns its height.
    pub fn paragraph(&mut self, x: f32, y: f32, width: f32, text: &str, style: TextStyle, color: Color) -> f32 {
        let layout = self.p.layout_wrapped(text, style, width);
        self.p.draw_text(&layout, x, y, color);
        layout.height
    }
}

/// An app written against `Ui`.
pub trait UiApp: 'static {
    type Message: Send + 'static;
    fn ui(&mut self, ui: &mut Ui);
    /// A message from another thread (stdin, backend events).
    fn message(&mut self, msg: Self::Message, cx: &mut Cx);
    /// A timer asked for with `wake_at` fired. Return true to paint.
    fn tick(&mut self, _cx: &mut Cx) -> bool {
        true
    }
    fn theme(&self, system_dark: bool) -> Theme;
}

/// Runs a `UiApp` as a `View`.
pub struct UiView<A> {
    pub app: A,
    input: Input,
    mem: Memory,
    background: Color,
}

impl<A: UiApp> UiView<A> {
    pub fn new(app: A) -> Self {
        Self { app, input: Input::default(), mem: Memory::default(), background: rgb(0xffffff) }
    }
}

impl<A: UiApp> View for UiView<A> {
    type Message = A::Message;

    fn paint(&mut self, p: &mut Paint) {
        let theme = self.app.theme(p.system_dark());
        self.background = theme.page;
        // A press outside the open popup closes it.
        if let Some((_, hit, _)) = self.input.pressed
            && self.mem.popup.is_some()
            && !hit.is_some_and(|h| self.mem.popup_ids.contains(&h) || Some(h) == self.mem.popup)
        {
            self.mem.popup = None;
        }
        let clicked = match (self.input.pressed, self.input.released) {
            (Some((_, a, _)), Some((_, b))) if a == b => a,
            (None, Some((_, b))) if self.mem.active.is_some() && self.mem.active == b => b,
            _ => None,
        };
        let pressed = self.input.pressed.and_then(|p| p.1);
        let had_input = !self.input.is_empty();
        self.mem.popup_ids_next.clear();
        let mut ui = Ui { p, theme, input: &mut self.input, mem: &mut self.mem, clicked, pressed, consumed: false };
        self.app.ui(&mut ui);
        let consumed = ui.consumed;
        std::mem::swap(&mut self.mem.popup_ids, &mut self.mem.popup_ids_next);
        if self.input.released.is_some() {
            self.mem.active = None;
        }
        self.input = Input::default();
        if had_input && consumed {
            p.request_repaint();
        }
    }

    fn event(&mut self, event: Event<'_, A::Message>, cx: &mut Cx) {
        match event {
            Event::PointerDown { pos, hit, shift } => {
                // A press elsewhere takes the focus away from a text field.
                if hit != cx.focused() {
                    cx.focus(None);
                }
                self.mem.active = hit;
                self.mem.pointer_down = true;
                self.input.pressed = Some((pos, hit, shift));
                cx.notify();
            }
            Event::PointerUp { pos, hit } => {
                self.mem.pointer_down = false;
                self.input.released = Some((pos, hit));
                cx.notify();
            }
            Event::PointerMove { .. } => {
                if self.mem.pointer_down && self.mem.active.is_some() {
                    cx.notify();
                }
            }
            Event::Scroll { delta, target, .. } => {
                self.input.scroll.push((target, delta));
                cx.notify();
            }
            Event::Key { event, mods } => {
                self.input.keys.push((event.clone(), mods, false));
                cx.notify();
            }
            Event::Ime(ime) => {
                self.input.ime.push(ime.clone());
                cx.notify();
            }
            Event::Message(m) => self.app.message(m, cx),
            Event::Timer => {
                if self.app.tick(cx) {
                    cx.notify();
                }
            }
        }
    }

    fn repaint_on_hover_change(&self) -> bool {
        true
    }

    fn background(&self) -> Color {
        self.background
    }
}
