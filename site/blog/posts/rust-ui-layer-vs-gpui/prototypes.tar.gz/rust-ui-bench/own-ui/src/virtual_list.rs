//! A vertical list of same-height rows that lays out and paints only the visible rows.

use crate::app::ScrollDelta;
use crate::geom::{Point, Rect};
use crate::scene::Paint;

pub struct VirtualList {
    pub row_height: f32,
    /// Pixels per wheel line.
    pub line_height: f32,
    offset: f32,
    count: usize,
    viewport: Rect,
}

impl VirtualList {
    pub fn new(row_height: f32, line_height: f32) -> Self {
        Self { row_height, line_height, offset: 0., count: 0, viewport: Rect::default() }
    }

    pub fn contains(&self, p: Point) -> bool {
        self.viewport.contains(p)
    }

    /// Returns true if the offset changed.
    pub fn scroll(&mut self, delta: &ScrollDelta) -> bool {
        // Positive deltas move the content down, i.e. scroll towards the top.
        let dy = match *delta {
            ScrollDelta::Lines(y) => y * self.line_height,
            ScrollDelta::Pixels(y) => y,
        };
        let old = self.offset;
        self.offset -= dy;
        self.clamp();
        self.offset != old
    }

    /// Scroll by `dy` pixels (positive: towards the top). Returns true on change.
    pub fn scroll_px(&mut self, dy: f32) -> bool {
        self.scroll(&ScrollDelta::Pixels(dy))
    }

    pub fn offset(&self) -> f32 {
        self.offset
    }

    pub fn set_offset(&mut self, offset: f32) {
        self.offset = offset;
        self.clamp();
    }

    /// Set the viewport and row count for this frame, and clamp the offset.
    pub fn layout(&mut self, rect: Rect, count: usize) {
        self.count = count;
        self.viewport = rect;
        self.clamp();
    }

    /// Rows that intersect the viewport.
    pub fn visible(&self) -> std::ops::Range<usize> {
        let h = self.row_height;
        let first = (self.offset / h).floor() as usize;
        let last = (((self.offset + self.viewport.h) / h).ceil() as usize).min(self.count);
        first.min(last)..last
    }

    pub fn row_rect(&self, i: usize) -> Rect {
        let v = self.viewport;
        Rect::new(v.x, v.y + i as f32 * self.row_height - self.offset, v.w, self.row_height)
    }

    pub fn max_offset(&self) -> f32 {
        (self.count as f32 * self.row_height - self.viewport.h).max(0.)
    }

    pub fn scroll_to_end(&mut self) {
        self.offset = self.max_offset();
    }

    pub fn at_end(&self) -> bool {
        self.offset >= self.max_offset() - 1.
    }

    fn clamp(&mut self) {
        let max = (self.count as f32 * self.row_height - self.viewport.h).max(0.);
        self.offset = self.offset.clamp(0., max);
    }

    /// Paint rows `[first, last)` that intersect `rect`, clipped to it.
    pub fn paint(&mut self, p: &mut Paint, rect: Rect, count: usize, mut row: impl FnMut(&mut Paint, usize, Rect)) {
        self.count = count;
        self.viewport = rect;
        self.clamp();
        let h = self.row_height;
        let first = (self.offset / h).floor() as usize;
        let last = (((self.offset + rect.h) / h).ceil() as usize).min(count);
        p.clip(rect, |p| {
            for i in first..last {
                let r = Rect::new(rect.x, rect.y + i as f32 * h - self.offset, rect.w, h);
                row(p, i, r);
            }
        });
    }
}
