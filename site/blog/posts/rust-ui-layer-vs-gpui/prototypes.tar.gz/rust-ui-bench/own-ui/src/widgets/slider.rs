//! A horizontal slider.

use winit::window::CursorIcon;

use crate::geom::Rect;
use crate::scene::Id;
use crate::ui::Ui;

/// Drag or click to set `value` in [min, max], snapped to `step`. Returns true on change.
pub fn slider(ui: &mut Ui, id: Id, rect: Rect, value: &mut f32, min: f32, max: f32, step: f32) -> bool {
    let t = ui.theme;
    let track = Rect::new(rect.x + 8., rect.y + rect.h / 2. - 2., rect.w - 16., 4.);
    let frac = if max > min { ((*value - min) / (max - min)).clamp(0., 1.) } else { 0. };
    ui.p.rounded(track, 2., t.sunken);
    ui.p.rounded(track.with_w(track.w * frac), 2., t.ink2);
    let knob = Rect::new(track.x + track.w * frac - 8., rect.y + rect.h / 2. - 8., 16., 16.);
    ui.p.shadow(knob, 8., 2., t.shadow);
    ui.p.bordered(knob, 8., t.surface, 1., t.line);
    ui.p.hitbox(rect, id, CursorIcon::Pointer);
    let x = if let Some((pos, _)) = ui.pressed(id) {
        Some(pos.x)
    } else if ui.is_active(id) {
        ui.pointer().map(|p| p.x)
    } else {
        None
    };
    let Some(x) = x else { return false };
    let f = ((x - track.x) / track.w).clamp(0., 1.);
    let mut v = min + f * (max - min);
    if step > 0. {
        v = (v / step).round() * step;
    }
    let v = v.clamp(min, max);
    if (v - *value).abs() > f32::EPSILON {
        *value = v;
        ui.repaint();
        return true;
    }
    false
}
