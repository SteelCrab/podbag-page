//! A minimal UI framework on winit + wgpu + glyphon. No widget toolkit underneath.
//!
//! Two levels: `View` (retained state, events, immediate painting; own-app uses it) and
//! `ui::UiApp` (immediate-mode widgets in `widgets`; own-full uses it).

mod app;
mod geom;
mod gpu;
pub mod icons;
mod scene;
mod text;
mod text_input;
pub mod ui;
mod virtual_list;
pub mod widgets;

pub use app::{App, Clipboard, Cx, Event, Proxy, ScrollDelta, Synthetic, View, WindowOptions, shortcut_letter, shortcut_modifier, since_start};
pub use geom::{Color, Point, Rect, rgb, rgba};
pub use scene::{Id, Paint, layer};
pub use text::{LINE_HEIGHT, TextLayout, TextStyle, TextSystem, full_scan_ms, load_fonts};
pub use text_input::TextInput;
pub use virtual_list::VirtualList;
pub use winit;
pub use winit::window::CursorIcon;
