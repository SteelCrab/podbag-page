//! Rect-cut layout for rows of widgets: take slices from the left or the right.

use crate::geom::Rect;

pub struct Row {
    pub rect: Rect,
    pub gap: f32,
    left: f32,
    right: f32,
}

impl Row {
    pub fn new(rect: Rect, gap: f32) -> Self {
        Self { rect, gap, left: rect.x, right: rect.right() }
    }

    /// The next `w` wide slot from the left, full height.
    pub fn left(&mut self, w: f32) -> Rect {
        let r = Rect::new(self.left, self.rect.y, w, self.rect.h);
        self.left += w + self.gap;
        r
    }

    /// The next `w` wide slot from the right.
    pub fn right(&mut self, w: f32) -> Rect {
        self.right -= w;
        let r = Rect::new(self.right, self.rect.y, w, self.rect.h);
        self.right -= self.gap;
        r
    }

    /// A slot of height `h`, centered vertically, from the left.
    pub fn left_h(&mut self, w: f32, h: f32) -> Rect {
        self.left(w).center_v(h)
    }

    pub fn right_h(&mut self, w: f32, h: f32) -> Rect {
        self.right(w).center_v(h)
    }

    /// What is left between the two sides.
    pub fn rest(&self) -> Rect {
        Rect::new(self.left, self.rect.y, (self.right - self.left).max(0.), self.rect.h)
    }

    pub fn skip(&mut self, w: f32) {
        self.left += w;
    }
}

/// A vertical cursor for stacked content.
pub struct Column {
    pub x: f32,
    pub y: f32,
    pub w: f32,
}

impl Column {
    pub fn new(x: f32, y: f32, w: f32) -> Self {
        Self { x, y, w }
    }

    /// Take `h` of height.
    pub fn take(&mut self, h: f32) -> Rect {
        let r = Rect::new(self.x, self.y, self.w, h);
        self.y += h;
        r
    }

    pub fn space(&mut self, h: f32) {
        self.y += h;
    }
}
