//! Single-line text input with IME, selection and clipboard.
//! The editing logic follows GPUI's `examples/input.rs` (Apache-2.0), ported to winit events.

use std::ops::Range;

use unicode_segmentation::UnicodeSegmentation;
use winit::event::{Ime, KeyEvent};
use winit::keyboard::{Key, ModifiersState, NamedKey};
use winit::window::CursorIcon;

use crate::app::{Clipboard, shortcut_letter, shortcut_modifier};
use crate::geom::{Color, Point, Rect, rgb, rgba};
use crate::scene::{Id, Paint};
use crate::text::{TextLayout, TextStyle};


pub struct TextInput {
    pub id: Id,
    pub content: String,
    placeholder: String,
    pub style: TextStyle,
    pub color: Color,
    pub placeholder_color: Color,
    pub caret_color: Color,
    pub selection_color: Color,
    selected: Range<usize>,
    reversed: bool,
    /// IME composition (preedit) range in `content`.
    marked: Option<Range<usize>>,
    selecting: bool,
    last_layout: Option<TextLayout>,
    last_bounds: Rect,
}

impl TextInput {
    pub fn new(id: Id, placeholder: &str, style: TextStyle, color: Color) -> Self {
        Self {
            id,
            content: String::new(),
            placeholder: placeholder.into(),
            style,
            color,
            placeholder_color: rgba(0x000000, 0.2),
            caret_color: rgb(0x0066ff), // gpui::blue()
            selection_color: rgba(0x3311ff, 0x30 as f32 / 255.),
            selected: 0..0,
            reversed: false,
            marked: None,
            selecting: false,
            last_layout: None,
            last_bounds: Rect::default(),
        }
    }

    /// Replace the whole content, as if typed.
    pub fn set_content(&mut self, text: &str) {
        self.content = text.into();
        self.selected = text.len()..text.len();
        self.reversed = false;
        self.marked = None;
    }

    pub fn set_placeholder(&mut self, text: &str) {
        if self.placeholder != text {
            self.placeholder = text.into();
        }
    }

    pub fn select_all(&mut self) {
        self.move_to(0);
        self.select_to(self.content.len());
    }

    pub fn is_selecting(&self) -> bool {
        self.selecting
    }

    /// Handle a key press. None: not for this widget. Some(changed): handled, and
    /// whether the content changed.
    pub fn key(&mut self, event: &KeyEvent, mods: ModifiersState, clip: &mut Clipboard) -> Option<bool> {
        if self.marked.is_some() {
            return Some(false); // the IME owns the keys while composing
        }
        let old = self.content.clone();
        match &event.logical_key {
            Key::Named(NamedKey::Backspace) => {
                if self.selected.is_empty() {
                    self.select_to(self.previous_boundary(self.cursor()));
                }
                self.replace(None, "");
            }
            Key::Named(NamedKey::Delete) => {
                if self.selected.is_empty() {
                    self.select_to(self.next_boundary(self.cursor()));
                }
                self.replace(None, "");
            }
            Key::Named(NamedKey::ArrowLeft) if mods.shift_key() => {
                self.select_to(self.previous_boundary(self.cursor()))
            }
            Key::Named(NamedKey::ArrowRight) if mods.shift_key() => {
                self.select_to(self.next_boundary(self.cursor()))
            }
            Key::Named(NamedKey::ArrowLeft) => {
                let to = if self.selected.is_empty() {
                    self.previous_boundary(self.cursor())
                } else {
                    self.selected.start
                };
                self.move_to(to);
            }
            Key::Named(NamedKey::ArrowRight) => {
                let to = if self.selected.is_empty() {
                    self.next_boundary(self.selected.end)
                } else {
                    self.selected.end
                };
                self.move_to(to);
            }
            Key::Named(NamedKey::Home) => self.move_to(0),
            Key::Named(NamedKey::End) => self.move_to(self.content.len()),
            _ if shortcut_modifier(mods) => match shortcut_letter(event) {
                Some('a') => self.select_all(),
                Some('c') => self.copy(clip),
                Some('x') => {
                    self.copy(clip);
                    self.replace(None, "");
                }
                Some('v') => {
                    if let Some(text) = clip.read() {
                        self.replace(None, &text.replace('\n', " "));
                    }
                }
                _ => return None,
            },
            _ => match &event.text {
                Some(t) if !mods.control_key() && !mods.super_key() && !t.chars().any(char::is_control) => {
                    self.replace(None, t);
                }
                _ => return None,
            },
        }
        Some(old != self.content)
    }

    /// Handle IME composition. Returns true if the content changed.
    pub fn ime(&mut self, ime: &Ime) -> bool {
        match ime {
            Ime::Preedit(text, cursor) => {
                let range = self.marked.clone().unwrap_or(self.selected.clone());
                if text.is_empty() && self.marked.is_none() {
                    return false;
                }
                self.splice(range.clone(), text);
                if text.is_empty() {
                    self.marked = None;
                    self.selected = range.start..range.start;
                } else {
                    self.marked = Some(range.start..range.start + text.len());
                    self.selected = match cursor {
                        Some((a, b)) => range.start + a..range.start + b,
                        None => range.start + text.len()..range.start + text.len(),
                    };
                }
            }
            Ime::Commit(text) => self.replace(None, text),
            Ime::Disabled => self.marked = None,
            Ime::Enabled => return false,
        }
        self.reversed = false;
        true
    }

    pub fn pointer_down(&mut self, pos: Point, shift: bool) {
        self.selecting = true;
        let ix = self.index_for_position(pos);
        if shift { self.select_to(ix) } else { self.move_to(ix) }
    }

    /// Extend a drag selection. Returns true if the selection changed.
    pub fn pointer_move(&mut self, pos: Point) -> bool {
        if !self.selecting {
            return false;
        }
        let old = self.selected.clone();
        self.select_to(self.index_for_position(pos));
        old != self.selected
    }

    pub fn pointer_up(&mut self) {
        self.selecting = false;
    }

    /// Paint the box content. `line` is the text line rect; `hit` the clickable area.
    pub fn paint(&mut self, p: &mut Paint, line: Rect, hit: Rect) {
        p.hitbox(hit, self.id, CursorIcon::Text);
        let (text, color) = if self.content.is_empty() {
            (self.placeholder.as_str(), self.placeholder_color)
        } else {
            (self.content.as_str(), self.color)
        };
        let layout = p.layout(text, self.style, None);
        let y = line.y + (line.h - layout.height) / 2.;
        p.clip(hit, |p| {
            if !self.selected.is_empty() {
                let x0 = layout.x_for_index(self.selected.start);
                let x1 = layout.x_for_index(self.selected.end);
                p.fill(Rect::new(line.x + x0, line.y, x1 - x0, line.h), self.selection_color);
            }
            p.draw_text(&layout, line.x, y, color);
            if let Some(m) = &self.marked {
                let x0 = layout.x_for_index(m.start);
                let x1 = layout.x_for_index(m.end);
                p.fill(Rect::new(line.x + x0, y + layout.baseline + 2., x1 - x0, 1.), self.color);
            }
            if p.is_focused(self.id) {
                let x = layout.x_for_index(self.cursor());
                if self.selected.is_empty() {
                    p.overlay(Rect::new(line.x + x, line.y, 2., line.h), self.caret_color);
                }
                let start = self.marked.as_ref().map_or(x, |m| layout.x_for_index(m.start));
                p.set_ime_area(Rect::new(line.x + start, line.y, 2., line.h));
            }
        });
        self.last_layout = Some(layout);
        self.last_bounds = line;
    }

    fn copy(&mut self, clip: &mut Clipboard) {
        if !self.selected.is_empty() {
            clip.write(self.content[self.selected.clone()].to_string());
        }
    }

    /// Replace the marked range, or else the selection, and drop the marking.
    fn replace(&mut self, range: Option<Range<usize>>, text: &str) {
        let range = range.or(self.marked.clone()).unwrap_or(self.selected.clone());
        self.splice(range.clone(), text);
        let end = range.start + text.len();
        self.selected = end..end;
        self.marked = None;
    }

    fn splice(&mut self, range: Range<usize>, text: &str) {
        self.content.replace_range(range, text);
    }

    fn move_to(&mut self, offset: usize) {
        self.selected = offset..offset;
        self.reversed = false;
    }

    fn cursor(&self) -> usize {
        if self.reversed { self.selected.start } else { self.selected.end }
    }

    fn select_to(&mut self, offset: usize) {
        if self.reversed {
            self.selected.start = offset;
        } else {
            self.selected.end = offset;
        }
        if self.selected.end < self.selected.start {
            self.reversed = !self.reversed;
            self.selected = self.selected.end..self.selected.start;
        }
    }

    fn index_for_position(&self, pos: Point) -> usize {
        let (Some(layout), b) = (&self.last_layout, self.last_bounds) else { return 0 };
        if self.content.is_empty() || pos.y < b.y {
            return 0;
        }
        if pos.y > b.bottom() {
            return self.content.len();
        }
        layout.index_for_x(pos.x - b.x).min(self.content.len())
    }

    fn previous_boundary(&self, offset: usize) -> usize {
        self.content
            .grapheme_indices(true)
            .rev()
            .find_map(|(i, _)| (i < offset).then_some(i))
            .unwrap_or(0)
    }

    fn next_boundary(&self, offset: usize) -> usize {
        self.content
            .grapheme_indices(true)
            .find_map(|(i, _)| (i > offset).then_some(i))
            .unwrap_or(self.content.len())
    }
}
