//! The per-frame display list and the paint context views draw into.
//!
//! Views paint immediate-mode every frame: quads, text, icons and hitboxes, each into a
//! layer. Higher layers draw on top and win hit tests (popups, dialogs, toasts). The
//! hitboxes of the last frame drive clicks, hover tracking and the mouse cursor.

use std::hash::{Hash, Hasher};
use std::time::Instant;

use winit::window::CursorIcon;

use crate::app::Clipboard;
use crate::geom::{Color, Point, Rect};
use crate::text::{TextLayout, TextStyle, TextSystem};

/// Identifies an interactive region. Views pick the values.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Id(pub u64);

impl Id {
    /// An id from any hashable key, e.g. `Id::of(("row", 3))`.
    pub fn of(key: impl Hash) -> Id {
        let mut h = std::collections::hash_map::DefaultHasher::new();
        key.hash(&mut h);
        Id(h.finish())
    }

    /// A child id.
    pub fn with(self, key: impl Hash) -> Id {
        Id::of((self.0, key))
    }
}

/// Layers, bottom to top.
pub mod layer {
    pub const BASE: usize = 0;
    pub const POPUP: usize = 1;
    pub const MODAL: usize = 2;
    pub const MODAL_POPUP: usize = 3;
    pub const TOP: usize = 4;
    pub const COUNT: usize = 5;
}

#[derive(Clone, Copy)]
pub struct Quad {
    pub rect: Rect,
    pub clip: Rect,
    pub color: Color,
    pub radius: f32,
    pub border: f32,
    pub border_color: Color,
    /// Blur radius for soft shadows; 0 for crisp edges.
    pub blur: f32,
}

pub struct TextDraw {
    pub layout: TextLayout,
    pub x: f32,
    pub y: f32,
    pub clip: Rect,
    pub color: Color,
}

/// An icon from the registry (see `icons`), drawn as a square.
pub struct IconDraw {
    pub icon: u16,
    pub rect: Rect,
    pub clip: Rect,
    pub color: Color,
}

pub struct Hitbox {
    pub rect: Rect,
    pub id: Id,
    pub cursor: CursorIcon,
    pub layer: usize,
}

#[derive(Default)]
pub struct Layer {
    /// Drawn first.
    pub quads: Vec<Quad>,
    /// Drawn over the quads.
    pub texts: Vec<TextDraw>,
    pub icons: Vec<IconDraw>,
    /// Drawn over the text (carets).
    pub overlay: Vec<Quad>,
}

#[derive(Default)]
pub struct Scene {
    pub layers: [Layer; layer::COUNT],
    pub hitboxes: Vec<Hitbox>,
    /// Scroll targets, same order rules as hitboxes.
    pub scrollers: Vec<Hitbox>,
}

impl Scene {
    pub fn clear(&mut self) {
        for l in &mut self.layers {
            l.quads.clear();
            l.texts.clear();
            l.icons.clear();
            l.overlay.clear();
        }
        self.hitboxes.clear();
        self.scrollers.clear();
    }

    /// Topmost hitbox under a point.
    pub fn hit(&self, p: Point) -> Option<&Hitbox> {
        topmost(&self.hitboxes, p)
    }

    pub fn scroller(&self, p: Point) -> Option<&Hitbox> {
        topmost(&self.scrollers, p)
    }
}

fn topmost(list: &[Hitbox], p: Point) -> Option<&Hitbox> {
    // Later entries of the same layer are on top.
    let mut best: Option<&Hitbox> = None;
    for h in list.iter().filter(|h| h.rect.contains(p)) {
        if best.is_none_or(|b| h.layer >= b.layer) {
            best = Some(h);
        }
    }
    best
}

pub type FrameCallback = Box<dyn FnOnce()>;

pub struct Paint<'a> {
    pub(crate) scene: &'a mut Scene,
    pub text: &'a mut TextSystem,
    pub(crate) bounds: Rect,
    pub(crate) pointer: Option<Point>,
    pub(crate) hover: Option<Id>,
    pub(crate) hover_layer: usize,
    pub(crate) focus: &'a mut Option<Id>,
    pub(crate) clip: Rect,
    pub(crate) layer: usize,
    pub(crate) next_frame: &'a mut Vec<FrameCallback>,
    pub(crate) ime_area: Option<Rect>,
    pub(crate) clipboard: &'a mut Clipboard,
    pub(crate) repaint: bool,
    pub(crate) quit: bool,
    pub(crate) wake_at: &'a mut Option<Instant>,
    pub(crate) scale: f32,
    pub(crate) dark: bool,
}

impl Paint<'_> {
    /// The window content area.
    pub fn bounds(&self) -> Rect {
        self.bounds
    }

    pub fn scale(&self) -> f32 {
        self.scale
    }

    /// True if the system appearance is dark.
    pub fn system_dark(&self) -> bool {
        self.dark
    }

    pub fn pointer(&self) -> Option<Point> {
        self.pointer
    }

    pub fn is_focused(&self, id: Id) -> bool {
        *self.focus == Some(id)
    }

    pub fn focused(&self) -> Option<Id> {
        *self.focus
    }

    /// Focus a text widget; the IME is on while something has focus.
    pub fn set_focus(&mut self, id: Option<Id>) {
        *self.focus = id;
    }

    pub fn clipboard(&mut self) -> &mut Clipboard {
        self.clipboard
    }

    /// Paint again after this frame (state changed while painting).
    pub fn request_repaint(&mut self) {
        self.repaint = true;
    }

    pub fn quit(&mut self) {
        self.quit = true;
    }

    /// Paint again no later than `at`.
    pub fn wake_at(&mut self, at: Instant) {
        if self.wake_at.is_none_or(|w| at < w) {
            *self.wake_at = Some(at);
        }
    }

    /// True if the pointer is over `rect` and inside the current clip.
    pub fn hovered(&self, rect: Rect) -> bool {
        self.pointer.is_some_and(|p| rect.contains(p) && self.clip.contains(p))
    }

    /// True if the pointer is over `rect` and nothing of a higher layer covers it.
    pub fn hovered_area(&self, rect: Rect) -> bool {
        self.hovered(rect) && (self.hover.is_none() || self.hover_layer <= self.layer)
    }

    /// True if `id` is the topmost hitbox under the pointer (as of the last frame).
    pub fn is_hovered(&self, id: Id) -> bool {
        self.hover == Some(id)
    }

    pub fn fill(&mut self, rect: Rect, color: Color) {
        self.rounded(rect, 0., color);
    }

    pub fn rounded(&mut self, rect: Rect, radius: f32, color: Color) {
        self.bordered(rect, radius, color, 0., Color::TRANSPARENT);
    }

    pub fn bordered(&mut self, rect: Rect, radius: f32, fill: Color, border: f32, border_color: Color) {
        let quad = Quad { rect, clip: self.clip, color: fill, radius, border, border_color, blur: 0. };
        self.scene.layers[self.layer].quads.push(quad);
    }

    /// A soft shadow under a rounded rect.
    pub fn shadow(&mut self, rect: Rect, radius: f32, blur: f32, color: Color) {
        let r = Rect::new(rect.x - blur, rect.y - blur + blur / 3., rect.w + blur * 2., rect.h + blur * 2.);
        let quad = Quad {
            rect: r,
            clip: self.clip,
            color,
            radius: radius + blur,
            border: 0.,
            border_color: color,
            blur,
        };
        self.scene.layers[self.layer].quads.push(quad);
    }

    /// A quad drawn above all text of the layer, e.g. a caret.
    pub fn overlay(&mut self, rect: Rect, color: Color) {
        let quad = Quad { rect, clip: self.clip, color, radius: 0., border: 0., border_color: color, blur: 0. };
        self.scene.layers[self.layer].overlay.push(quad);
    }

    /// One-pixel line along the bottom edge.
    pub fn border_bottom(&mut self, rect: Rect, color: Color) {
        self.fill(Rect::new(rect.x, rect.bottom() - 1., rect.w, 1.), color);
    }

    pub fn layout(&mut self, text: &str, style: TextStyle, max_width: Option<f32>) -> TextLayout {
        self.text.layout(text, style, max_width)
    }

    /// Text wrapped at `width`, any number of lines.
    pub fn layout_wrapped(&mut self, text: &str, style: TextStyle, width: f32) -> TextLayout {
        self.text.layout_wrapped(text, style, width)
    }

    /// Draw a laid-out text with its first line box top-left at (x, y).
    pub fn draw_text(&mut self, layout: &TextLayout, x: f32, y: f32, color: Color) {
        let clip = self.clip;
        self.scene.layers[self.layer].texts.push(TextDraw { layout: layout.clone(), x, y, clip, color });
    }

    /// Left-aligned, vertically centered, clipped text with an ellipsis if it is too wide.
    pub fn label(&mut self, rect: Rect, text: &str, style: TextStyle, color: Color) -> TextLayout {
        let layout = self.layout(text, style, Some(rect.w));
        let y = rect.y + (rect.h - layout.height) / 2.;
        self.clip(rect, |p| p.draw_text(&layout, rect.x, y, color));
        layout
    }

    /// An icon from the registry, filling `rect` (square).
    pub fn icon(&mut self, icon: u16, rect: Rect, color: Color) {
        let clip = self.clip;
        self.scene.layers[self.layer].icons.push(IconDraw { icon, rect, clip, color });
    }

    pub fn hitbox(&mut self, rect: Rect, id: Id, cursor: CursorIcon) {
        let rect = rect.intersect(&self.clip);
        self.scene.hitboxes.push(Hitbox { rect, id, cursor, layer: self.layer });
    }

    /// A region that takes wheel and trackpad scrolling.
    pub fn scroll_region(&mut self, rect: Rect, id: Id) {
        let rect = rect.intersect(&self.clip);
        let cursor = CursorIcon::Default;
        self.scene.scrollers.push(Hitbox { rect, id, cursor, layer: self.layer });
    }

    /// Paint with an extra clip rect.
    pub fn clip<R>(&mut self, rect: Rect, f: impl FnOnce(&mut Self) -> R) -> R {
        let old = self.clip;
        self.clip = old.intersect(&rect);
        let r = f(self);
        self.clip = old;
        r
    }

    pub fn current_clip(&self) -> Rect {
        self.clip
    }

    pub fn current_layer(&self) -> usize {
        self.layer
    }

    /// Paint into another layer; the clip is reset to the window.
    pub fn on_layer<R>(&mut self, layer: usize, f: impl FnOnce(&mut Self) -> R) -> R {
        let (old_layer, old_clip) = (self.layer, self.clip);
        self.layer = layer.min(layer::COUNT - 1);
        self.clip = self.bounds;
        let r = f(self);
        self.layer = old_layer;
        self.clip = old_clip;
        r
    }

    /// Run `f` when the frame after this one begins, i.e. once this frame was presented.
    pub fn on_next_frame(&mut self, f: impl FnOnce() + 'static) {
        self.next_frame.push(Box::new(f));
    }

    /// Where the IME candidate window should go (the focused text field's caret).
    pub fn set_ime_area(&mut self, rect: Rect) {
        self.ime_area = Some(rect);
    }
}
