# bench-api

The shared backend of the full-port benchmark. A Rust port of Podbag Desktop's mocked
API (`desktop/preview/mock.js` at `ec551fd`), its string tables (`desktop/ui/i18n.js`)
and the `Intl` formatting that app.js uses. No UI types (no gpui, no winit).

```toml
bench-api = { path = "../shared/bench-api" }
```

## Start

```rust
use bench_api::{Backend, Options, Event, Kind};

let (backend, events) = Backend::new(Options::from_env());
// `backend` is Clone + Send + Sync: give a clone to each place that needs it.
// `events` is a std::sync::mpsc::Receiver<Event>: drain it from the UI loop.
```

`Options::from_env()` reads:

| Input | Effect |
|---|---|
| `--rows N` or `BENCH_ROWS=N` | The containers are the N synthetic rows of `gpui-app/src/data.rs` (same generator). |
| `BENCH_SCENARIO` | `default` (podbag on macOS, VM running), `empty`, `vm` (VM stopped), `offline` (Linux, not reachable), `docker`. These are mock.js views. |
| `BENCH_FEATURES=all` | `features()` returns stats, top, pause and rename on (mock.js: all off). Needed to see the rename dialog and pause. |
| `BENCH_LANG` | The first language setting (`en` by default, as in mock.js). |

`Options { instant: true, .. }` runs all timers at once (tests).

## Event model

Commands are plain synchronous methods on `Backend`. They return at once.
Timed results come as `Event`s on the channel, sent from timer threads, at the
times mock.js uses:

| Event | Sent by | When |
|---|---|---|
| `Changed` | `act`, `remove`, `rename`, `create_volume`, end of `pull` | at once |
| `Live(bool)` | `watch(on)` | after 10 ms |
| `Logs { generation, lines }` | `logs_start` | 28 lines after 30 ms, then 1 line a second until `logs_stop` |
| `PullProgress(line)` | `pull` | 6 lines, about 220 ms apart |
| `PullDone(Result<String, String>)` | `pull` | after the last line (the pulled reference, or an error) |
| `EngineChanged(action)` | `vm(action)` | at once |
| `VmStatus(state)` | (not sent by the mock) | – |
| `DockerSwitching(to)` / `DockerChanged(cmd)` | `docker_switch(to)` | at once / after 650 ms |

A UI that needs a wakeup (winit `EventLoopProxy`, GPUI task) can run a thread that blocks
on `events.recv()` and forwards each event to its own loop.

## Commands

All on `Backend`. `Result<_, String>` errors are the text the UI shows.

| mock.js command | Rust |
|---|---|
| `connection` | `connection() -> Connection { token, name, local }` |
| `contexts` | `contexts() -> Vec<String>` |
| `engine` | `engine(start: bool) -> EngineInfo` (`start` starts a stopped VM) |
| `set_engine` | `set_engine(name) -> Result<()>` (then call `connection` and `engine` again) |
| `list` | `containers()`, `images()`, `volumes()`, `networks()` `-> Result<Vec<T>>` |
| `inspect` | `inspect(Kind, id) -> Result<serde_json::Value>` |
| `features` | `features(sample) -> Features` |
| `container_json` | `container_json(id, "top" or "stats") -> Result<Value>` |
| `act` | `act(id, "start" / "stop" / "restart" / "pause" / "unpause") -> Result<()>` |
| `remove` | `remove(Kind, id, force) -> Result<()>` |
| `prune` | `prune(Kind) -> Result<PruneResult { count, bytes }>` |
| `rename` | `rename(id, name) -> Result<()>` |
| `create_volume` | `create_volume(name) -> Result<()>` |
| `open_shell`, `open_terminal` | `open_shell(id)`, `open_terminal(what) -> Result<()>` |
| `logs_start` / `logs_stop` | `logs_start(id) -> u64` (generation), `logs_stop()` |
| `watch` | `watch(on)` |
| `pull` | `pull(image, location, host)` (result: `PullDone`) |
| `search` | `search(term) -> SearchResult { supported, error, results }` |
| `registries` | `registries(&[(id, host)]) -> Vec<Registry>` |
| `docker_images` / `import_images` | `docker_images() -> Vec<DockerImage>`, `import_images(&names)` |
| `docker_command` / `docker_switch` | `docker_command() -> Option<DockerCommand>`, `docker_switch(to)` |
| `vm` | `vm(action) -> Result<()>` |
| `vm_status` | `vm_status() -> Option<VmStatus>` (None for Docker and Linux) |
| `vm_set` | `vm_set(VmChange) -> Result<String>` |
| `kube_contexts` | `kube_contexts() -> Result<Vec<String>>` |
| `kube_counts` | `kube_counts(context, all_namespaces) -> Result<KubeCounts>` |
| `kube_list` | `kube_list(KubeKind, all_namespaces, context) -> Result<KubeList { context, namespace, items }>` (items are JSON) |
| `get_settings` / `set_settings` | `get_settings() -> Settings`, `set_settings(&Settings)` |
| `plugin:autostart\|…` | `launch_at_login() -> Result<bool>`, `set_launch_at_login(bool)` |
| `updates` | `updates() -> Updates` (for the status bar) |
| – | `now()`: the Unix time the sample data is relative to |

Data helpers from app.js (`types.rs`): `Container::name()`, `ports_text()`, `is_up()`,
`Image::name()`, `Network::builtin()`, `subnet()`, `gateway()`, `short_id()`,
`pretty_json()` (like `JSON.stringify(v, null, 2)`, same key order).

## i18n (`bench_api::i18n`)

```rust
let mut tr = I18n::new("system");      // or "en", "ko", "ja", "zh-CN", "fil", "es", "vi"
tr.t("nav.containers");                // language → English → the key
tr.tv("done.remove", &[("name", &"web")]);
tr.load("ko");                         // runtime switch; returns the language used
i18n::names();                         // [(lang, own name)] for the settings menu
```

"system" resolves through `sys-locale` and `LANG` with the rules of i18n.js
(`zh*` → zh-CN, `tl`/`fil` → fil, else the base tag, else en). The JSON files are
copies in `shared/i18n/`, embedded with `include_str!`.

## Formatting (`bench_api::fmt`)

`ago(when, now, lang)` ("2 hours ago", "어제"), `size(bytes, lang)`, `mib(Option<u32>, lang)`,
`percent(p, lang)`, `duration(Option<u64>, lang)`, `number(x, digits, lang)`,
`parse_rfc3339(text)`. They follow what a browser's `Intl` prints for the 7 languages, close
enough for a side-by-side look.

## Differences from mock.js

mock.js is a static preview. To let the UI show the result of an action:

- `act`, `remove`, `rename` change the lists and send `Changed` (mock.js returns null and
  changes nothing). `remove` of a running container without `force` fails, and built-in
  networks cannot be removed, as with a real engine.
- `pull` streams 6 progress lines and finishes (mock.js never resolves). A name with
  `notfound` fails. The pulled image is added to the list.
- `logs_start` keeps adding a line a second (mock.js sends one batch).
- `engine(true)` starts a stopped VM (mock.js ignores it). `vm("stop")` also clears the
  usage values of `vm_status`, as the stopped VM of mock.js's `vm` view has none.
- `vm_set` stores the values and updates `pending` (mock.js returns "Saved." only).
- `prune` returns `{ count: 2, bytes: 61 MB }` and changes nothing, as in mock.js.

## Tests

`cargo test`: mock data and command results, actions and events, i18n fallback,
formatting, and `tests/parity.rs`, which compiles `gpui-app/src/data.rs` as is and
compares its first and last rows with `rows::rows(n)`.
