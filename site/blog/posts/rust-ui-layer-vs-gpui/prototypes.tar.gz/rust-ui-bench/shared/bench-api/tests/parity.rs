//! The `--rows` rows equal the parity prototypes' rows (gpui-app/src/data.rs, compiled as is).

use bench_api::{Backend, Options, rows};

// The parity prototypes' generator, compiled as is.
#[allow(unexpected_cfgs, dead_code)]
#[path = "../../../gpui-app/src/data.rs"]
mod prototype;

#[test]
fn synthetic_rows_match_prototype() {
    for n in [1, 1000, 10000] {
        let ours = rows::rows(n);
        let theirs = prototype::rows(n);
        for (a, b) in [
            (&ours[0], &theirs[0]),
            (ours.last().unwrap(), theirs.last().unwrap()),
        ] {
            assert_eq!(
                (&a.name, a.image, a.running, &a.ports, &a.created, &a.hay),
                (&b.name, b.image, b.running, &b.ports, &b.created, &b.hay)
            );
        }
    }
    let (b, _) = Backend::new(Options {
        rows: Some(1000),
        instant: true,
        ..Options::default()
    });
    let list = b.containers().unwrap();
    assert_eq!(list.len(), 1000);
    assert_eq!(list[999].name(), "worker-00999");
    assert_eq!(list[1].ports_text(), "8001→8080/tcp");
    // The benchmark filter: web-00040 and web-00045.
    let hits = list
        .iter()
        .filter(|c| c.name().contains("web-0004") || c.id.contains("web-0004"))
        .count();
    assert_eq!(hits, 2);
}
