//! The mocked engine: a Rust port of `desktop/preview/mock.js` (Podbag ec551fd).
//! Same data and results. Where mock.js does nothing, this mock changes its lists so the
//! UI can show the result (see README.md, "Differences from mock.js").

use std::sync::mpsc::{Receiver, Sender, channel};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;

use serde_json::{Value, json};

use crate::fmt::rfc3339;
use crate::rows;
use crate::types::*;

/// Which mock.js `view` to start from (the engine's state, the data).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Scenario {
    /// podbag on macOS, VM running, sample data.
    #[default]
    Default,
    /// No containers and no volumes.
    Empty,
    /// The VM is stopped (mock.js `vm`).
    VmStopped,
    /// The engine does not answer, on Linux (mock.js `offline`).
    Offline,
    /// Docker Desktop is the engine (mock.js `docker`).
    Docker,
}

impl Scenario {
    pub fn parse(s: &str) -> Option<Scenario> {
        Some(match s {
            "default" | "" => Scenario::Default,
            "empty" => Scenario::Empty,
            "vm" => Scenario::VmStopped,
            "offline" => Scenario::Offline,
            "docker" => Scenario::Docker,
            _ => return None,
        })
    }
}

#[derive(Clone, Debug, Default)]
pub struct Options {
    /// Some(n): the containers are the n synthetic rows (`--rows N`).
    pub rows: Option<usize>,
    pub scenario: Scenario,
    /// All of `features` on (stats, top, pause, rename). mock.js has them all off.
    pub all_features: bool,
    /// The first language setting ("en" in mock.js).
    pub language: Option<String>,
    /// Time steps of the timers, as a multiple (0 for tests: no waiting).
    pub instant: bool,
}

impl Options {
    /// From the command line and the environment:
    /// `--rows N` (or BENCH_ROWS), BENCH_SCENARIO (default, empty, vm, offline, docker),
    /// BENCH_FEATURES=all, BENCH_LANG (en, ko, ja, zh-CN, fil, es, vi, system).
    pub fn from_env() -> Options {
        let args: Vec<String> = std::env::args().collect();
        let rows = args
            .iter()
            .position(|a| a == "--rows")
            .and_then(|i| args.get(i + 1))
            .and_then(|v| v.parse().ok())
            .or_else(|| {
                std::env::var("BENCH_ROWS")
                    .ok()
                    .and_then(|v| v.parse().ok())
            });
        let scenario = std::env::var("BENCH_SCENARIO")
            .ok()
            .and_then(|s| Scenario::parse(&s))
            .unwrap_or_default();
        let all_features = std::env::var("BENCH_FEATURES")
            .map(|v| v == "all")
            .unwrap_or(false);
        let language = std::env::var("BENCH_LANG").ok().filter(|s| !s.is_empty());
        Options {
            rows,
            scenario,
            all_features,
            language,
            instant: false,
        }
    }
}

struct State {
    containers: Vec<Container>,
    images: Vec<Image>,
    volumes: Vec<Volume>,
    networks: Vec<Network>,
    kube: Value,
    engine: EngineInfo,
    vm: VmStatus,
    token: u64,
    selected: String,
    launch_at_login: bool,
    settings: Settings,
    docker: DockerCommand,
    logs_generation: u64,
    logs_following: bool,
}

/// The backend. Cheap to clone; all clones share one state and one event channel.
#[derive(Clone)]
pub struct Backend {
    state: Arc<Mutex<State>>,
    events: Sender<Event>,
    now: i64,
    opts: Arc<Options>,
}

fn port(private: u16, public: u16) -> Port {
    Port {
        ip: "0.0.0.0".into(),
        private_port: private,
        public_port: public,
        kind: "tcp".into(),
    }
}

fn strs(v: &[&str]) -> Vec<String> {
    v.iter().map(|s| s.to_string()).collect()
}

fn sample_containers(now: i64) -> Vec<Container> {
    let c = |id: &str,
             name: &str,
             image: &str,
             cmd: &str,
             created: i64,
             state: &str,
             status: &str,
             ports: Vec<Port>| Container {
        id: id.into(),
        names: vec![format!("/{name}")],
        image: image.into(),
        command: cmd.into(),
        created,
        state: state.into(),
        status: status.into(),
        ports,
    };
    vec![
        c(
            "a1b2c3d4e5f60718",
            "web",
            "nginx:alpine",
            "nginx -g 'daemon off;'",
            now - 7200,
            "running",
            "Up 2 hours",
            vec![port(80, 8080)],
        ),
        c(
            "b2c3d4e5f6a70819",
            "db",
            "postgres:16-alpine",
            "docker-entrypoint.sh postgres",
            now - 86400 * 3,
            "running",
            "Up 3 days",
            vec![port(5432, 5432)],
        ),
        c(
            "c3d4e5f6a7b8091a",
            "cache",
            "redis:7-alpine",
            "redis-server",
            now - 86400 * 3,
            "running",
            "Up 3 days",
            vec![port(6379, 0)],
        ),
        c(
            "d4e5f6a7b8c9102b",
            "worker",
            "registry.example.com/team/worker:1.4.2",
            "/app/worker --queue jobs",
            now - 3600 * 5,
            "exited",
            "Exited (1) 4 hours ago",
            vec![],
        ),
        c(
            "e5f6a7b8c9d0213c",
            "migrate",
            "myapp:1.4",
            "./migrate up",
            now - 86400 * 9,
            "exited",
            "Exited (0) 9 days ago",
            vec![],
        ),
    ]
}

fn sample_images(now: i64) -> Vec<Image> {
    let i = |id: &str, tag: &str, days: i64, size: u64, containers: i64| Image {
        id: id.into(),
        repo_tags: vec![tag.into()],
        created: now - 86400 * days,
        size,
        containers,
    };
    vec![
        i("sha256:9d1f6a0c3e2b44aa", "nginx:alpine", 12, 52_400_000, 1),
        i(
            "sha256:8c2e5b1d7f3a55bb",
            "postgres:16-alpine",
            20,
            251_000_000,
            1,
        ),
        i(
            "sha256:7b3d4c2e8a4b66cc",
            "redis:7-alpine",
            30,
            41_200_000,
            1,
        ),
        i(
            "sha256:6a4c3d1f9b5c77dd",
            "registry.example.com/team/worker:1.4.2",
            2,
            183_000_000,
            1,
        ),
        i("sha256:5f5b2e0a0c6d88ee", "alpine:3.22", 60, 8_520_000, 0),
    ]
}

fn sample_volumes(now: i64) -> Vec<Volume> {
    let v = |name: &str, days: i64| Volume {
        name: name.into(),
        driver: "local".into(),
        mountpoint: format!("/var/lib/podbag/volumes/{name}/_data"),
        created_at: rfc3339(now - 86400 * days),
    };
    vec![
        v("pgdata", 3),
        v("redis-data", 3),
        v("3f2a9c41d7e8b6a5c0f1e2d3b4a59687", 40),
    ]
}

fn sample_networks() -> Vec<Network> {
    let n = |name: &str, id: &str, driver: &str, ipam: &[(&str, &str)]| Network {
        name: name.into(),
        id: id.into(),
        driver: driver.into(),
        scope: "local".into(),
        ipam: ipam
            .iter()
            .map(|(s, g)| IpamConfig {
                subnet: s.to_string(),
                gateway: g.to_string(),
            })
            .collect(),
    };
    vec![
        n(
            "bridge",
            "4e1c0b8a2f6d9e7c",
            "bridge",
            &[("10.77.0.0/16", "10.77.0.1")],
        ),
        n(
            "app",
            "5f2d1c9b3a7e0f8d",
            "bridge",
            &[("10.77.1.0/24", "10.77.1.1")],
        ),
        n("host", "6a3e2d0c4b8f1a9e", "host", &[]),
        n("none", "7b4f3e1d5c9a2b0f", "null", &[]),
    ]
}

fn sample_kube() -> Value {
    json!({
        "pods": [
            { "metadata": { "name": "web", "namespace": "default" }, "spec": { "containers": [{ "name": "nginx" }], "nodeName": "worker-1" }, "status": { "phase": "Running", "containerStatuses": [{ "name": "nginx", "ready": true }] } },
            { "metadata": { "name": "web", "namespace": "staging" }, "spec": { "containers": [{ "name": "nginx" }] }, "status": { "phase": "Pending" } }
        ],
        "deployments": [
            { "metadata": { "name": "frontend", "namespace": "default" }, "spec": { "replicas": 3, "template": { "spec": { "containers": [{ "image": "nginx:alpine" }] } } }, "status": { "readyReplicas": 3 } }
        ],
        "claims": [
            { "metadata": { "name": "postgres-data", "namespace": "default" }, "spec": { "storageClassName": "standard" }, "status": { "phase": "Bound", "capacity": { "storage": "20Gi" } } }
        ],
        "services": [
            { "metadata": { "name": "frontend", "namespace": "default" }, "spec": { "type": "NodePort", "clusterIP": "10.43.0.80", "ports": [{ "port": 80, "nodePort": 30080, "protocol": "TCP" }] } }
        ]
    })
}

const LIMITS: VmLimits = VmLimits {
    cpus_min: 1,
    cpus_max: 10,
    memory_min_mib: 1024,
    memory_max_mib: 20480,
    mac_memory_mib: 24576,
};

fn running_vm() -> VmStatus {
    VmStatus {
        platform: "macos".into(),
        state: "running".into(),
        resources_editable: true,
        in_use: Some(VmResources {
            cpus: Some(4),
            memory_mib: Some(4096),
            idle_seconds: Some(300),
        }),
        next: VmResources {
            cpus: Some(4),
            memory_mib: Some(6144),
            idle_seconds: Some(300),
        },
        saved: VmResources {
            cpus: None,
            memory_mib: Some(6144),
            idle_seconds: None,
        },
        overridden_by: vec![],
        pending: true,
        limits: LIMITS,
        uptime_seconds: Some(7560),
        containers: Some(3),
        cpu_percent: Some(12.5),
        memory_used_mib: Some(1350),
        memory_total_mib: Some(3900),
        disk: Some(VmDisk {
            path: "/Users/me/.podbag/vm/disk.img".into(),
            allocated_bytes: 5_800_000_000,
            size_bytes: 68_719_476_736,
        }),
    }
}

fn stopped_vm() -> VmStatus {
    VmStatus {
        state: "stopped".into(),
        in_use: None,
        next: VmResources {
            cpus: Some(4),
            memory_mib: Some(4096),
            idle_seconds: Some(300),
        },
        saved: VmResources {
            cpus: Some(4),
            memory_mib: Some(4096),
            idle_seconds: None,
        },
        pending: false,
        uptime_seconds: None,
        containers: None,
        cpu_percent: None,
        memory_used_mib: None,
        memory_total_mib: None,
        disk: Some(VmDisk {
            path: "/Users/me/.podbag/vm/disk.img".into(),
            allocated_bytes: 3_400_000_000,
            size_bytes: 68_719_476_736,
        }),
        ..running_vm()
    }
}

/// mock.js `engine` for a scenario and the selected engine.
fn engine_info(scenario: Scenario, selected: &str) -> EngineInfo {
    let docker = scenario == Scenario::Docker;
    let mut e = EngineInfo {
        platform: "macos".into(),
        engine: if docker { "docker" } else { "podbag" }.into(),
        engine_name: if docker { "Docker" } else { "podbag" }.into(),
        shell: true,
        endpoint: "unix:///Users/me/.podbag/run/docker.sock".into(),
        reachable: !matches!(scenario, Scenario::Offline | Scenario::VmStopped),
        vm: Some(if scenario == Scenario::VmStopped { "stopped" } else { "running" }.into()),
        version: Some("podbag 0.1.0 (API 1.47)".into()),
        error: match scenario {
            Scenario::VmStopped => Some("vm-stopped".into()),
            Scenario::Offline => Some("cannot connect to unix:///Users/me/.podbag/run/docker.sock: No such file or directory".into()),
            _ => None,
        },
    };
    if docker {
        e.endpoint = "unix:///Users/me/.docker/run/docker.sock".into();
        e.vm = None;
        e.version = Some("Docker Desktop 4.50.0 29.0.1 (API 1.52)".into());
    }
    if scenario == Scenario::Offline {
        e.platform = "linux".into();
        e.vm = None;
        e.endpoint = "unix:///run/user/1000/podbag/docker.sock".into();
    }
    if !selected.is_empty() && selected != e.engine {
        e.engine = selected.into();
        e.engine_name = if selected == "kiri" {
            "Kiri".into()
        } else {
            selected.into()
        };
        e.endpoint = if selected == "kiri" {
            "unix:///Users/me/.kiri/run/docker.sock".into()
        } else {
            selected.into()
        };
        e.vm = None;
        e.version = Some(selected.into());
    }
    e
}

fn log_lines() -> Vec<String> {
    let mut v = strs(&[
        "/docker-entrypoint.sh: Configuration complete; ready for start up",
        "2026/11/20 03:12:01 [notice] 1#1: using the \"epoll\" event method",
        "2026/11/20 03:12:01 [notice] 1#1: nginx/1.27.3",
        "2026/11/20 03:12:01 [notice] 1#1: start worker processes",
    ]);
    v.extend((0..24).map(access_line));
    v
}

fn access_line(i: usize) -> String {
    format!(
        "10.77.0.1 - - [20/Nov/2026:03:{:02}:07 +0000] \"GET /api/items?page={} HTTP/1.1\" 200 {} \"-\" \"curl/8.11.0\"",
        (14 + i) % 60,
        i + 1,
        1200 + i * 37
    )
}

fn hub() -> Vec<HubResult> {
    let r = |name: &str, d: &str, stars: u64, official: bool| HubResult {
        name: name.into(),
        description: d.into(),
        star_count: stars,
        is_official: official,
    };
    vec![
        r("nginx", "Official build of Nginx.", 21034, true),
        r(
            "nginxinc/nginx-unprivileged",
            "Unprivileged NGINX Dockerfiles",
            172,
            false,
        ),
        r(
            "nginx/nginx-ingress",
            "NGINX and NGINX Plus Ingress Controllers for Kubernetes",
            109,
            false,
        ),
        r(
            "bitnami/nginx",
            "Bitnami container image for NGINX",
            197,
            false,
        ),
    ]
}

/// mock.js `registries` (id, label, host, needsHost, account, hint, hostExample).
const REGISTRIES: &[(
    &str,
    &str,
    &str,
    bool,
    Option<&str>,
    Option<&str>,
    Option<&str>,
)] = &[
    (
        "dockerhub",
        "Docker Hub",
        "docker.io",
        false,
        None,
        None,
        None,
    ),
    (
        "github",
        "GitHub",
        "ghcr.io",
        false,
        Some("octocat"),
        None,
        None,
    ),
    (
        "ecr",
        "Amazon ECR",
        "",
        true,
        None,
        Some(
            "aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <account>.dkr.ecr.<region>.amazonaws.com",
        ),
        Some("123456789012.dkr.ecr.us-east-1.amazonaws.com"),
    ),
    ("quay", "Quay.io", "quay.io", false, None, None, None),
    (
        "gar",
        "Google Artifact Registry",
        "",
        true,
        None,
        Some("gcloud auth configure-docker <region>-docker.pkg.dev"),
        Some("us-docker.pkg.dev"),
    ),
    (
        "gitlab",
        "GitLab",
        "registry.gitlab.com",
        false,
        None,
        None,
        None,
    ),
    (
        "acr",
        "Azure Container Registry",
        "",
        true,
        None,
        Some("az acr login --name <registry-name>"),
        Some("contoso.azurecr.io"),
    ),
    (
        "ecr-public",
        "Amazon ECR Public",
        "public.ecr.aws",
        false,
        None,
        None,
        Some("public.ecr.aws"),
    ),
    (
        "mcr",
        "Microsoft Artifact Registry",
        "mcr.microsoft.com",
        false,
        None,
        None,
        Some("mcr.microsoft.com"),
    ),
    (
        "dhi",
        "Docker Hardened Images",
        "dhi.io",
        false,
        None,
        None,
        Some("dhi.io"),
    ),
    (
        "gcr",
        "Google Artifact Registry (gcr.io)",
        "",
        true,
        None,
        None,
        Some("gcr.io"),
    ),
    (
        "digitalocean",
        "DigitalOcean Container Registry",
        "registry.digitalocean.com",
        false,
        None,
        None,
        Some("registry.digitalocean.com"),
    ),
    (
        "ocir",
        "Oracle Cloud Infrastructure Registry",
        "",
        true,
        None,
        None,
        Some("iad.ocir.io"),
    ),
    (
        "oracle",
        "Oracle Container Registry",
        "container-registry.oracle.com",
        false,
        None,
        None,
        Some("container-registry.oracle.com"),
    ),
    (
        "ibm",
        "IBM Cloud Container Registry",
        "",
        true,
        None,
        None,
        Some("us.icr.io"),
    ),
    (
        "alibaba",
        "Alibaba Cloud Container Registry",
        "",
        true,
        None,
        None,
        Some("crpi-example.cn-hangzhou.personal.cr.aliyuncs.com"),
    ),
    (
        "tencent",
        "Tencent Container Registry",
        "",
        true,
        None,
        None,
        Some("example.tencentcloudcr.com"),
    ),
    (
        "huawei",
        "Huawei Cloud SWR",
        "",
        true,
        None,
        None,
        Some("swr.cn-north-4.myhuaweicloud.com"),
    ),
    (
        "scaleway",
        "Scaleway Container Registry",
        "",
        true,
        None,
        None,
        Some("rg.fr-par.scw.cloud"),
    ),
    (
        "ovh",
        "OVHcloud Managed Private Registry",
        "",
        true,
        None,
        None,
        Some("example.container-registry.ovh.net"),
    ),
    (
        "redhat",
        "Red Hat Container Registry",
        "",
        true,
        None,
        None,
        Some("registry.redhat.io"),
    ),
    (
        "suse",
        "SUSE Registry",
        "registry.suse.com",
        false,
        None,
        None,
        Some("registry.suse.com"),
    ),
    (
        "kubernetes",
        "Kubernetes Registry",
        "registry.k8s.io",
        false,
        None,
        None,
        Some("registry.k8s.io"),
    ),
    (
        "ngc",
        "NVIDIA NGC",
        "nvcr.io",
        false,
        None,
        None,
        Some("nvcr.io"),
    ),
    (
        "chainguard",
        "Chainguard Registry",
        "cgr.dev",
        false,
        None,
        None,
        Some("cgr.dev"),
    ),
    (
        "cloudsmith",
        "Cloudsmith",
        "docker.cloudsmith.io",
        false,
        None,
        None,
        Some("docker.cloudsmith.io"),
    ),
    (
        "jfrog",
        "JFrog Artifactory",
        "",
        true,
        None,
        None,
        Some("example.jfrog.io"),
    ),
    (
        "harbor",
        "Harbor",
        "",
        true,
        None,
        None,
        Some("harbor.example.com"),
    ),
    (
        "nexus",
        "Sonatype Nexus Repository",
        "",
        true,
        None,
        None,
        Some("nexus.example.com:5000"),
    ),
    (
        "gitlab-self",
        "GitLab Self-Managed",
        "",
        true,
        None,
        None,
        Some("registry.example.com"),
    ),
    ("custom", "Other registry", "", true, None, None, None),
];

const PODBAG_CONTEXT: (&str, bool, &str, Option<&str>) =
    ("podbag", true, "podbag", Some("desktop-linux"));
const DESKTOP_CONTEXT: (&str, bool, &str, Option<&str>) =
    ("Docker Desktop", false, "desktop-linux", None);

fn docker_cmd(
    (name, is_podbag, context, previous): (&str, bool, &str, Option<&str>),
) -> DockerCommand {
    DockerCommand {
        installed: true,
        name: name.into(),
        is_podbag,
        from_env: false,
        context: context.into(),
        previous: previous.map(Into::into),
    }
}

impl Backend {
    /// A backend and the channel its events arrive on.
    pub fn new(opts: Options) -> (Backend, Receiver<Event>) {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);
        let scenario = opts.scenario;
        let mut containers = match opts.rows {
            Some(n) => rows::containers(n, now),
            None => sample_containers(now),
        };
        let mut volumes = sample_volumes(now);
        if scenario == Scenario::Empty {
            containers.clear();
            volumes.clear();
        }
        let selected = engine_info(scenario, "").engine;
        let state = State {
            containers,
            images: sample_images(now),
            volumes,
            networks: sample_networks(),
            kube: sample_kube(),
            engine: engine_info(scenario, &selected),
            vm: if scenario == Scenario::VmStopped {
                stopped_vm()
            } else {
                running_vm()
            },
            token: 1,
            selected,
            launch_at_login: false,
            settings: Settings {
                language: opts.language.clone().unwrap_or_else(|| "en".into()),
                theme: "system".into(),
                sidebar_width: 216,
                sidebar_collapsed: false,
            },
            docker: docker_cmd(PODBAG_CONTEXT),
            logs_generation: 0,
            logs_following: false,
        };
        let (tx, rx) = channel();
        (
            Backend {
                state: Arc::new(Mutex::new(state)),
                events: tx,
                now,
                opts: Arc::new(opts),
            },
            rx,
        )
    }

    fn st(&self) -> MutexGuard<'_, State> {
        self.state.lock().unwrap_or_else(|e| e.into_inner())
    }

    fn send(&self, e: Event) {
        let _ = self.events.send(e);
    }

    /// Run `f` after `ms` milliseconds on a timer thread (at once with `instant`).
    fn later(&self, ms: u64, f: impl FnOnce(&Backend) + Send + 'static) {
        let me = self.clone();
        if self.opts.instant {
            f(&me);
            return;
        }
        thread::spawn(move || {
            thread::sleep(Duration::from_millis(ms));
            f(&me);
        });
    }

    /// The time the sample data is relative to (Unix seconds).
    pub fn now(&self) -> i64 {
        self.now
    }

    pub fn options(&self) -> &Options {
        &self.opts
    }

    // ---- connection and engine ----

    pub fn connection(&self) -> Connection {
        let s = self.st();
        Connection {
            token: s.token,
            name: s.selected.clone(),
            local: s.selected == "podbag",
        }
    }

    /// Docker contexts for the engine menu.
    pub fn contexts(&self) -> Vec<String> {
        strs(&["desktop-linux", "orbstack"])
    }

    /// `start`: start the VM if it is stopped (mock.js ignores it).
    pub fn engine(&self, start: bool) -> EngineInfo {
        let mut s = self.st();
        if start && s.engine.vm.as_deref() == Some("stopped") {
            Self::set_vm_running(&mut s, true);
        }
        s.engine.clone()
    }

    /// The preferred engine (podbag, docker, podman, kiri, context:<name>, a socket).
    /// The window connects again after this (`connection`, then `engine`).
    pub fn set_engine(&self, engine: &str) -> Result<(), String> {
        let mut s = self.st();
        s.selected = engine.to_string();
        s.token += 1;
        s.engine = engine_info(self.opts.scenario, engine);
        Ok(())
    }

    // ---- lists ----

    pub fn containers(&self) -> Result<Vec<Container>, String> {
        Ok(self.st().containers.clone())
    }

    pub fn images(&self) -> Result<Vec<Image>, String> {
        Ok(self.st().images.clone())
    }

    pub fn volumes(&self) -> Result<Vec<Volume>, String> {
        Ok(self.st().volumes.clone())
    }

    pub fn networks(&self) -> Result<Vec<Network>, String> {
        Ok(self.st().networks.clone())
    }

    /// The object's details as the engine's inspect JSON (a sample, as in mock.js).
    pub fn inspect(&self, kind: Kind, id: &str) -> Result<Value, String> {
        Ok(json!({
            "Id": id, "Name": "/web", "Created": "2026-11-20T01:12:00Z",
            "State": { "Status": "running", "Running": true, "Pid": 4182, "StartedAt": "2026-11-20T01:12:01Z" },
            "Config": { "Image": "nginx:alpine", "Cmd": ["nginx", "-g", "daemon off;"], "Env": ["PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "NGINX_VERSION=1.27.3"], "Tty": false },
            "HostConfig": { "PortBindings": { "80/tcp": [{ "HostIp": "", "HostPort": "8080" }] }, "RestartPolicy": { "Name": "no" } },
            "NetworkSettings": { "IPAddress": "10.77.0.2" },
            "Kind": kind.as_str(),
        }))
    }

    pub fn features(&self, _sample: Option<&str>) -> Features {
        let on = self.opts.all_features;
        Features {
            stats: on,
            top: on,
            pause: on,
            rename: on,
        }
    }

    /// `top` or `stats` of a running container. mock.js: "not supported".
    pub fn container_json(&self, _id: &str, what: &str) -> Result<Value, String> {
        if !self.opts.all_features {
            return Err("not supported".into());
        }
        Ok(match what {
            "top" => {
                json!({ "Titles": ["PID", "USER", "TIME", "COMMAND"], "Processes": [["4182", "root", "0:00", "nginx: master process nginx -g daemon off;"], ["4210", "nginx", "0:03", "nginx: worker process"]] })
            }
            _ => {
                json!({ "cpu_percent": 0.4, "memory_usage": 9_437_184, "memory_limit": 4_294_967_296u64, "pids": 2 })
            }
        })
    }

    // ---- actions ----

    /// start, stop, restart, pause, unpause.
    pub fn act(&self, id: &str, action: &str) -> Result<(), String> {
        {
            let mut s = self.st();
            let c = s
                .containers
                .iter_mut()
                .find(|c| c.id == id)
                .ok_or_else(|| format!("No such container: {id}"))?;
            let (state, status) = match action {
                "start" | "restart" | "unpause" => ("running", "Up Less than a second"),
                "stop" => ("exited", "Exited (0) Less than a second ago"),
                "pause" => ("paused", "Up Less than a second (Paused)"),
                _ => return Err(format!("unknown action: {action}")),
            };
            c.state = state.into();
            c.status = status.into();
        }
        self.send(Event::Changed);
        Ok(())
    }

    /// `force`: stop a running container first.
    pub fn remove(&self, kind: Kind, id: &str, force: bool) -> Result<(), String> {
        {
            let mut s = self.st();
            match kind {
                Kind::Containers => {
                    let i = s
                        .containers
                        .iter()
                        .position(|c| c.id == id)
                        .ok_or_else(|| format!("No such container: {id}"))?;
                    if s.containers[i].is_up() && !force {
                        return Err(format!(
                            "cannot remove container {}: container is running: stop the container before removing or force remove",
                            s.containers[i].name()
                        ));
                    }
                    s.containers.remove(i);
                }
                Kind::Images => {
                    let i = s
                        .images
                        .iter()
                        .position(|o| o.id == id)
                        .ok_or_else(|| format!("No such image: {id}"))?;
                    s.images.remove(i);
                }
                Kind::Volumes => {
                    let i = s
                        .volumes
                        .iter()
                        .position(|o| o.name == id)
                        .ok_or_else(|| format!("No such volume: {id}"))?;
                    s.volumes.remove(i);
                }
                Kind::Networks => {
                    let i = s
                        .networks
                        .iter()
                        .position(|o| o.id == id)
                        .ok_or_else(|| format!("No such network: {id}"))?;
                    if s.networks[i].builtin() {
                        return Err(format!(
                            "{} is a pre-defined network and cannot be removed",
                            s.networks[i].name
                        ));
                    }
                    s.networks.remove(i);
                }
            }
        }
        self.send(Event::Changed);
        Ok(())
    }

    /// mock.js: always 2 objects and 61 MB; the lists stay.
    pub fn prune(&self, _kind: Kind) -> Result<PruneResult, String> {
        Ok(PruneResult {
            count: 2,
            bytes: 61_000_000,
        })
    }

    pub fn rename(&self, id: &str, name: &str) -> Result<(), String> {
        {
            let mut s = self.st();
            let new = format!("/{}", name.trim_start_matches('/'));
            if s.containers
                .iter()
                .any(|c| c.id != id && c.names.first() == Some(&new))
            {
                return Err(format!(
                    "Conflict. The container name \"{new}\" is already in use"
                ));
            }
            let c = s
                .containers
                .iter_mut()
                .find(|c| c.id == id)
                .ok_or_else(|| format!("No such container: {id}"))?;
            c.names = vec![new];
        }
        self.send(Event::Changed);
        Ok(())
    }

    pub fn create_volume(&self, name: &str) -> Result<(), String> {
        {
            let mut s = self.st();
            if s.volumes.iter().any(|v| v.name == name) {
                return Err(format!("volume {name} already exists"));
            }
            // mock.js pushes only Name and Driver.
            s.volumes.push(Volume {
                name: name.into(),
                driver: "local".into(),
                mountpoint: String::new(),
                created_at: String::new(),
            });
        }
        self.send(Event::Changed);
        Ok(())
    }

    pub fn open_shell(&self, _id: &str) -> Result<(), String> {
        Ok(())
    }

    /// "plain" or "upgrade".
    pub fn open_terminal(&self, _what: &str) -> Result<(), String> {
        Ok(())
    }

    // ---- logs and events ----

    /// Follow a container's logs: an `Event::Logs` with the sample lines after 30 ms,
    /// then one new line a second until `logs_stop`. Returns the generation.
    pub fn logs_start(&self, _id: &str) -> u64 {
        let generation = {
            let mut s = self.st();
            s.logs_generation += 1;
            s.logs_following = true;
            s.logs_generation
        };
        self.later(30, move |b| {
            b.send(Event::Logs {
                generation,
                lines: log_lines(),
            });
            if b.opts.instant {
                return;
            }
            let mut i = 24;
            loop {
                thread::sleep(Duration::from_secs(1));
                let s = b.st();
                if !s.logs_following || s.logs_generation != generation {
                    break;
                }
                drop(s);
                b.send(Event::Logs {
                    generation,
                    lines: vec![access_line(i)],
                });
                i += 1;
            }
        });
        generation
    }

    pub fn logs_stop(&self) {
        self.st().logs_following = false;
    }

    /// The engine's event stream: `Event::Live` after 10 ms.
    pub fn watch(&self, on: bool) {
        self.later(10, move |b| b.send(Event::Live(on)));
    }

    // ---- images ----

    /// Pull an image: `Event::PullProgress` lines, then `Event::PullDone`.
    /// (mock.js never finishes a pull.) A name with "notfound" fails.
    pub fn pull(&self, image: &str, location: Option<&str>, host: Option<&str>) {
        let host = host
            .filter(|h| !h.is_empty())
            .map(str::to_string)
            .unwrap_or_else(|| match location {
                None | Some("dockerhub") => "docker.io".into(),
                Some(id) => REGISTRIES
                    .iter()
                    .find(|r| r.0 == id)
                    .map(|r| r.2.to_string())
                    .unwrap_or_default(),
            });
        let image = image.to_string();
        let reference = if image.contains('/')
            && image
                .split('/')
                .next()
                .is_some_and(|h| h.contains('.') || h.contains(':'))
        {
            image.clone()
        } else if host == "docker.io" && !image.contains('/') {
            format!("docker.io/library/{image}")
        } else {
            format!("{host}/{image}")
        };
        let reference = if reference
            .rsplit('/')
            .next()
            .is_some_and(|last| last.contains(':') || last.contains('@'))
        {
            reference
        } else {
            format!("{reference}:latest")
        };
        let lines = vec![
            format!("Trying to pull {reference}..."),
            "Getting image source signatures".to_string(),
            "Copying blob sha256:4abcf2066143 done".to_string(),
            "Copying blob sha256:9b3977197b4f done".to_string(),
            "Copying config sha256:5e8f1c2d3a4b done".to_string(),
            "Writing manifest to image destination".to_string(),
        ];
        self.later(150, move |b| {
            for (i, line) in lines.into_iter().enumerate() {
                if i > 0 && !b.opts.instant {
                    thread::sleep(Duration::from_millis(220));
                }
                if i == 1 && image.contains("notfound") {
                    b.send(Event::PullDone(Err(format!(
                        "{reference}: manifest unknown"
                    ))));
                    return;
                }
                b.send(Event::PullProgress(line));
            }
            {
                let mut s = b.st();
                let tag = reference
                    .strip_prefix("docker.io/library/")
                    .or_else(|| reference.strip_prefix("docker.io/"))
                    .unwrap_or(&reference)
                    .to_string();
                if !s.images.iter().any(|i| i.repo_tags.contains(&tag)) {
                    let n = s.images.len() as u64;
                    s.images.push(Image {
                        id: format!("sha256:{:016x}", 0x4c0f_fee0_0000_0000u64 + n),
                        repo_tags: vec![tag],
                        created: b.now - 86400,
                        size: 31_400_000,
                        containers: 0,
                    });
                }
            }
            b.send(Event::PullDone(Ok(reference)));
            b.send(Event::Changed);
        });
    }

    /// Docker Hub search.
    pub fn search(&self, term: &str) -> SearchResult {
        SearchResult {
            supported: true,
            error: None,
            results: hub()
                .into_iter()
                .filter(|r| r.name.contains(term))
                .collect(),
        }
    }

    /// The places to pull from. `hosts`: (registry id, host) the user gave.
    pub fn registries(&self, hosts: &[(String, String)]) -> Vec<Registry> {
        REGISTRIES
            .iter()
            .map(|&(id, label, host, needs_host, account, hint, example)| {
                let host = hosts
                    .iter()
                    .find(|(i, _)| i == id)
                    .map(|(_, h)| h.clone())
                    .unwrap_or_else(|| host.to_string());
                let hint = if id == "acr" && !host.is_empty() {
                    let first = host.split(['.', '-']).next().unwrap_or("");
                    Some(format!("az acr login --name {first}"))
                } else {
                    hint.map(Into::into)
                };
                Registry {
                    id: id.into(),
                    label: label.into(),
                    host,
                    host_example: example.map(Into::into),
                    needs_host,
                    account: account.map(Into::into),
                    hint,
                }
            })
            .collect()
    }

    /// Images in Docker Desktop, for "Import from Docker".
    pub fn docker_images(&self) -> Vec<DockerImage> {
        let d = |name: &str, size: u64, registry: &str| DockerImage {
            name: name.into(),
            size,
            registry: registry.into(),
        };
        vec![
            d("nginx:alpine", 52_400_000, "dockerhub"),
            d("mysql:8.4", 603_000_000, "dockerhub"),
            d("ghcr.io/example/worker:1.4", 183_000_000, "github"),
            d(
                "demo-registry.cn-shanghai.cr.aliyuncs.com/team/api:2",
                76_000_000,
                "alibaba",
            ),
            d("contoso.azurecr.io/team/api:2", 84_000_000, "acr"),
            d(
                "registry.example.com/team/worker:1.4.2",
                183_000_000,
                "custom",
            ),
        ]
    }

    pub fn import_images(&self, _names: &[String]) -> Result<(), String> {
        Ok(())
    }

    // ---- the docker command ----

    pub fn docker_command(&self) -> Option<DockerCommand> {
        Some(self.st().docker.clone())
    }

    /// "use" (point docker at podbag) or "back". `Event::DockerSwitching` now,
    /// `Event::DockerChanged` after 650 ms.
    pub fn docker_switch(&self, to: &str) {
        self.send(Event::DockerSwitching(to.to_string()));
        let to = to.to_string();
        self.later(650, move |b| {
            let d = docker_cmd(if to == "use" {
                PODBAG_CONTEXT
            } else {
                DESKTOP_CONTEXT
            });
            b.st().docker = d.clone();
            b.send(Event::DockerChanged(d));
        });
    }

    // ---- the VM ----

    fn set_vm_running(s: &mut State, on: bool) {
        s.engine.vm = Some(if on { "running" } else { "stopped" }.into());
        s.engine.reachable = on;
        s.engine.error = if on { None } else { Some("vm-stopped".into()) };
        let keep = (s.vm.next, s.vm.saved, s.vm.overridden_by.clone());
        s.vm = if on {
            VmStatus {
                in_use: Some(keep.0),
                next: keep.0,
                pending: false,
                uptime_seconds: Some(0),
                ..running_vm()
            }
        } else {
            VmStatus {
                next: keep.0,
                ..stopped_vm()
            }
        };
        s.vm.saved = keep.1;
        s.vm.overridden_by = keep.2;
    }

    /// start, stop, restart. Sends `Event::EngineChanged`.
    pub fn vm(&self, action: &str) -> Result<(), String> {
        {
            let mut s = self.st();
            Self::set_vm_running(&mut s, action != "stop");
        }
        self.send(Event::EngineChanged(action.to_string()));
        Ok(())
    }

    /// None without a VM (Docker, Linux).
    pub fn vm_status(&self) -> Option<VmStatus> {
        let s = self.st();
        if self.opts.scenario == Scenario::Docker || s.engine.platform == "linux" {
            return None;
        }
        Some(s.vm.clone())
    }

    /// Save VM resources; `restart` restarts a running VM with them.
    pub fn vm_set(&self, change: VmChange) -> Result<String, String> {
        let mut s = self.st();
        let l = s.vm.limits;
        if let Some(c) = change.cpus {
            if c < l.cpus_min || c > l.cpus_max {
                return Err(format!(
                    "CPUs must be from {} to {}",
                    l.cpus_min, l.cpus_max
                ));
            }
            s.vm.next.cpus = Some(c);
            s.vm.saved.cpus = Some(c);
        }
        if let Some(m) = change.memory_mib {
            if m < l.memory_min_mib || m > l.memory_max_mib {
                return Err(format!(
                    "memory must be from {} to {} MiB",
                    l.memory_min_mib, l.memory_max_mib
                ));
            }
            s.vm.next.memory_mib = Some(m);
            s.vm.saved.memory_mib = Some(m);
        }
        if let Some(i) = change.idle_seconds {
            s.vm.next.idle_seconds = Some(i);
            s.vm.saved.idle_seconds = Some(i);
        }
        let running = s.vm.state == "running";
        if running && change.restart {
            s.vm.in_use = Some(s.vm.next);
            s.vm.uptime_seconds = Some(0);
        }
        s.vm.pending = running && s.vm.in_use != Some(s.vm.next);
        Ok("Saved.".into())
    }

    // ---- Kubernetes ----

    pub fn kube_contexts(&self) -> Result<Vec<String>, String> {
        Ok(strs(&["dev", "staging"]))
    }

    fn kube_items(&self, kind: KubeKind, all: bool) -> Vec<Value> {
        let s = self.st();
        s.kube[kind.as_str()]
            .as_array()
            .map(|a| {
                a.iter()
                    .filter(|i| all || i["metadata"]["namespace"] == "default")
                    .cloned()
                    .collect()
            })
            .unwrap_or_default()
    }

    pub fn kube_counts(
        &self,
        _context: Option<&str>,
        all_namespaces: bool,
    ) -> Result<KubeCounts, String> {
        let n = |k| self.kube_items(k, all_namespaces).len();
        Ok(KubeCounts {
            pods: n(KubeKind::Pods),
            services: n(KubeKind::Services),
            deployments: n(KubeKind::Deployments),
            claims: n(KubeKind::Claims),
        })
    }

    pub fn kube_list(
        &self,
        kind: KubeKind,
        all_namespaces: bool,
        context: Option<&str>,
    ) -> Result<KubeList, String> {
        Ok(KubeList {
            context: context
                .filter(|c| !c.is_empty())
                .unwrap_or("dev")
                .to_string(),
            namespace: "default".into(),
            items: self.kube_items(kind, all_namespaces),
        })
    }

    // ---- settings ----

    pub fn get_settings(&self) -> Settings {
        self.st().settings.clone()
    }

    pub fn set_settings(&self, settings: &Settings) -> Result<(), String> {
        self.st().settings = settings.clone();
        Ok(())
    }

    pub fn launch_at_login(&self) -> Result<bool, String> {
        Ok(self.st().launch_at_login)
    }

    pub fn set_launch_at_login(&self, on: bool) -> Result<(), String> {
        self.st().launch_at_login = on;
        Ok(())
    }

    /// Versions for the status bar (mock.js's non-settings view: up to date).
    pub fn updates(&self) -> Updates {
        Updates {
            engine: "0.1.0".into(),
            app: "0.1.0".into(),
            latest: "0.1.0".into(),
            newer: false,
            checked: self.now - 3600,
            error: None,
        }
    }
}
