//! The string tables, with the lookup rules of `desktop/ui/i18n.js`: the chosen
//! language, then English, then the key itself. `{name}` parts are filled in from vars.

use std::collections::HashMap;

/// The languages, in the order of the settings menu.
pub const LANGUAGES: [&str; 7] = ["en", "ko", "ja", "zh-CN", "fil", "es", "vi"];

fn source(lang: &str) -> Option<&'static str> {
    Some(match lang {
        "en" => include_str!("../../i18n/en.json"),
        "ko" => include_str!("../../i18n/ko.json"),
        "ja" => include_str!("../../i18n/ja.json"),
        "zh-CN" => include_str!("../../i18n/zh-CN.json"),
        "fil" => include_str!("../../i18n/fil.json"),
        "es" => include_str!("../../i18n/es.json"),
        "vi" => include_str!("../../i18n/vi.json"),
        _ => return None,
    })
}

type Table = HashMap<String, String>;

fn parse(text: &str) -> Table {
    serde_json::from_str(text).unwrap_or_default()
}

/// One of LANGUAGES for a locale tag (ko-KR, zh-Hans-CN, tl), or None.
pub fn match_tag(tag: &str) -> Option<&'static str> {
    let lower = tag.to_lowercase().replace('_', "-");
    let base = lower.split('-').next().unwrap_or("");
    match base {
        "zh" => Some("zh-CN"),
        "fil" | "tl" => Some("fil"),
        _ => LANGUAGES.iter().copied().find(|l| *l == base),
    }
}

/// The setting ("system" or a language) as a language. `system` lists the system's
/// locale tags in order of preference.
pub fn resolve(setting: &str, system: &[String]) -> &'static str {
    if let Some(l) = LANGUAGES.iter().copied().find(|l| *l == setting) {
        return l;
    }
    system.iter().find_map(|t| match_tag(t)).unwrap_or("en")
}

/// The system's locale tags (sys-locale, then LANG / LC_ALL).
pub fn system_locales() -> Vec<String> {
    let mut out: Vec<String> = sys_locale::get_locales().collect();
    for var in ["LC_ALL", "LC_MESSAGES", "LANG"] {
        if let Ok(v) = std::env::var(var) {
            if !v.is_empty() && v != "C" && v != "POSIX" {
                out.push(v);
            }
        }
    }
    out
}

pub struct I18n {
    lang: &'static str,
    english: Table,
    table: Option<Table>,
}

impl I18n {
    /// The tables for a setting ("system", "en", "ko", …).
    pub fn new(setting: &str) -> Self {
        let mut me = Self {
            lang: "en",
            english: parse(source("en").unwrap()),
            table: None,
        };
        me.load(setting);
        me
    }

    /// Tables from text, for tests: English and one other language.
    pub fn from_tables(lang: &'static str, english: &str, table: &str) -> Self {
        Self {
            lang,
            english: parse(english),
            table: Some(parse(table)),
        }
    }

    /// Switch language at runtime. Returns the language now used.
    pub fn load(&mut self, setting: &str) -> &'static str {
        self.lang = resolve(setting, &system_locales());
        self.table = if self.lang == "en" {
            None
        } else {
            source(self.lang).map(parse)
        };
        self.lang
    }

    /// The language now used.
    pub fn lang(&self) -> &'static str {
        self.lang
    }

    /// The text for key: the language's, then English, then the key.
    pub fn t(&self, key: &str) -> String {
        self.table
            .as_ref()
            .and_then(|t| t.get(key))
            .or_else(|| self.english.get(key))
            .cloned()
            .unwrap_or_else(|| key.to_string())
    }

    /// The text for key with `{name}` parts filled in.
    pub fn tv(&self, key: &str, vars: &[(&str, &dyn std::fmt::Display)]) -> String {
        let mut s = self.t(key);
        for (k, v) in vars {
            s = s.replace(&format!("{{{k}}}"), &v.to_string());
        }
        s
    }
}

/// Each language's own name ("language.name"), for the settings menu.
pub fn names() -> Vec<(&'static str, String)> {
    LANGUAGES
        .iter()
        .map(|l| {
            let name = parse(source(l).unwrap())
                .remove("language.name")
                .unwrap_or_else(|| l.to_string());
            (*l, name)
        })
        .collect()
}
