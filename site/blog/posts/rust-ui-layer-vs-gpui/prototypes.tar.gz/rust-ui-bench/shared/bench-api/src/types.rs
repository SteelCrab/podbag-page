//! The data the mock commands return. Field names follow the Docker API and mock.js;
//! `serde` renames give the same JSON text as the web app.

use serde::Serialize;

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct Port {
    #[serde(rename = "IP")]
    pub ip: String,
    #[serde(rename = "PrivatePort")]
    pub private_port: u16,
    /// 0: not published.
    #[serde(rename = "PublicPort")]
    pub public_port: u16,
    #[serde(rename = "Type")]
    pub kind: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct Container {
    pub id: String,
    pub names: Vec<String>,
    pub image: String,
    pub command: String,
    /// Unix seconds.
    pub created: i64,
    /// running, exited, created, paused, restarting, dead.
    pub state: String,
    pub status: String,
    pub ports: Vec<Port>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct Image {
    pub id: String,
    pub repo_tags: Vec<String>,
    pub created: i64,
    pub size: u64,
    pub containers: i64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct Volume {
    pub name: String,
    pub driver: String,
    /// Empty for a volume made by `create_volume` (mock.js sets none).
    pub mountpoint: String,
    /// RFC 3339 text, or empty.
    pub created_at: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct IpamConfig {
    #[serde(rename = "Subnet")]
    pub subnet: String,
    #[serde(rename = "Gateway")]
    pub gateway: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct Network {
    pub name: String,
    pub id: String,
    pub driver: String,
    pub scope: String,
    /// IPAM.Config.
    pub ipam: Vec<IpamConfig>,
}

/// The resource kinds of `list`, `remove` and `prune`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Kind {
    Containers,
    Images,
    Volumes,
    Networks,
}

impl Kind {
    pub const ALL: [Kind; 4] = [
        Kind::Containers,
        Kind::Images,
        Kind::Volumes,
        Kind::Networks,
    ];

    /// The name app.js uses ("containers", …), also the i18n key suffix.
    pub fn as_str(self) -> &'static str {
        match self {
            Kind::Containers => "containers",
            Kind::Images => "images",
            Kind::Volumes => "volumes",
            Kind::Networks => "networks",
        }
    }
}

/// The Kubernetes resources of kubernetes.js.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum KubeKind {
    Pods,
    Services,
    Deployments,
    Claims,
}

impl KubeKind {
    pub const ALL: [KubeKind; 4] = [
        KubeKind::Pods,
        KubeKind::Services,
        KubeKind::Deployments,
        KubeKind::Claims,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            KubeKind::Pods => "pods",
            KubeKind::Services => "services",
            KubeKind::Deployments => "deployments",
            KubeKind::Claims => "claims",
        }
    }
}

/// `connection`: the engine the window talks to.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Connection {
    pub token: u64,
    /// podbag, docker, podman, kiri, context:<name>, or a socket URL.
    pub name: String,
    pub local: bool,
}

/// `engine`: the engine's state.
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EngineInfo {
    /// macos, linux, windows.
    pub platform: String,
    pub engine: String,
    pub engine_name: String,
    pub shell: bool,
    pub endpoint: String,
    pub reachable: bool,
    /// running, stopped; None without a VM.
    pub vm: Option<String>,
    pub version: Option<String>,
    /// "vm-stopped" or a message.
    pub error: Option<String>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VmResources {
    pub cpus: Option<u32>,
    pub memory_mib: Option<u32>,
    pub idle_seconds: Option<u32>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VmLimits {
    pub cpus_min: u32,
    pub cpus_max: u32,
    pub memory_min_mib: u32,
    pub memory_max_mib: u32,
    pub mac_memory_mib: u32,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VmDisk {
    pub path: String,
    pub allocated_bytes: u64,
    pub size_bytes: u64,
}

/// `vm_status`: `podbag vm status --json`.
#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VmStatus {
    pub platform: String,
    /// running, standby, starting, stopped, "not set up".
    pub state: String,
    pub resources_editable: bool,
    pub in_use: Option<VmResources>,
    pub next: VmResources,
    pub saved: VmResources,
    /// PODBAG_VM_CPUS, PODBAG_VM_MEMORY, PODBAG_VM_IDLE.
    pub overridden_by: Vec<String>,
    pub pending: bool,
    pub limits: VmLimits,
    pub uptime_seconds: Option<u64>,
    pub containers: Option<u32>,
    pub cpu_percent: Option<f64>,
    pub memory_used_mib: Option<u32>,
    pub memory_total_mib: Option<u32>,
    pub disk: Option<VmDisk>,
}

/// `vm_set`: the values to change. `restart`: restart the VM now.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct VmChange {
    pub cpus: Option<u32>,
    pub memory_mib: Option<u32>,
    pub idle_seconds: Option<u32>,
    pub restart: bool,
}

/// `features`: what the engine can do beyond the basics.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Features {
    pub stats: bool,
    pub top: bool,
    pub pause: bool,
    pub rename: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PruneResult {
    pub count: u64,
    pub bytes: u64,
}

/// One Docker Hub search result.
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct HubResult {
    pub name: String,
    pub description: String,
    pub star_count: u64,
    pub is_official: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SearchResult {
    pub supported: bool,
    pub error: Option<String>,
    pub results: Vec<HubResult>,
}

/// A place to pull from (`registries`).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Registry {
    pub id: String,
    pub label: String,
    /// The host; empty when the user must give one.
    pub host: String,
    pub host_example: Option<String>,
    pub needs_host: bool,
    /// The logged-in user, if any.
    pub account: Option<String>,
    /// A cloud CLI login command, if the registry uses one.
    pub hint: Option<String>,
}

/// Where the `docker` command goes (`docker_command`).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DockerCommand {
    pub installed: bool,
    pub name: String,
    pub is_podbag: bool,
    pub from_env: bool,
    pub context: String,
    pub previous: Option<String>,
}

/// One image in Docker Desktop (`docker_images`).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DockerImage {
    pub name: String,
    pub size: u64,
    pub registry: String,
}

/// `updates`: versions and the last update check (the status bar shows them).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Updates {
    pub engine: String,
    pub app: String,
    pub latest: String,
    pub newer: bool,
    pub checked: i64,
    pub error: Option<String>,
}

/// `get_settings` / `set_settings`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Settings {
    /// "system" or one of `i18n::LANGUAGES`.
    pub language: String,
    /// system, light, dark.
    pub theme: String,
    pub sidebar_width: u32,
    pub sidebar_collapsed: bool,
}

/// `kube_list`.
#[derive(Clone, Debug, PartialEq)]
pub struct KubeList {
    pub context: String,
    pub namespace: String,
    /// Kubernetes objects as JSON (metadata, spec, status), as kubectl gives them.
    pub items: Vec<serde_json::Value>,
}

/// `kube_counts`: items per resource in the scope.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct KubeCounts {
    pub pods: usize,
    pub services: usize,
    pub deployments: usize,
    pub claims: usize,
}

impl KubeCounts {
    pub fn get(&self, kind: KubeKind) -> usize {
        match kind {
            KubeKind::Pods => self.pods,
            KubeKind::Services => self.services,
            KubeKind::Deployments => self.deployments,
            KubeKind::Claims => self.claims,
        }
    }

    pub fn total(&self) -> usize {
        self.pods + self.services + self.deployments + self.claims
    }
}

/// Events, delivered through the channel `Backend::new` returns.
#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    /// The lists changed: read them again.
    Changed,
    /// The engine's event stream is on (true) or off.
    Live(bool),
    /// New log lines of the container `logs_start` follows.
    Logs { generation: u64, lines: Vec<String> },
    /// One line of pull progress.
    PullProgress(String),
    /// The pull ended: the image reference, or an error. (The result of `pull`.)
    PullDone(Result<String, String>),
    /// The VM was started, stopped or restarted (the action): connect again.
    EngineChanged(String),
    /// The VM's state changed outside the app: running, stopped.
    VmStatus(String),
    /// `docker_switch` started: "use" or "back".
    DockerSwitching(String),
    /// `docker_switch` ended. (The result of `docker_switch`.)
    DockerChanged(DockerCommand),
}

// ---- small helpers of app.js, on the data ----

/// app.js `shortId`: the first 12 characters, without "sha256:".
pub fn short_id(id: &str) -> &str {
    let id = id.strip_prefix("sha256:").unwrap_or(id);
    let end = id
        .char_indices()
        .nth(12)
        .map(|(i, _)| i)
        .unwrap_or(id.len());
    &id[..end]
}

impl Container {
    /// app.js `containerName`.
    pub fn name(&self) -> &str {
        match self.names.first() {
            Some(n) => n.strip_prefix('/').unwrap_or(n),
            None => short_id(&self.id),
        }
    }

    /// app.js `portsText`: "8080→80/tcp, 6379/tcp".
    pub fn ports_text(&self) -> String {
        let mut seen: Vec<String> = Vec::new();
        for p in &self.ports {
            let kind = if p.kind.is_empty() { "tcp" } else { &p.kind };
            let text = if p.public_port != 0 {
                format!("{}→{}/{}", p.public_port, p.private_port, kind)
            } else {
                format!("{}/{}", p.private_port, kind)
            };
            if !seen.contains(&text) {
                seen.push(text);
            }
        }
        seen.join(", ")
    }

    /// running, paused or restarting: removing it needs force.
    pub fn is_up(&self) -> bool {
        matches!(self.state.as_str(), "running" | "paused" | "restarting")
    }
}

impl Image {
    /// app.js `imageName`: the first real tag, or the short ID.
    pub fn name(&self) -> &str {
        self.repo_tags
            .iter()
            .find(|t| t.as_str() != "<none>:<none>")
            .map(|s| s.as_str())
            .unwrap_or_else(|| short_id(&self.id))
    }
}

impl Network {
    /// bridge, host, none: they cannot be removed.
    pub fn builtin(&self) -> bool {
        matches!(self.name.as_str(), "bridge" | "host" | "none")
    }

    pub fn subnet(&self) -> &str {
        self.ipam.first().map(|c| c.subnet.as_str()).unwrap_or("")
    }

    pub fn gateway(&self) -> &str {
        self.ipam.first().map(|c| c.gateway.as_str()).unwrap_or("")
    }
}

/// Pretty JSON like `JSON.stringify(v, null, 2)`.
pub fn pretty_json<T: Serialize>(v: &T) -> String {
    serde_json::to_string_pretty(v).unwrap_or_default()
}
