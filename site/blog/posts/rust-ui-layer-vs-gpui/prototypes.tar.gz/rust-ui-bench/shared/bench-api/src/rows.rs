//! `--rows N`: the synthetic container rows of the parity prototypes
//! (`gpui-app/src/data.rs`, same generator), and the same rows as `Container`s.

use crate::types::{Container, Port};

/// One synthetic row, field for field as in `gpui-app/src/data.rs`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Row {
    pub name: String,
    pub image: &'static str,
    pub running: bool,
    pub ports: String,
    pub created: String,
    /// Lower-case text of all columns, for the search filter.
    pub hay: String,
}

const PREFIXES: [&str; 5] = ["web", "api", "db", "cache", "worker"];
const IMAGES: [&str; 5] = [
    "docker.io/library/nginx:1.27",
    "ghcr.io/example/api:2.3.1",
    "docker.io/library/postgres:16",
    "docker.io/library/redis:7.4",
    "quay.io/example/worker:0.9",
];
const INNER_PORTS: [u16; 5] = [80, 8080, 5432, 6379, 9000];

pub fn rows(n: usize) -> Vec<Row> {
    (0..n)
        .map(|i| {
            let p = i % 5;
            let running = i % 3 != 0;
            let name = format!("{}-{:05}", PREFIXES[p], i);
            let ports = if running {
                format!("127.0.0.1:{}->{}/tcp", 8000 + i % 1000, INNER_PORTS[p])
            } else {
                String::new()
            };
            let created = match i % 4 {
                0 => format!("{} minutes ago", 1 + i % 59),
                1 => format!("{} hours ago", 1 + i % 23),
                2 => format!("{} days ago", 1 + i % 6),
                _ => format!("{} weeks ago", 1 + i % 4),
            };
            let state = if running { "running" } else { "exited" };
            let hay = format!("{name}\n{}\n{state}\n{ports}\n{created}", IMAGES[p]).to_lowercase();
            Row {
                name,
                image: IMAGES[p],
                running,
                ports,
                created,
                hay,
            }
        })
        .collect()
}

/// The age of row `i` in seconds (its `created` text as a number).
fn age_secs(i: usize) -> i64 {
    let i = i as i64;
    match i % 4 {
        0 => (1 + i % 59) * 60,
        1 => (1 + i % 23) * 3600,
        2 => (1 + i % 6) * 86400,
        _ => (1 + i % 4) * 604800,
    }
}

/// The synthetic rows as containers. The ID is hex and never contains a row name,
/// so the benchmark filter (`web-0004`) matches the same rows as in the prototypes.
pub fn containers(n: usize, now: i64) -> Vec<Container> {
    rows(n)
        .into_iter()
        .enumerate()
        .map(|(i, r)| {
            let p = i % 5;
            let ports = if r.running {
                vec![Port {
                    ip: "127.0.0.1".into(),
                    private_port: INNER_PORTS[p],
                    public_port: (8000 + i % 1000) as u16,
                    kind: "tcp".into(),
                }]
            } else {
                Vec::new()
            };
            let id = format!(
                "{:016x}",
                (i as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15) | 1 << 60
            );
            Container {
                id,
                names: vec![format!("/{}", r.name)],
                image: r.image.to_string(),
                command: String::new(),
                created: now - age_secs(i),
                state: if r.running { "running" } else { "exited" }.into(),
                status: if r.running {
                    format!("Up {}", r.created.trim_end_matches(" ago"))
                } else {
                    format!("Exited (0) {}", r.created)
                },
                ports,
            }
        })
        .collect()
}
