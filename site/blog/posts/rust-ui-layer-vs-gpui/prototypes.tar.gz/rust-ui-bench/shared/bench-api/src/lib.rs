//! Shared backend of the full-port benchmark: Podbag Desktop's mocked API
//! (`desktop/preview/mock.js`), its string tables and its formatting helpers.
//! No UI types: both ports (GPUI and the own framework) use it as is.

pub mod fmt;
pub mod i18n;
pub mod mock;
pub mod rows;
pub mod types;

pub use mock::{Backend, Options, Scenario};
pub use serde_json;
pub use types::*;

#[cfg(test)]
mod tests {
    use super::*;

    fn backend(opts: Options) -> (Backend, std::sync::mpsc::Receiver<Event>) {
        Backend::new(Options {
            instant: true,
            ..opts
        })
    }

    #[test]
    fn containers_match_mock_js() {
        let (b, _) = backend(Options::default());
        assert_eq!(b.connection().name, "podbag");
        assert_eq!(b.engine(false).engine_name, "podbag");
        let list = b.containers().unwrap();
        assert_eq!(list.len(), 5);
        let web = &list[0];
        assert_eq!(web.name(), "web");
        assert_eq!(web.id, "a1b2c3d4e5f60718");
        assert_eq!(web.ports_text(), "8080→80/tcp");
        assert_eq!(web.created, b.now() - 7200);
        assert_eq!(list[2].ports_text(), "6379/tcp");
        assert_eq!(list[3].state, "exited");
        assert_eq!(short_id("sha256:9d1f6a0c3e2b44aa"), "9d1f6a0c3e2b");
    }

    #[test]
    fn commands_match_mock_js() {
        let (b, _) = backend(Options::default());
        assert_eq!(
            b.prune(Kind::Images).unwrap(),
            PruneResult {
                count: 2,
                bytes: 61_000_000
            }
        );
        assert_eq!(b.container_json("x", "top"), Err("not supported".into()));
        assert_eq!(b.features(None), Features::default());
        let s = b.search("nginx/");
        assert_eq!(s.results.len(), 1);
        assert_eq!(s.results[0].name, "nginx/nginx-ingress");
        let regs = b.registries(&[("acr".into(), "contoso.azurecr.io".into())]);
        assert_eq!(regs.len(), 31);
        let acr = regs.iter().find(|r| r.id == "acr").unwrap();
        assert_eq!(acr.hint.as_deref(), Some("az acr login --name contoso"));
        let counts = b.kube_counts(None, false).unwrap();
        assert_eq!(
            (
                counts.pods,
                counts.services,
                counts.deployments,
                counts.claims
            ),
            (1, 1, 1, 1)
        );
        assert_eq!(b.kube_counts(None, true).unwrap().pods, 2);
        let list = b.kube_list(KubeKind::Pods, true, None).unwrap();
        assert_eq!(list.context, "dev");
        assert_eq!(list.items[1]["metadata"]["namespace"], "staging");
        let inspect = b.inspect(Kind::Containers, "abc").unwrap();
        assert!(pretty_json(&inspect).starts_with("{\n  \"Id\": \"abc\",\n  \"Name\": \"/web\""));
        let vm = b.vm_status().unwrap();
        assert_eq!(
            (vm.state.as_str(), vm.next.memory_mib, vm.pending),
            ("running", Some(6144), true)
        );
    }

    #[test]
    fn actions_change_lists_and_send_events() {
        let (b, rx) = backend(Options::default());
        b.act("d4e5f6a7b8c9102b", "start").unwrap();
        assert_eq!(rx.try_recv(), Ok(Event::Changed));
        assert_eq!(b.containers().unwrap()[3].state, "running");
        assert!(
            b.remove(Kind::Containers, "a1b2c3d4e5f60718", false)
                .is_err()
        );
        b.remove(Kind::Containers, "a1b2c3d4e5f60718", true)
            .unwrap();
        assert_eq!(b.containers().unwrap().len(), 4);
        assert!(b.remove(Kind::Networks, "4e1c0b8a2f6d9e7c", false).is_err());
        b.logs_start("x");
        let _ = rx.try_recv();
        match rx.try_recv() {
            Ok(Event::Logs {
                generation: 1,
                lines,
            }) => assert_eq!(lines.len(), 28),
            other => panic!("{other:?}"),
        }
        b.pull("nginx", Some("dockerhub"), None);
        let events: Vec<Event> = rx.try_iter().collect();
        assert!(events.contains(&Event::PullDone(Ok(
            "docker.io/library/nginx:latest".into()
        ))));
        b.vm("stop").unwrap();
        assert_eq!(rx.try_recv(), Ok(Event::EngineChanged("stop".into())));
        assert!(!b.engine(false).reachable);
        assert!(b.engine(true).reachable);
    }

    #[test]
    fn i18n_fallback() {
        let i = i18n::I18n::from_tables(
            "ko",
            r#"{"a": "A {name}", "b": "B"}"#,
            r#"{"a": "가 {name}"}"#,
        );
        assert_eq!(i.tv("a", &[("name", &"x")]), "가 x");
        assert_eq!(i.t("b"), "B", "English when the language has no text");
        assert_eq!(
            i.t("missing.key"),
            "missing.key",
            "the key when no table has it"
        );
        assert_eq!(i18n::match_tag("ko-KR"), Some("ko"));
        assert_eq!(i18n::match_tag("zh_Hans_CN"), Some("zh-CN"));
        assert_eq!(i18n::match_tag("tl"), Some("fil"));
        assert_eq!(i18n::match_tag("de-DE"), None);
        assert_eq!(
            i18n::resolve("system", &["de-DE".into(), "ja-JP".into()]),
            "ja"
        );
        assert_eq!(i18n::resolve("system", &["de-DE".into()]), "en");
        let mut real = i18n::I18n::new("ko");
        assert_eq!(real.t("nav.containers"), "컨테이너");
        real.load("zh-CN");
        assert_eq!(real.t("nav.containers"), "容器");
        assert_eq!(i18n::names().len(), 7);
    }

    #[test]
    fn formatting() {
        let now = 1_000_000_000;
        assert_eq!(fmt::ago(now - 7200, now, "en"), "2 hours ago");
        assert_eq!(fmt::ago(now - 86400, now, "en"), "yesterday");
        assert_eq!(fmt::ago(now - 86400 * 3, now, "ko"), "3일 전");
        assert_eq!(fmt::ago(now - 10, now, "en"), "now");
        assert_eq!(fmt::size(52_400_000, "en"), "52.4 MB");
        assert_eq!(fmt::size(52_400_000, "es"), "52,4 MB");
        assert_eq!(fmt::mib(Some(1350), "en"), "1.3 GB");
        assert_eq!(fmt::duration(Some(7560), "en"), "2 hr 6 min");
        assert_eq!(fmt::percent(12.5, "en"), "12.5%");
        assert_eq!(
            fmt::parse_rfc3339("2026-11-20T01:12:00Z"),
            fmt::parse_rfc3339(&fmt::rfc3339(fmt::parse_rfc3339("2026-11-20T01:12:00Z")))
        );
        assert_eq!(fmt::parse_rfc3339("1970-01-02T00:00:00.000Z"), 86400);
    }
}
