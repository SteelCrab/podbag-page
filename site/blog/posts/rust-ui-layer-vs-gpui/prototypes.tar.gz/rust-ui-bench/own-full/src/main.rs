//! Podbag Desktop's window on our own UI framework (own-ui), with the shared mock
//! backend (bench-api). The full-port benchmark of experiments/gpui-bench.
//!
//! Usage: own-full [--rows N]
//! stdout: `READY <ms since main>`, `RENDER <ms>`, `FILTER <ms> <visible rows>`,
//! `VIEW <name> <ms>`. stdin: `filter <text>`, `nav <view>`, `quit`; for UI checks also
//! `click X Y`, `move X Y`, `scroll X Y DY`, `type TEXT`.
//! Env: BENCH_ROWS, BENCH_NO_FOCUS, BENCH_LOG, BENCH_SCENARIO, BENCH_LANG (see bench-api).

mod app;
mod dialogs;
mod icons;
mod theme;
mod views;

use std::io::{BufRead, Write};
use std::time::Instant;

use own_ui::ui::UiView;
use own_ui::{App, Id, Point, Synthetic, WindowOptions};

use app::{Desktop, Msg};

pub fn emit(line: String) {
    let mut out = std::io::stdout().lock();
    let _ = writeln!(out, "{line}");
    let _ = out.flush();
}

/// UI test commands on stdin: `click X Y`, `move X Y`, `scroll X Y DY`, `type TEXT`
/// (window coordinates in logical px).
fn synthetic(line: &str) -> Option<Synthetic> {
    let mut words = line.split_whitespace();
    let cmd = words.next()?;
    if cmd == "type" {
        return Some(Synthetic::Text(line.trim_start().strip_prefix("type ")?.to_string()));
    }
    let nums: Vec<f32> = words.filter_map(|w| w.parse().ok()).collect();
    let at = |i: usize| Point { x: nums[i], y: nums[i + 1] };
    match (cmd, nums.len()) {
        ("click", 2) => Some(Synthetic::Click(at(0))),
        ("move", 2) => Some(Synthetic::Move(at(0))),
        ("scroll", 3) => Some(Synthetic::Scroll(at(0), nums[2])),
        _ => None,
    }
}

fn main() {
    let t0 = Instant::now();
    let ui = App::<Msg>::new();
    icons::install();
    let (backend, events) = bench_api::Backend::new(bench_api::Options::from_env());

    let proxy = ui.proxy();
    std::thread::spawn(move || {
        for line in std::io::stdin().lock().lines() {
            let Ok(line) = line else { break };
            let sent = match synthetic(&line) {
                Some(s) => proxy.synthetic(s),
                None => proxy.send(Msg::Stdin(line)),
            };
            if !sent {
                break;
            }
        }
    });
    // Backend events come from timer threads; forward them to wake the event loop.
    let proxy = ui.proxy();
    std::thread::spawn(move || {
        while let Ok(ev) = events.recv() {
            if !proxy.send(Msg::Api(ev)) {
                break;
            }
        }
    });

    let opts = WindowOptions {
        title: "podbag (own-full)".into(),
        width: 1200.,
        height: 800.,
        min_size: Some((640., 480.)),
        // BENCH_NO_FOCUS: same switch as the other prototypes (the containers search box).
        focus: std::env::var_os("BENCH_NO_FOCUS").is_none().then(|| Id::of(("search", 0usize))),
        debug: std::env::var_os("BENCH_LOG").is_some(),
    };
    ui.run(opts, move || UiView::new(Desktop::new(backend, t0)));
}
