//! Modal dialogs of app.js and kubernetes.js: confirm, ask (one line of text), choose
//! (several answers) and the Kubernetes object viewer.

use bench_api::{Kind, VmChange};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, Kind as ButtonKind};
use own_ui::widgets::dialog::{buttons_row, dialog};
use own_ui::widgets::logs::{LogView, log_view};
use own_ui::widgets::text_field::text_field;
use own_ui::winit::keyboard::NamedKey;
use own_ui::{Id, Rect, TextInput, TextStyle};

use crate::app::Desktop;

/// What a confirmed dialog does.
pub enum Then {
    Remove { kind: Kind, id: String, name: String, force: bool },
    Prune(Kind),
    Vm(String),
    DockerUse,
}

/// What an ask dialog's text is for.
pub enum AskFor {
    Rename(String),
    CreateVolume,
    Socket,
}

pub enum Dialog {
    Confirm { title: String, text: String, yes: String, danger: bool, then: Then },
    Ask { title: String, label: String, input: TextInput, ok: String, error: String, then: AskFor },
    Choose { title: String, text: String, later: String, now: String, cancel: String, danger: bool, change: VmChange },
    KubeObject { title: String, context: String, lines: LogView },
}

impl Dialog {
    pub fn confirm(d: &Desktop, text: String, yes: Option<String>, then: Then) -> Dialog {
        Dialog::Confirm {
            title: d.t("confirm.title"),
            text,
            yes: yes.unwrap_or_else(|| d.t("action.remove")),
            danger: true,
            then,
        }
    }

    pub fn ask(title: String, label: String, value: &str, placeholder: &str, ok: String, then: AskFor) -> Dialog {
        let mut input = TextInput::new(Id::of("ask-input"), placeholder, TextStyle::new(14.).line_height(20.), own_ui::Color::TRANSPARENT);
        input.set_content(value);
        input.select_all();
        Dialog::Ask { title, label, input, ok, error: String::new(), then }
    }
}

enum Outcome {
    Open,
    Close,
    Yes,
    Later,
}

const ID: &str = "dialog";

pub fn paint(d: &mut Desktop, ui: &mut Ui) {
    let Some(mut dlg) = d.dialog.take() else { return };
    let cancel_label = d.t("action.cancel");
    let back_label = d.t("action.back");
    let escape = ui.key_pressed(NamedKey::Escape).is_some();
    let mut outcome = if escape { Outcome::Close } else { Outcome::Open };
    let t = ui.theme;
    let id = Id::of(ID);
    match &mut dlg {
        Dialog::Confirm { title, text, yes, danger, .. } => {
            let enter = ui.key_pressed(NamedKey::Enter).is_some();
            dialog(ui, id, 440., |ui, r| {
                let mut y = r.y;
                y += heading(ui, r.x, y, r.w, title) + 10.;
                y += ui.paragraph(r.x, y, r.w, text, ui.style(), t.ink2) + 16.;
                let widths = [button::width(ui, yes, None, false), button::width(ui, &cancel_label, None, false)];
                let rects = buttons_row(r.x, y, r.w, &widths);
                let kind = if *danger { ButtonKind::Danger } else { ButtonKind::Primary };
                if button::button(ui, id.with("yes"), rects[0], yes, None, kind, true) || enter {
                    outcome = Outcome::Yes;
                }
                if button::button(ui, id.with("cancel"), rects[1], &cancel_label, None, ButtonKind::Normal, true) {
                    outcome = Outcome::Close;
                }
                y + 32. - r.y
            });
        }
        Dialog::Ask { title, label, input, ok, error, .. } => {
            ui.focus(Some(input.id));
            let enter = ui.key_pressed(NamedKey::Enter).is_some();
            dialog(ui, id, 440., |ui, r| {
                let mut y = r.y;
                y += heading(ui, r.x, y, r.w, title) + 10.;
                let style = ui.style().with_size(13.).weight(600);
                ui.p.label(Rect::new(r.x, y, r.w, 18.), label, style, t.ink);
                y += 24.;
                text_field(ui, input, Rect::new(r.x, y, r.w, 34.), None, true);
                y += 44.;
                if !error.is_empty() {
                    let style = TextStyle::new(12.5).mono().line_height(18.);
                    y += ui.paragraph(r.x, y, r.w, error, style, t.red) + 6.;
                }
                let widths = [button::width(ui, ok, None, false), button::width(ui, &cancel_label, None, false)];
                let rects = buttons_row(r.x, y, r.w, &widths);
                if button::button(ui, id.with("ok"), rects[0], ok, None, ButtonKind::Primary, true) || enter {
                    outcome = Outcome::Yes;
                }
                if button::button(ui, id.with("cancel"), rects[1], &cancel_label, None, ButtonKind::Normal, true) {
                    outcome = Outcome::Close;
                }
                y + 32. - r.y
            });
        }
        Dialog::Choose { title, text, later, now, cancel, danger, .. } => {
            dialog(ui, id, 440., |ui, r| {
                let mut y = r.y;
                y += heading(ui, r.x, y, r.w, title) + 10.;
                y += ui.paragraph(r.x, y, r.w, text, ui.style(), t.ink2) + 16.;
                let widths = [button::width(ui, now, None, false), button::width(ui, later, None, false), button::width(ui, cancel, None, false)];
                let rects = buttons_row(r.x, y, r.w, &widths);
                let kind = if *danger { ButtonKind::Danger } else { ButtonKind::Primary };
                if button::button(ui, id.with("now"), rects[0], now, None, kind, true) {
                    outcome = Outcome::Yes;
                }
                if button::button(ui, id.with("later"), rects[1], later, None, ButtonKind::Normal, true) {
                    outcome = Outcome::Later;
                }
                if button::button(ui, id.with("cancel"), rects[2], cancel, None, ButtonKind::Normal, true) {
                    outcome = Outcome::Close;
                }
                y + 32. - r.y
            });
        }
        Dialog::KubeObject { title, context, lines } => {
            let width = (ui.bounds().w - 48.).min(720.);
            let pre_h = (ui.bounds().h * 0.6).min(lines.lines.len() as f32 * 19. + 26.);
            dialog(ui, id, width, |ui, r| {
                let mut y = r.y;
                y += heading(ui, r.x, y, r.w, title) + 10.;
                y += ui.paragraph(r.x, y, r.w, context, ui.style(), t.ink2) + 10.;
                log_view(ui, id.with("json"), Rect::new(r.x, y, r.w, pre_h), lines, "");
                y += pre_h + 16.;
                let w = button::width(ui, &back_label, None, false);
                let rects = buttons_row(r.x, y, r.w, &[w]);
                if button::button(ui, id.with("back"), rects[0], &back_label, None, ButtonKind::Normal, true) {
                    outcome = Outcome::Close;
                }
                y + 32. - r.y
            });
        }
    }
    match outcome {
        Outcome::Open => d.dialog = Some(dlg),
        Outcome::Close => ui.focus(None),
        Outcome::Yes | Outcome::Later => finish(d, ui, dlg, matches!(outcome, Outcome::Yes)),
    }
}

fn heading(ui: &mut Ui, x: f32, y: f32, w: f32, text: &str) -> f32 {
    let style = ui.style().with_size(16.).weight(700);
    let ink = ui.theme.ink;
    ui.paragraph(x, y, w, text, style, ink)
}

fn finish(d: &mut Desktop, ui: &mut Ui, dlg: Dialog, yes: bool) {
    match dlg {
        Dialog::Confirm { then, .. } => match then {
            Then::Remove { kind, id, name, force } => d.remove(kind, &id, &name, force),
            Then::Prune(kind) => d.prune(kind),
            Then::Vm(action) => d.run_vm_action(&action),
            Then::DockerUse => d.api.docker_switch("use"),
        },
        Dialog::Ask { title, label, mut input, ok, then, .. } => {
            let text = input.content.trim().to_string();
            if text.is_empty() {
                d.dialog = Some(Dialog::Ask { title, label, input, ok, error: String::new(), then });
                return;
            }
            let result = match &then {
                AskFor::Rename(id) => d.api.rename(id, &text).map(|()| d.tv("done.rename", &[("name", &text)])),
                AskFor::CreateVolume => d.api.create_volume(&text).map(|()| String::new()),
                AskFor::Socket => d.api.set_engine(&text).map(|()| String::new()),
            };
            match result {
                Ok(done) => {
                    if !done.is_empty() {
                        d.toasts.push(done, false);
                    }
                    if matches!(then, AskFor::Socket) {
                        d.reconnect();
                    }
                    d.refresh_soon();
                    ui.focus(None);
                }
                Err(error) => {
                    input.select_all();
                    d.dialog = Some(Dialog::Ask { title, label, input, ok, error, then });
                }
            }
        }
        Dialog::Choose { mut change, .. } => {
            change.restart = yes;
            crate::views::settings::save_vm(d, change);
        }
        Dialog::KubeObject { .. } => {}
    }
}
