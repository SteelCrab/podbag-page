//! An object's page: header with actions, tabs, and the info, logs or inspect panel.

use bench_api::{Kind, fmt, pretty_json};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, IconKind};
use own_ui::widgets::checkbox;
use own_ui::widgets::logs::{follow_now, log_view};
use own_ui::widgets::scroll::scroll_view;
use own_ui::widgets::tabs::tabs;
use own_ui::{Id, Rect, TextStyle};

use crate::app::{Desktop, Tab};
use crate::icons::Icon;
use crate::views::resources::{object_name, row_actions};
use crate::views::{chip, fields};

pub fn paint(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    let t = ui.theme;
    let Some((kind, id, tab)) = d.detail.as_ref().map(|x| (x.kind, x.id.clone(), x.tab)) else { return };
    let Some(i) = index_of(d, kind, &id) else {
        d.close_detail();
        return;
    };
    let mut r = r;
    let bar = r.cut_top(62.);
    ui.p.border_bottom(bar, t.line);
    let inner = bar.inset(12., 0., 20., 1.);
    if button::icon_button(ui, Id::of("detail-back"), Rect::new(inner.x, inner.y + (inner.h - 30.) / 2., 30., 30.), Icon::Back.id(), IconKind::Plain, true) {
        d.close_detail();
        return;
    }
    // Actions at the right; the title takes what is left.
    let actions_w = 6. * 32.;
    let actions = Rect::new(inner.right() - actions_w, inner.y, actions_w, inner.h);
    row_actions(d, ui, kind, i, actions, Id::of("detail-actions"), true);
    if d.detail.is_none() {
        return;
    }
    let name = object_name(d, kind, i);
    let style = ui.style().with_size(18.).weight(700);
    let max_title = (actions.x - inner.x - 42. - 150.).max(60.);
    let title = ui.p.layout(&name, style, Some(max_title));
    let tx = inner.x + 42.;
    ui.p.draw_text(&title, tx, inner.y + (inner.h - title.height) / 2., t.ink);
    if kind == Kind::Containers {
        let state = d.lists.containers[i].state.clone();
        chip(d, ui, tx + title.width + 12., inner.y + inner.h / 2., &state, 140.);
    }
    // Tabs.
    let tabs_list: Vec<Tab> = if kind == Kind::Containers { vec![Tab::Info, Tab::Logs, Tab::Inspect] } else { vec![Tab::Info, Tab::Inspect] };
    let labels: Vec<String> = tabs_list.iter().map(|t| d.t(t.key())).collect();
    let tab_bar = r.cut_top(42.);
    ui.p.border_bottom(tab_bar, t.line);
    let selected = tabs_list.iter().position(|x| *x == tab).unwrap_or(0);
    if let Some(n) = tabs(ui, Id::of("detail-tabs"), tab_bar.inset(20., 0., 20., 0.), &labels, selected) {
        d.set_tab(tabs_list[n]);
    }
    let panel = r.inset(20., 18., 20., 24.);
    match tab {
        Tab::Info => info(d, ui, panel, kind, i),
        Tab::Logs => logs(d, ui, panel),
        Tab::Inspect => {
            let Some(det) = &mut d.detail else { return };
            log_view(ui, Id::of("inspect"), panel, &mut det.inspect, "");
        }
    }
}

fn index_of(d: &Desktop, kind: Kind, id: &str) -> Option<usize> {
    match kind {
        Kind::Containers => d.lists.containers.iter().position(|c| c.id == id),
        Kind::Images => d.lists.images.iter().position(|o| o.id == id),
        Kind::Volumes => d.lists.volumes.iter().position(|o| o.name == id),
        Kind::Networks => d.lists.networks.iter().position(|o| o.id == id),
    }
}

fn info(d: &mut Desktop, ui: &mut Ui, panel: Rect, kind: Kind, i: usize) {
    let row = |k: &str, v: String, mono: bool| (d.t(k), v, mono);
    let rows: Vec<(String, String, bool)> = match kind {
        Kind::Containers => {
            let c = &d.lists.containers[i];
            vec![
                row("col.id", c.id.clone(), true),
                row("col.image", c.image.clone(), false),
                row("detail.command", c.command.clone(), true),
                row("detail.status", c.status.clone(), false),
                row("col.ports", c.ports_text(), false),
                row("col.created", d.ago(c.created), false),
            ]
        }
        Kind::Images => {
            let o = &d.lists.images[i];
            let users: Vec<&str> = d
                .lists
                .containers
                .iter()
                .filter(|c| o.repo_tags.contains(&c.image) || c.image == o.id)
                .map(|c| c.name())
                .collect();
            vec![
                row("col.id", o.id.clone(), true),
                row("detail.tags", o.repo_tags.join(", "), false),
                row("col.size", fmt::size(o.size, d.lang), false),
                row("col.created", d.ago(o.created), false),
                row("detail.used", users.join(", "), false),
            ]
        }
        Kind::Volumes => {
            let o = &d.lists.volumes[i];
            let when = fmt::parse_rfc3339(&o.created_at);
            vec![
                row("col.name", o.name.clone(), false),
                row("col.driver", o.driver.clone(), false),
                row("detail.path", o.mountpoint.clone(), true),
                row("col.created", if when == 0 { String::new() } else { d.ago(when) }, false),
            ]
        }
        Kind::Networks => {
            let o = &d.lists.networks[i];
            vec![
                row("col.id", o.id.clone(), true),
                row("col.driver", o.driver.clone(), false),
                row("col.subnet", o.subnet().to_string(), true),
                row("detail.gateway", o.gateway().to_string(), true),
                row("detail.scope", o.scope.clone(), false),
            ]
        }
    };
    let none = d.t("detail.none");
    let extras: Vec<(String, String)> = if kind == Kind::Containers && d.lists.containers[i].state == "running" {
        let id = d.lists.containers[i].id.clone();
        [(d.features.top, "top", "detail.processes"), (d.features.stats, "stats", "detail.usage")]
            .into_iter()
            .filter(|(on, _, _)| *on)
            .map(|(_, what, label)| {
                let text = match d.api.container_json(&id, what) {
                    Ok(v) => pretty_json(&v),
                    Err(e) => e,
                };
                (d.t(label), text)
            })
            .collect()
    } else {
        Vec::new()
    };
    let t = ui.theme;
    let mut scroll = std::mem::take(&mut d.detail_scroll);
    scroll_view(ui, Id::of("detail-info"), panel.inset(0., -18., 0., 0.), &mut scroll, |ui, area| {
        let mut y = area.y + 18.;
        y += fields(ui, area.x, y, area.w - 12., &rows, &none);
        for (title, text) in &extras {
            y += 12.;
            let style = ui.style().weight(700);
            ui.p.label(Rect::new(area.x, y, area.w, 20.), title, style, t.ink);
            y += 28.;
            let mono = TextStyle::new(12.5).mono().line_height(19.);
            let h = ui.p.layout_wrapped(text, mono, area.w - 40.).height + 24.;
            ui.p.bordered(Rect::new(area.x, y, area.w - 12., h), 8., t.surface, 1., t.line);
            ui.paragraph(area.x + 14., y + 12., area.w - 40., text, mono, t.ink);
            y += h;
        }
        y + 24. - area.y
    });
    d.detail_scroll = scroll;
}

fn logs(d: &mut Desktop, ui: &mut Ui, panel: Rect) {
    let mut panel = panel;
    let bar = panel.cut_top(28.);
    panel.cut_top(8.);
    let label = d.t("action.follow");
    let w = checkbox::width(ui, &label);
    let mut follow = d.logs.follow;
    if checkbox::checkbox(ui, Id::of("follow"), Rect::new(bar.right() - w, bar.y, w, bar.h), Some(&mut follow), &label, true) {
        d.logs.follow = follow;
        if follow {
            follow_now(&mut d.logs);
        }
    }
    let empty = d.t("detail.noLogs");
    log_view(ui, Id::of("logs"), panel, &mut d.logs, &empty);
}
