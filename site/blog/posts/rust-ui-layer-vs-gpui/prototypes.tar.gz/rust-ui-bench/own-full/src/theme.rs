//! Podbag Desktop's colors (desktop/ui/style.css): a warm neutral page, white surfaces,
//! one blue accent. Light and dark.

use own_ui::ui::Theme;
use own_ui::{Color, rgb, rgba};

pub fn light() -> Theme {
    Theme {
        page: rgb(0xf9f9f7),
        surface: rgb(0xffffff),
        sunken: rgb(0xf2f1ed),
        hover: rgb(0xefeee9),
        ink: rgb(0x0b0b0b),
        ink2: rgb(0x52514e),
        muted: rgb(0x6f6e69),
        line: rgb(0xe1e0d9),
        accent: rgb(0x2a78d6),
        accent_text: rgb(0x1d5fae),
        accent_soft: rgb(0xe5eefa),
        accent_ink: rgb(0xffffff),
        green: rgb(0x1b7f45),
        green_soft: rgb(0xe3f3e9),
        amber: rgb(0x8f5a00),
        amber_soft: rgb(0xfbf0d9),
        red: rgb(0xb8322d),
        red_soft: rgb(0xfbe6e5),
        danger_bg: rgb(0xb8322d),
        gray_soft: rgb(0xeeede8),
        shadow: rgba(0x000000, 0.12),
        backdrop: rgba(0x000000, 0.35),
        text_size: 14.,
    }
}

pub fn dark() -> Theme {
    Theme {
        page: rgb(0x0d0d0d),
        surface: rgb(0x1a1a19),
        sunken: rgb(0x242422),
        hover: rgb(0x262624),
        ink: rgb(0xf0efec),
        ink2: rgb(0xc3c2b7),
        muted: rgb(0x9c9b94),
        line: rgb(0x2c2c2a),
        accent: rgb(0x3987e5),
        accent_text: rgb(0x8ab8f3),
        accent_soft: rgb(0x1b2a3f),
        accent_ink: rgb(0xffffff),
        green: rgb(0x5fd08f),
        green_soft: rgb(0x17301f),
        amber: rgb(0xf0b54d),
        amber_soft: rgb(0x352a14),
        red: rgb(0xf47c76),
        red_soft: rgb(0x3a1b1a),
        danger_bg: rgb(0xc4413b),
        gray_soft: rgb(0x2a2a28),
        shadow: rgba(0x000000, 0.5),
        backdrop: rgba(0x000000, 0.35),
        text_size: 14.,
    }
}

/// The settings' section icon colors.
pub fn setting_color(key: &str) -> Color {
    rgb(match key {
        "startup" => 0x24846c,
        "language" => 0x3379bd,
        "theme" => 0x8254b2,
        "engine" => 0x516887,
        "vm" => 0xa76528,
        "updates" => 0x316fb9,
        _ => 0x677382,
    })
}
