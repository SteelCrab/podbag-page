//! The settings page: startup, language, theme; then engine, VM, updates and about as
//! sections that open and close.

use bench_api::{VmChange, VmStatus, fmt, i18n};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, Kind as ButtonKind};
use own_ui::widgets::checkbox;
use own_ui::widgets::radio::segmented;
use own_ui::widgets::scroll::scroll_view;
use own_ui::widgets::select::{Item, select};
use own_ui::widgets::slider::slider;
use own_ui::widgets::text_field::text_field;
use own_ui::{CursorIcon, Id, Rect};

use crate::app::Desktop;
use crate::dialogs::{AskFor, Dialog, Then};
use crate::icons::Icon;
use crate::theme::setting_color;
use crate::views::{fields, pill, title_bar, vm_state_key};

const ROW_H: f32 = 61.;

pub fn paint(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    let mut r = r;
    let bar = r.cut_top(62.);
    let title = d.t("settings.title");
    title_bar(ui, bar, &title);
    let mut scroll = std::mem::take(&mut d.settings_scroll);
    scroll_view(ui, Id::of("settings-scroll"), r, &mut scroll, |ui, area| {
        let w = (area.w - 40.).min(780.);
        let x = area.x + 20.;
        let mut y = area.y + 20.;
        y += card(ui, x, y, w, |ui, x, y, w| first_card(d, ui, x, y, w)) + 18.;
        y += card(ui, x, y, w, |ui, x, y, w| second_card(d, ui, x, y, w)) + 24.;
        y - area.y
    });
    d.settings_scroll = scroll;
}

/// A card; `body` paints inside (16 px side padding) and returns its height.
fn card(ui: &mut Ui, x: f32, y: f32, w: f32, body: impl FnOnce(&mut Ui, f32, f32, f32) -> f32) -> f32 {
    let t = ui.theme;
    let id = Id::of(("card", (x as i32, y as i32)));
    let h = ui.mem.heights.get(&id).copied().unwrap_or(ROW_H * 3.);
    ui.p.bordered(Rect::new(x, y, w, h), 10., t.surface, 1., t.line);
    let used = body(ui, x + 16., y, w - 32.);
    if (used - h).abs() > 0.5 {
        ui.mem.heights.insert(id, used);
        ui.repaint();
    }
    used
}

/// The colored icon and title of a setting; returns its width.
fn setting_title(ui: &mut Ui, x: f32, cy: f32, key: &str, icon: Icon, label: &str) -> f32 {
    let t = ui.theme;
    let ir = Rect::new(x, cy - 16., 32., 32.);
    ui.p.rounded(ir, 8., setting_color(key));
    ui.p.icon(icon.id(), ir.center(20., 20.), own_ui::rgb(0xffffff));
    let style = ui.style().weight(600);
    let l = ui.p.layout(label, style, None);
    ui.p.draw_text(&l, x + 44., cy - l.height / 2., t.ink);
    44. + l.width
}

fn separator(ui: &mut Ui, x: f32, y: f32, w: f32) {
    let line = ui.theme.line;
    ui.p.fill(Rect::new(x, y, w, 1.), line);
}

fn first_card(d: &mut Desktop, ui: &mut Ui, x: f32, y0: f32, w: f32) -> f32 {
    let t = ui.theme;
    let mut y = y0;
    // Startup.
    let cy = y + ROW_H / 2.;
    setting_title(ui, x, cy, "startup", Icon::Power, &d.t("settings.startup"));
    let label = d.t("settings.launchAtLogin");
    let cw = checkbox::width(ui, &label).min(w * 0.6);
    let mut on = d.launch_at_login.unwrap_or(false);
    let known = d.launch_at_login.is_some();
    let r = Rect::new(x + w - cw, y, cw, ROW_H);
    if checkbox::checkbox(ui, Id::of("launch-at-login"), r, known.then_some(&mut on), &label, true) {
        match d.api.set_launch_at_login(on) {
            Ok(()) => d.launch_at_login = d.api.launch_at_login().ok(),
            Err(e) => d.toasts.push(e, true),
        }
    }
    y += ROW_H;
    separator(ui, x, y, w);
    // Language.
    let cy = y + ROW_H / 2.;
    setting_title(ui, x, cy, "language", Icon::Globe, &d.t("settings.language"));
    let names = i18n::names();
    let system = d.t("settings.system");
    let mut items = vec![Item::Option(&system)];
    items.extend(names.iter().map(|(_, n)| Item::Option(n.as_str())));
    let sel = names.iter().position(|(l, _)| *l == d.settings.language).map_or(0, |i| i + 1);
    if let Some(i) = select(ui, Id::of("language"), Rect::new(x + w - 190., cy - 17., 190., 34.), &items, sel, true) {
        let setting = if i == 0 { "system".to_string() } else { names[i - 1].0.to_string() };
        d.set_language(&setting, ui);
    }
    y += ROW_H;
    separator(ui, x, y, w);
    // Theme.
    let cy = y + ROW_H / 2.;
    setting_title(ui, x, cy, "theme", Icon::Appearance, &d.t("settings.theme"));
    let options = [("system", Icon::Display), ("light", Icon::Sun), ("dark", Icon::Moon)];
    let labels: Vec<String> = options.iter().map(|(k, _)| d.t(&format!("settings.{k}"))).collect();
    let segs: Vec<(Option<u16>, &str)> = options.iter().zip(&labels).map(|((_, i), l)| (Some(i.id()), l.as_str())).collect();
    let sel = options.iter().position(|(k, _)| *k == d.settings.theme).unwrap_or(0);
    let seg_style = ui.style().with_size(13.).weight(600);
    let natural: f32 = labels.iter().map(|l| ui.p.layout(l, seg_style, None).width + 21. + 22.).sum::<f32>() + 4.;
    let sw = natural.max(240.).min(w * 0.6);
    if let Some(i) = segmented(ui, Id::of("theme"), Rect::new(x + w - sw, cy - 16., sw, 32.), &segs, sel) {
        d.settings.theme = options[i].0.to_string();
        d.save_settings();
    }
    let _ = t;
    y + ROW_H - y0
}

/// A section header that opens and closes; returns (height, open).
fn section(d: &mut Desktop, ui: &mut Ui, x: f32, y: f32, w: f32, key: &'static str, icon: Icon, value: &str) -> (f32, bool) {
    let t = ui.theme;
    let id = Id::of(("section", key));
    let r = Rect::new(x - 8., y, w + 16., ROW_H);
    if ui.hovered(id) {
        ui.p.rounded(r.inset(0., 2., 0., 2.), 6., t.hover);
    }
    let cy = y + ROW_H / 2.;
    let label = d.t(&format!("settings.{key}"));
    let title_w = setting_title(ui, x, cy, key, icon, &label);
    let open = d.open_sections.contains(key);
    let chevron = if open { own_ui::icons::CHEVRON_DOWN } else { own_ui::icons::CHEVRON_RIGHT };
    ui.p.icon(chevron, Rect::new(x + w - 14., cy - 7., 14., 14.), t.muted);
    let style = ui.style().with_size(13.);
    let max = (w - title_w - 40.).max(20.);
    let vl = ui.p.layout(value, style, Some(max));
    ui.p.draw_text(&vl, x + w - 24. - vl.width, cy - vl.height / 2., t.ink2);
    ui.p.hitbox(r, id, CursorIcon::Pointer);
    if ui.clicked(id) {
        if open {
            d.open_sections.remove(key);
        } else {
            d.open_sections.insert(key);
        }
    }
    (ROW_H, d.open_sections.contains(key))
}

fn second_card(d: &mut Desktop, ui: &mut Ui, x: f32, y0: f32, w: f32) -> f32 {
    let mut y = y0;
    let bx = x + 44.;
    let bw = w - 44.;
    // Engine.
    let engine_name = d.engine.as_ref().map(|e| e.engine_name.clone()).unwrap_or_default();
    let (h, open) = section(d, ui, x, y, w, "engine", Icon::Engine, &engine_name);
    y += h;
    if open {
        y += engine_body(d, ui, bx, y, bw) + 18.;
    }
    // The VM, for podbag on macOS and Windows.
    if let Some(vm) = d.vm.clone().filter(|_| d.has_vm()) {
        separator(ui, x, y, w);
        let state = d.t(&format!("vm.state.{}", vm_state_key(&vm.state)));
        let (h, open) = section(d, ui, x, y, w, "vm", Icon::Vm, &state);
        y += h;
        if open {
            y += vm_body(d, ui, bx, y, bw, &vm) + 18.;
        }
    }
    // Updates (read only: updating is out of scope).
    if let Some(u) = d.updates.clone() {
        separator(ui, x, y, w);
        let value = if u.newer { d.tv("status.available", &[("version", &u.latest)]) } else { u.engine.clone() };
        let (h, open) = section(d, ui, x, y, w, "updates", Icon::Update, &value);
        y += h;
        if open {
            let rows = vec![
                (d.t("settings.appVersion"), u.app.clone(), false),
                (d.t("settings.engineVersion"), u.engine.clone(), false),
                (d.t("settings.latest"), u.latest.clone(), false),
                (d.t("settings.checked"), if u.checked > 0 { d.ago(u.checked) } else { d.t("settings.never") }, false),
            ];
            let none = d.t("detail.none");
            y += fields(ui, bx, y, bw, &rows, &none);
            let status = if u.newer { d.tv("update.available", &[("version", &u.latest)]) } else { d.t("update.upToDate") };
            let t = ui.theme;
            let color = if u.newer { t.accent_text } else { t.muted };
            y += ui.paragraph(bx, y + 4., bw, &status, ui.style().with_size(12.5), color) + 22.;
        }
    }
    // About.
    separator(ui, x, y, w);
    let (h, open) = section(d, ui, x, y, w, "about", Icon::Inspect, "");
    y += h;
    if open {
        let t = ui.theme;
        y += ui.paragraph(bx, y, bw, &d.t("settings.aboutText"), ui.style(), t.ink2) + 18.;
    }
    y - y0
}

fn engine_body(d: &mut Desktop, ui: &mut Ui, x: f32, y0: f32, w: f32) -> f32 {
    let t = ui.theme;
    let mut y = y0;
    // The engine picker: podbag, Docker, Podman, Kiri, Docker contexts, a socket.
    let label = d.t("settings.engine");
    ui.p.label(Rect::new(x, y, 120., 34.), &label, ui.style(), t.ink2);
    let name = d.connection.name.clone();
    let mut values: Vec<(String, String)> =
        vec![("podbag".into(), "podbag".into()), ("docker".into(), "Docker".into()), ("podman".into(), "Podman".into()), ("kiri".into(), "Kiri".into())];
    let group = d.t("engine.contexts");
    let contexts: Vec<(String, String)> = d.contexts.iter().map(|c| (format!("context:{c}"), c.clone())).collect();
    if !values.iter().chain(&contexts).any(|(v, _)| *v == name) {
        values.push((name.clone(), name.clone()));
    }
    let windows = d.engine.as_ref().is_some_and(|e| e.platform == "windows");
    let socket = d.t("engine.socket");
    let mut items: Vec<Item> = values.iter().map(|(_, l)| Item::Option(l.as_str())).collect();
    let mut keys: Vec<Option<&str>> = values.iter().map(|(v, _)| Some(v.as_str())).collect();
    if !contexts.is_empty() {
        items.push(Item::Group(&group));
        keys.push(None);
        for (v, l) in &contexts {
            items.push(Item::Option(l.as_str()));
            keys.push(Some(v.as_str()));
        }
    }
    if !windows {
        items.push(Item::Option(&socket));
        keys.push(Some("custom"));
    }
    let sel = keys.iter().position(|k| *k == Some(name.as_str())).unwrap_or(0);
    let sw = (w - 134.).min(300.);
    if let Some(i) = select(ui, Id::of("engine-picker"), Rect::new(x + 134., y, sw, 34.), &items, sel, true)
        && let Some(next) = keys[i]
        && next != name
    {
        if next == "custom" {
            let title = d.t("engine.socket");
            let label = d.t("settings.socket");
            let ok = d.t("engine.connect");
            d.dialog = Some(Dialog::ask(title, label, "", "unix:///path/to/docker.sock", ok, AskFor::Socket));
        } else {
            match d.api.set_engine(next) {
                Ok(()) => d.reconnect(),
                Err(e) => d.toasts.push(e, true),
            }
        }
    }
    y += 42.;
    y += ui.paragraph(x, y, w, &d.t("settings.engineNote"), ui.style().with_size(12.5), t.muted) + 12.;
    let e = d.engine.clone();
    let rows = vec![
        (d.t("settings.socket"), e.as_ref().map(|e| e.endpoint.clone()).unwrap_or_default(), true),
        (d.t("settings.version"), e.as_ref().and_then(|e| e.version.clone()).unwrap_or_default(), false),
    ];
    let none = d.t("detail.none");
    y += fields(ui, x, y, w, &rows, &none);
    // Where the docker command goes (images.js `dockerSettings`).
    if let Some(cmd) = d.docker.clone() {
        separator(ui, x, y + 2., w);
        y += 14.;
        let label = d.t("docker.command");
        let style = ui.style();
        let lw = ui.p.layout(&label, style, None).width;
        ui.p.label(Rect::new(x, y, lw + 2., 30.), &label, style, t.ink2);
        let route = if !cmd.installed {
            d.t("docker.missing")
        } else if let Some(to) = &d.docker_switching {
            let target = if to == "use" { "podbag".to_string() } else { cmd.previous.clone().unwrap_or_else(|| "default".into()) };
            d.tv("docker.switching", &[("name", &target)])
        } else if cmd.is_podbag {
            d.t("docker.applied")
        } else {
            d.tv("docker.using", &[("name", &cmd.name)])
        };
        let (fg, bg) = if cmd.is_podbag { (t.green, t.green_soft) } else { (t.ink2, t.gray_soft) };
        let pw = pill(ui, x + lw + 10., y + 15., &route, fg, bg, w - lw - 60.);
        if cmd.installed && d.docker_switching.is_none() && (!cmd.is_podbag || cmd.previous.is_some()) {
            let (icon, to) = if cmd.is_podbag { (Icon::Undo, "back") } else { (Icon::Switch, "use") };
            let br = Rect::new(x + lw + 10. + pw + 8., y, 30., 30.);
            if button::icon_button(ui, Id::of("docker-switch"), br, icon.id(), button::IconKind::Accent, true) {
                if to == "use" {
                    let text = d.tv("docker.askUse", &[("name", &cmd.name)]);
                    let yes = d.t("docker.use");
                    d.dialog = Some(Dialog::confirm(d, text, Some(yes), Then::DockerUse));
                } else {
                    d.api.docker_switch("back");
                }
            }
        }
        y += 30.;
    }
    y - y0
}

pub fn fill_vm_form(d: &mut Desktop) {
    let Some(vm) = &d.vm else { return };
    let next = vm.in_use.map_or(vm.next, |u| if vm.next.cpus.is_none() && vm.next.memory_mib.is_none() { u } else { vm.next });
    let f = &mut d.vm_form;
    f.cpus.set_content(&next.cpus.map(|c| c.to_string()).unwrap_or_default());
    f.memory.set_content(&next.memory_mib.map(|m| trim_float(m as f32 / 1024.)).unwrap_or_default());
    f.idle.set_content(&next.idle_seconds.map(|s| ((s as f32 / 60.).round() as u32).to_string()).unwrap_or_default());
}

fn trim_float(v: f32) -> String {
    let s = format!("{v:.2}");
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}

fn vm_body(d: &mut Desktop, ui: &mut Ui, x: f32, y0: f32, w: f32, vm: &VmStatus) -> f32 {
    let t = ui.theme;
    let mut y = y0;
    let running = vm.state == "running";
    let stoppable = running || vm.state == "standby" || vm.state == "starting";
    // State.
    let style = ui.style();
    ui.p.label(Rect::new(x, y, 160., 22.), &d.t("settings.vmState"), style, t.ink2);
    let (fg, bg) = match vm_state_key(&vm.state) {
        "running" => (t.green, t.green_soft),
        "starting" => (t.amber, t.amber_soft),
        _ => (t.ink2, t.gray_soft),
    };
    let state = d.t(&format!("vm.state.{}", vm_state_key(&vm.state)));
    let label_w = 132f32;
    pill(ui, x + label_w, y + 11., &state, fg, bg, w - label_w);
    y += 32.;
    let mut rows = Vec::new();
    if let Some(u) = vm.in_use {
        let idle = match u.idle_seconds {
            Some(s) if s > 0 => d.tv("settings.idleAfter", &[("time", &fmt::duration(Some(s as u64), d.lang))]),
            _ => d.t("settings.idleNever"),
        };
        let text = [d.tv("settings.cpusValue", &[("n", &u.cpus.unwrap_or(0))]), fmt::mib(u.memory_mib, d.lang), idle].join(" · ");
        rows.push((d.t("settings.vmInUse"), text, false));
    }
    if vm.uptime_seconds.is_some() {
        rows.push((d.t("settings.vmUptime"), fmt::duration(vm.uptime_seconds, d.lang), false));
    }
    if let Some(disk) = &vm.disk {
        let text = d.tv("settings.vmDiskValue", &[("used", &fmt::size(disk.allocated_bytes, d.lang)), ("size", &fmt::size(disk.size_bytes, d.lang))]);
        rows.push((d.t("settings.vmDisk"), text, false));
    }
    let none = d.t("detail.none");
    y += fields(ui, x, y, w, &rows, &none) + 4.;
    // Start, stop, restart.
    let mut bx = x;
    for (action, icon, key, enabled, primary) in [
        ("start", Icon::Start, "action.startVm", !stoppable && vm.state != "not set up", !stoppable),
        ("stop", Icon::Stop, "action.stopVm", stoppable, false),
        ("restart", Icon::Restart, "action.restartVm", running, false),
    ] {
        let label = d.t(key);
        let bw = button::width(ui, &label, Some(icon.id()), false);
        let kind = if primary { ButtonKind::Primary } else { ButtonKind::Normal };
        if button::button(ui, Id::of(("vm-settings", action)), Rect::new(bx, y, bw, 32.), &label, Some(icon.id()), kind, enabled && !d.vm_busy) {
            d.vm_action(action);
        }
        bx += bw + 8.;
    }
    y += 32.;
    if !vm.resources_editable {
        y += 10. + ui.paragraph(x, y + 10., w, &d.t("settings.vmWsl"), ui.style().with_size(12.5), t.muted);
        return y - y0;
    }
    // The form: CPUs, memory, idle.
    y += 18.;
    separator(ui, x, y, w);
    y += 16.;
    let l = vm.limits;
    let over = |name: &str| vm.overridden_by.iter().any(|n| n == name);
    let col_w = ((w - 28.) / 3.).max(120.);
    let label_style = ui.style().with_size(13.).weight(600);
    let hint_style = ui.style().with_size(12.5);
    let mut col_h: f32 = 0.;
    let specs = [
        ("cpus", d.t("settings.cpus"), Some((l.cpus_min as f32, l.cpus_max as f32, 1.))),
        ("memory", d.t("settings.memory"), Some((l.memory_min_mib as f32 / 1024., l.memory_max_mib as f32 / 1024., 0.25))),
        ("idle", d.t("settings.idle"), None),
    ];
    for (i, (name, label, range)) in specs.iter().enumerate() {
        let cx = x + i as f32 * (col_w + 14.);
        let mut cy = y;
        cy += ui.paragraph(cx, cy, col_w, label, label_style, t.ink) + 5.;
        let input = match *name {
            "cpus" => &mut d.vm_form.cpus,
            "memory" => &mut d.vm_form.memory,
            _ => &mut d.vm_form.idle,
        };
        if text_field(ui, input, Rect::new(cx, cy, col_w, 34.), None, true) {
            d.vm_form.dirty = true;
        }
        cy += 39.;
        if let Some((min, max, step)) = range {
            let input = if *name == "cpus" { &mut d.vm_form.cpus } else { &mut d.vm_form.memory };
            let mut v: f32 = input.content.trim().parse().unwrap_or(*min);
            if slider(ui, Id::of(("vm-slider", *name)), Rect::new(cx, cy, col_w, 20.), &mut v, *min, *max, *step) {
                input.set_content(&trim_float(v));
                d.vm_form.dirty = true;
            }
            cy += 25.;
        }
        let hint = match *name {
            "cpus" => d.tv("settings.limits", &[("min", &l.cpus_min), ("max", &l.cpus_max)]),
            "memory" => d.tv("settings.limits", &[("min", &fmt::mib(Some(l.memory_min_mib), d.lang)), ("max", &fmt::mib(Some(l.memory_max_mib), d.lang))]),
            _ => d.t("settings.idleHint"),
        };
        cy += ui.paragraph(cx, cy, col_w, &hint, hint_style, t.muted) + 3.;
        let env = match *name {
            "cpus" => "PODBAG_VM_CPUS",
            "memory" => "PODBAG_VM_MEMORY",
            _ => "PODBAG_VM_IDLE",
        };
        if over(env) {
            cy += ui.paragraph(cx, cy, col_w, &d.tv("settings.vmOverridden", &[("name", &env)]), hint_style, t.amber);
        }
        col_h = col_h.max(cy - y);
    }
    y += col_h + 8.;
    if vm.pending {
        y += ui.paragraph(x, y, w, &d.t("settings.vmPending"), hint_style, t.muted) + 6.;
    }
    if !d.vm_form.error.is_empty() {
        let e = d.vm_form.error.clone();
        y += ui.paragraph(x, y, w, &e, ui.style(), t.red) + 6.;
    }
    y += 8.;
    let label = d.t("settings.apply");
    let bw = button::width(ui, &label, None, false);
    if button::button(ui, Id::of("vm-apply"), Rect::new(x, y, bw, 32.), &label, None, ButtonKind::Primary, true) {
        apply_vm(d, vm);
    }
    y + 32. - y0
}

/// app.js `applyVm`: check the form, then save (asking first when the VM runs).
fn apply_vm(d: &mut Desktop, vm: &VmStatus) {
    d.vm_form.error.clear();
    let l = vm.limits;
    let parse = |s: &str| s.trim().parse::<f32>().ok();
    let checks = [
        (parse(&d.vm_form.cpus.content), l.cpus_min as f32, l.cpus_max as f32, "settings.cpus", 1.),
        (parse(&d.vm_form.memory.content), l.memory_min_mib as f32 / 1024., l.memory_max_mib as f32 / 1024., "settings.memory", 0.25),
        (parse(&d.vm_form.idle.content), 0., 1440., "settings.idle", 1.),
    ];
    for (v, min, max, key, step) in checks {
        let ok = v.is_some_and(|v| v >= min && v <= max && ((v / step) - (v / step).round()).abs() < 1e-3);
        if !ok {
            let range = d.tv("settings.limits", &[("min", &min), ("max", &max)]);
            d.vm_form.error = format!("{}: {range}", d.t(key));
            return;
        }
    }
    let cpus = parse(&d.vm_form.cpus.content).unwrap_or(0.) as u32;
    let memory_mib = (parse(&d.vm_form.memory.content).unwrap_or(0.) * 1024.).round() as u32;
    let idle_seconds = (parse(&d.vm_form.idle.content).unwrap_or(0.) * 60.).round() as u32;
    let next = vm.next;
    let mut change = VmChange::default();
    if Some(cpus) != next.cpus {
        change.cpus = Some(cpus);
    }
    if Some(memory_mib) != next.memory_mib {
        change.memory_mib = Some(memory_mib);
    }
    if Some(idle_seconds) != next.idle_seconds {
        change.idle_seconds = Some(idle_seconds);
    }
    let none = change.cpus.is_none() && change.memory_mib.is_none() && change.idle_seconds.is_none();
    if none && !vm.pending {
        let text = d.t("settings.vmSame");
        d.toasts.push(text, false);
        return;
    }
    if none {
        change.cpus = Some(cpus);
    }
    let in_use = vm.in_use;
    let differs = in_use.is_none_or(|u| u.cpus != Some(cpus) || u.memory_mib != Some(memory_mib) || u.idle_seconds != Some(idle_seconds));
    if vm.state == "running" && differs {
        let n = vm.containers.unwrap_or(0);
        let mut text = d.t("settings.vmApplyText");
        if n > 0 {
            text = format!("{text}\n\n{}", d.tv("settings.vmApplyWarn", &[("n", &n)]));
        }
        d.dialog = Some(Dialog::Choose {
            title: d.t("settings.vmApplyTitle"),
            text,
            later: d.t("settings.nextStart"),
            now: d.t("settings.restartNow"),
            cancel: d.t("action.cancel"),
            danger: n > 0,
            change,
        });
        return;
    }
    save_vm(d, change);
}

pub fn save_vm(d: &mut Desktop, change: VmChange) {
    match d.api.vm_set(change) {
        Ok(_) => {
            d.vm_form.dirty = false;
            let text = d.t(if change.restart { "settings.vmRestarted" } else { "settings.vmSaved" });
            d.toasts.push(text, false);
        }
        Err(e) => d.vm_form.error = e,
    }
    d.refresh_vm();
}
