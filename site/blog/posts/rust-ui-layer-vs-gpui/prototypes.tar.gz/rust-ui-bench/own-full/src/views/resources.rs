//! The four engine lists (containers, images, volumes, networks): toolbar with search
//! and tools, the table with row actions, and the empty states.

use bench_api::{Kind, fmt, short_id};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, IconKind, Kind as ButtonKind};
use own_ui::widgets::layout::Row;
use own_ui::widgets::table::{Column, Width, table};
use own_ui::widgets::text_field::text_field;
use own_ui::{Id, Rect, TextStyle};

use crate::app::{Desktop, Tab, kind_index};
use crate::dialogs::{AskFor, Dialog};
use crate::icons::Icon;
use crate::views::{centered, chip, code_line, title_bar};

pub fn paint(d: &mut Desktop, ui: &mut Ui, r: Rect, kind: Kind) {
    let mut r = r;
    let bar = r.cut_top(62.);
    toolbar(d, ui, bar, kind);
    let content = r.inset(20., 8., 20., 0.);
    list(d, ui, content, kind);
}

fn toolbar(d: &mut Desktop, ui: &mut Ui, bar: Rect, kind: Kind) {
    let t = ui.theme;
    let title = d.t(&format!("nav.{}", kind.as_str()));
    let title_right = title_bar(ui, bar, &title);
    let mut row = Row::new(bar.inset(20., 14., 20., 15.), 8.);
    // Tools, from the right.
    let refresh = row.right_h(30., 30.);
    if button::icon_button(ui, Id::of("refresh"), refresh, Icon::Refresh.id(), IconKind::Plain, true) {
        d.refresh();
    }
    let prune = d.t("action.prune");
    let w = button::width(ui, &prune, Some(Icon::Prune.id()), false);
    if button::button(ui, Id::of(("prune", kind.as_str())), row.right_h(w, 32.), &prune, Some(Icon::Prune.id()), ButtonKind::Normal, true) {
        d.ask_prune(kind);
    }
    if kind == Kind::Volumes {
        let label = d.t("volume.create");
        let w = button::width(ui, &label, None, false);
        if button::button(ui, Id::of("create-volume"), row.right_h(w, 32.), &label, None, ButtonKind::Primary, true) {
            create_volume(d);
        }
    }
    if kind == Kind::Images {
        let label = d.t("action.pull");
        let w = button::width(ui, &label, Some(Icon::Pull.id()), false);
        if button::button(ui, Id::of("pull"), row.right_h(w, 32.), &label, Some(Icon::Pull.id()), ButtonKind::Primary, true) {
            d.open_pull();
        }
    }
    // The live dot: the engine's event stream is on.
    let live_text = if d.live { d.t("live.on") } else { String::new() };
    let style = ui.style().with_size(12.5);
    let lw = ui.p.layout(&live_text, style, None).width;
    let live = row.right_h(lw + 14., 20.);
    let color = if d.live { t.green } else { t.muted };
    ui.p.rounded(Rect::new(live.x, live.y + 6., 8., 8.), 4., color);
    ui.p.label(Rect::new(live.x + 14., live.y, lw + 2., 20.), &live_text, style, color);
    // The search box, after the title.
    let rest = row.rest();
    let x = title_right + 12.;
    let w = (rest.right() - x - 12.).clamp(0., 280.);
    if w >= 120. {
        let search = Rect::new(x, bar.y + 15., w, 32.);
        let i = kind_index(kind);
        if text_field(ui, &mut d.search[i], search, Some(Icon::Search.id()), true) {
            d.on_search(kind);
        }
    }
}

pub fn create_volume(d: &mut Desktop) {
    let title = d.t("volume.create");
    let label = d.t("col.name");
    d.dialog = Some(Dialog::ask(title.clone(), label, "", "data", title, AskFor::CreateVolume));
}

fn columns(d: &Desktop, kind: Kind, window_w: f32) -> Vec<(Column<'static>, &'static str)> {
    let narrow = window_w < 880.;
    let mid = window_w < 1060.;
    let c = |key: &'static str, width: Width| (Column { label: "", width }, key);
    let cols = match kind {
        Kind::Containers => {
            let mut v = vec![c("col.name", Width::Flex(1.)), c("col.image", Width::Flex(1.)), c("col.state", Width::Px(128.))];
            if !narrow {
                v.push(c("col.ports", Width::Px(130.)));
            }
            if !mid {
                v.push(c("col.created", Width::Px(124.)));
            }
            v.push(c("col.actions", Width::Px(164.)));
            v
        }
        Kind::Images => {
            let mut v = vec![c("col.name", Width::Flex(1.))];
            if !narrow {
                v.push(c("col.id", Width::Px(130.)));
            }
            v.extend([c("col.size", Width::Px(110.)), c("col.created", Width::Px(150.)), c("col.actions", Width::Px(56.))]);
            v
        }
        Kind::Volumes => vec![c("col.name", Width::Flex(1.)), c("col.driver", Width::Px(120.)), c("col.created", Width::Px(160.)), c("col.actions", Width::Px(56.))],
        Kind::Networks => {
            let mut v = vec![c("col.name", Width::Flex(1.)), c("col.driver", Width::Px(110.)), c("col.subnet", Width::Flex(1.))];
            if !narrow {
                v.push(c("col.id", Width::Px(130.)));
            }
            v.push(c("col.actions", Width::Px(56.)));
            v
        }
    };
    let _ = d;
    cols
}

fn list(d: &mut Desktop, ui: &mut Ui, r: Rect, kind: Kind) {
    let t = ui.theme;
    let i = kind_index(kind);
    if !d.loaded {
        ui.p.label(Rect::new(r.x + 10., r.y + 24., r.w, 20.), &d.t("engine.checking"), ui.style(), t.ink2);
        return;
    }
    if let Some(err) = d.lists.errors[i].clone() {
        let h = ui.paragraph(r.x + 10., r.y + 24., r.w - 20., &err, ui.style(), t.red);
        let label = d.t("action.retry");
        let w = button::width(ui, &label, Some(Icon::Refresh.id()), false);
        if button::button(ui, Id::of("list-retry"), Rect::new(r.x + 10., r.y + 36. + h, w, 32.), &label, Some(Icon::Refresh.id()), ButtonKind::Normal, true) {
            d.refresh();
        }
        return;
    }
    if d.lists.len(kind) == 0 {
        empty_state(d, ui, r, kind);
        return;
    }
    let q = d.search[i].content.clone();
    let shown = d.lists.filter(kind, &q).to_vec();
    if shown.is_empty() {
        let text = d.tv("empty.search", &[("q", &q.trim())]);
        ui.paragraph(r.x + 10., r.y + 24., r.w - 20., &text, ui.style(), t.ink2);
        return;
    }
    let window_w = ui.bounds().w;
    let cols = columns(d, kind, window_w);
    let labels: Vec<String> = cols.iter().map(|(_, k)| if *k == "col.actions" { String::new() } else { d.t(k) }).collect();
    let table_cols: Vec<Column> = cols.iter().zip(&labels).map(|((c, _), l)| Column { label: l.as_str(), width: c.width }).collect();
    let keys: Vec<&'static str> = cols.iter().map(|(_, k)| *k).collect();
    let id = Id::of(("table", kind.as_str()));
    let mut list = std::mem::replace(&mut d.tables[i], own_ui::VirtualList::new(1., 1.));
    let clicked = table(ui, id, r, &table_cols, shown.len(), &mut list, |ui, row, col, cell| {
        paint_cell(d, ui, kind, shown[row], keys[col], cell, id.with(("row", row)));
    });
    d.tables[i] = list;
    if let Some(row) = clicked {
        let id = object_id(d, kind, shown[row]);
        d.open_detail(kind, &id, Tab::Info);
    }
}

pub fn object_id(d: &Desktop, kind: Kind, i: usize) -> String {
    match kind {
        Kind::Containers => d.lists.containers[i].id.clone(),
        Kind::Images => d.lists.images[i].id.clone(),
        Kind::Volumes => d.lists.volumes[i].name.clone(),
        Kind::Networks => d.lists.networks[i].id.clone(),
    }
}

pub fn object_name(d: &Desktop, kind: Kind, i: usize) -> String {
    match kind {
        Kind::Containers => d.lists.containers[i].name().to_string(),
        Kind::Images => d.lists.images[i].name().to_string(),
        Kind::Volumes => d.lists.volumes[i].name.clone(),
        Kind::Networks => d.lists.networks[i].name.clone(),
    }
}

fn paint_cell(d: &mut Desktop, ui: &mut Ui, kind: Kind, i: usize, key: &str, cell: Rect, row_id: Id) {
    let t = ui.theme;
    let base = ui.style();
    let primary = base.weight(600);
    let mono = TextStyle::new(12.5).mono().line_height(18.);
    let small_mono = TextStyle::new(12.).mono().line_height(16.);
    let secondary = base;
    if key == "col.actions" {
        row_actions(d, ui, kind, i, cell, row_id, false);
        return;
    }
    match (kind, key) {
        (Kind::Containers, "col.name") => {
            let c = &d.lists.containers[i];
            let name_r = Rect::new(cell.x, cell.y + 9., cell.w, 20.);
            ui.p.label(name_r, c.name(), primary, t.ink);
            ui.p.label(Rect::new(cell.x, name_r.bottom() + 1., cell.w, 16.), short_id(&c.id), small_mono, t.ink2);
        }
        (Kind::Containers, "col.image") => {
            ui.p.label(cell, &d.lists.containers[i].image, base, t.ink);
        }
        (Kind::Containers, "col.state") => {
            let state = d.lists.containers[i].state.clone();
            ui.clip(cell, |ui| chip(d, ui, cell.x, cell.y + cell.h / 2., &state, cell.w));
        }
        (Kind::Containers, "col.ports") => {
            let ports = d.lists.containers[i].ports_text();
            ui.p.label(cell, if ports.is_empty() { "—" } else { &ports }, mono, t.ink);
        }
        (Kind::Containers, "col.created") => {
            let text = d.ago(d.lists.containers[i].created);
            ui.p.label(cell, &text, secondary, t.ink2);
        }
        (Kind::Images, "col.name") => {
            let name = d.lists.images[i].name().to_string();
            ui.p.label(cell, &name, primary, t.ink);
        }
        (Kind::Images, "col.id") => {
            ui.p.label(cell, short_id(&d.lists.images[i].id), mono, t.ink2);
        }
        (Kind::Images, "col.size") => {
            let text = fmt::size(d.lists.images[i].size, d.lang);
            ui.p.label(cell, &text, base, t.ink);
        }
        (Kind::Images, "col.created") => {
            let text = d.ago(d.lists.images[i].created);
            ui.p.label(cell, &text, secondary, t.ink2);
        }
        (Kind::Volumes, "col.name") => {
            ui.p.label(cell, &d.lists.volumes[i].name, primary, t.ink);
        }
        (Kind::Volumes, "col.driver") => {
            ui.p.label(cell, &d.lists.volumes[i].driver, base, t.ink);
        }
        (Kind::Volumes, "col.created") => {
            let when = fmt::parse_rfc3339(&d.lists.volumes[i].created_at);
            let text = if when == 0 { String::new() } else { d.ago(when) };
            ui.p.label(cell, &text, secondary, t.ink2);
        }
        (Kind::Networks, "col.name") => {
            let n = &d.lists.networks[i];
            let name = ui.p.layout(&n.name, primary, Some(cell.w));
            ui.p.draw_text(&name, cell.x, cell.y + (cell.h - name.height) / 2., t.ink);
            if n.builtin() {
                let tag = d.t("state.builtin");
                let style = TextStyle::new(11.).line_height(16.);
                let tl = ui.p.layout(&tag, style, None);
                let tr = Rect::new(cell.x + name.width + 8., cell.y + (cell.h - 16.) / 2., tl.width + 12., 16.);
                if tr.right() < cell.right() {
                    ui.p.rounded(tr, 4., t.gray_soft);
                    ui.p.draw_text(&tl, tr.x + 6., tr.y, t.ink2);
                }
            }
        }
        (Kind::Networks, "col.driver") => {
            ui.p.label(cell, &d.lists.networks[i].driver, base, t.ink);
        }
        (Kind::Networks, "col.subnet") => {
            let s = d.lists.networks[i].subnet();
            ui.p.label(cell, if s.is_empty() { "—" } else { s }, mono, t.ink);
        }
        (Kind::Networks, "col.id") => {
            ui.p.label(cell, short_id(&d.lists.networks[i].id), mono, t.ink2);
        }
        _ => {}
    }
}

/// app.js `rowActions`: icon buttons, right-aligned in `cell`. `detail`: leave out Logs.
pub fn row_actions(d: &mut Desktop, ui: &mut Ui, kind: Kind, i: usize, cell: Rect, base_id: Id, detail: bool) {
    let id = object_id(d, kind, i);
    let name = object_name(d, kind, i);
    let busy = d.busy.contains(&id);
    let mut buttons: Vec<(&'static str, Icon, IconKind, &'static str)> = Vec::new();
    if kind == Kind::Containers {
        let c = &d.lists.containers[i];
        match c.state.as_str() {
            "running" | "restarting" => {
                buttons.push(("stop", Icon::Stop, IconKind::Plain, "action.stop"));
                buttons.push(("restart", Icon::Restart, IconKind::Plain, "action.restart"));
                if d.features.pause {
                    buttons.push(("pause", Icon::Pause, IconKind::Plain, "action.pause"));
                }
            }
            "paused" => {
                if d.features.pause {
                    buttons.push(("unpause", Icon::Start, IconKind::Plain, "action.resume"));
                }
                buttons.push(("stop", Icon::Stop, IconKind::Plain, "action.stop"));
            }
            _ => buttons.push(("start", Icon::Start, IconKind::Accent, "action.start")),
        }
        if !detail {
            buttons.push(("logs", Icon::Logs, IconKind::Plain, "action.logs"));
        }
        if c.state == "running" {
            buttons.push(("shell", Icon::Shell, IconKind::Plain, "action.shell"));
        }
        if detail && d.features.rename {
            buttons.push(("rename", Icon::Rename, IconKind::Plain, "action.rename"));
        }
    }
    let builtin = kind == Kind::Networks && d.lists.networks[i].builtin();
    if !builtin {
        buttons.push(("remove", Icon::Remove, IconKind::Danger, "action.remove"));
    }
    let n = buttons.len() as f32;
    let mut x = cell.right() - n * 32. + 2.;
    let y = cell.y + (cell.h - 30.) / 2.;
    for (action, icon, ik, _label) in buttons {
        let r = Rect::new(x, y, 30., 30.);
        x += 32.;
        if !button::icon_button(ui, base_id.with(action), r, icon.id(), ik, !busy) {
            continue;
        }
        match action {
            "logs" => d.open_detail(kind, &id, Tab::Logs),
            "shell" => {
                if let Err(e) = d.api.open_shell(&id) {
                    d.toasts.push(e, true);
                }
            }
            "rename" => {
                let title = d.t("rename.title");
                let label = d.t("rename.label");
                let ok = d.t("action.rename");
                d.dialog = Some(Dialog::ask(title, label, &name, "", ok, AskFor::Rename(id.clone())));
            }
            "remove" => {
                let up = kind == Kind::Containers && d.lists.containers[i].is_up();
                d.ask_remove(kind, &id, &name, up);
            }
            action => d.act(&id, &name, action),
        }
        break;
    }
}

fn empty_state(d: &mut Desktop, ui: &mut Ui, r: Rect, kind: Kind) {
    let t = ui.theme;
    let cx = r.x + r.w / 2.;
    let mut y = r.y + 48.;
    let icon = match kind {
        Kind::Containers => Icon::Containers,
        Kind::Images => Icon::Images,
        Kind::Volumes => Icon::Volumes,
        Kind::Networks => Icon::Networks,
    };
    ui.p.rounded(Rect::new(cx - 32., y, 64., 64.), 16., t.accent_soft);
    ui.p.icon(icon.id(), Rect::new(cx - 16., y + 16., 32., 32.), t.accent_text);
    y += 76.;
    let h2 = ui.style().with_size(18.).weight(700);
    y += centered(ui, cx, y, &d.t(&format!("empty.{}.title", kind.as_str())), h2, t.ink) + 8.;
    let podbag = d.is_podbag();
    let docker = d.engine.as_ref().is_some_and(|e| e.engine == "docker");
    if podbag || docker || kind == Kind::Images {
        y += centered(ui, cx, y, &d.t(&format!("empty.{}.text", kind.as_str())), ui.style(), t.ink2) + 6.;
    }
    let cmd = if podbag { "podbag" } else { "docker" };
    let command = match kind {
        Kind::Containers => Some(format!("{cmd} run -d --name web -p 8080:80 nginx:alpine")),
        Kind::Volumes => Some(format!("{cmd} volume create data")),
        Kind::Networks => Some(format!("{cmd} network create app")),
        Kind::Images => None,
    };
    if let Some(command) = command.filter(|_| podbag || docker) {
        y += code_line(d, ui, cx, y, &command, Id::of("empty-code")) + 14.;
    }
    if kind == Kind::Images {
        let label = d.t("action.pull");
        let w = button::width(ui, &label, Some(Icon::Pull.id()), false);
        if button::button(ui, Id::of("empty-pull"), Rect::new(cx - w / 2., y + 8., w, 32.), &label, Some(Icon::Pull.id()), ButtonKind::Primary, true) {
            d.open_pull();
        }
    }
}
