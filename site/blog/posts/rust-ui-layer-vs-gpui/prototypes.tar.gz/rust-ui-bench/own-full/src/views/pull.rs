//! The pull panel (images.js): search Docker Hub or type a reference, pick a tag, choose
//! where to pull from, then watch the progress stream. Registry login is out of scope.

use std::time::{Duration, Instant};

use bench_api::{HubResult, Registry};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, Kind as ButtonKind};
use own_ui::widgets::text_field::{plain_field, text_field};
use own_ui::winit::keyboard::NamedKey;
use own_ui::{Color, CursorIcon, Id, Rect, TextInput, TextStyle, layer};

use crate::app::Desktop;
use crate::icons::Icon;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Step {
    Search,
    Tag,
    Host,
    Pulling,
    Done,
}

pub struct PullPanel {
    pub input: TextInput,
    pub location: String,
    pub locations: Vec<Registry>,
    pub results: Vec<HubResult>,
    pub active: usize,
    pub step: Step,
    pub chosen: Option<HubResult>,
    pub supported: bool,
    pub search_error: Option<String>,
    pub lines: Vec<String>,
    pub pulling: String,
    pub result: Option<Result<String, String>>,
    pub tag: TextInput,
    pub host: TextInput,
    pub menu_open: bool,
    pub menu_search: TextInput,
    search_at: Option<Instant>,
    after_host: Step,
}

fn input(id: &str, size: f32) -> TextInput {
    TextInput::new(Id::of(id), "", TextStyle::new(size).line_height((size * 1.45).round()), Color::TRANSPARENT)
}

/// A reference the user pasted whole: with a tag, a digest or a registry host.
fn looks_full(q: &str) -> bool {
    if q.contains(':') || q.contains('@') || q.starts_with("localhost/") {
        return true;
    }
    q.split_once('/').is_some_and(|(first, _)| first.contains('.') || first.contains(':'))
}

impl PullPanel {
    pub fn new(locations: Vec<Registry>, placeholder: &str) -> Self {
        let mut i = input("pull-input", 15.);
        i.set_placeholder(placeholder);
        Self {
            input: i,
            location: "dockerhub".into(),
            locations,
            results: Vec::new(),
            active: 0,
            step: Step::Search,
            chosen: None,
            supported: true,
            search_error: None,
            lines: Vec::new(),
            pulling: String::new(),
            result: None,
            tag: input("pull-tag", 14.),
            host: input("pull-host", 14.),
            menu_open: false,
            menu_search: input("loc-search", 13.),
            search_at: None,
            after_host: Step::Search,
        }
    }

    fn location(&self) -> Registry {
        self.locations.iter().find(|l| l.id == self.location).cloned().unwrap_or(Registry {
            id: "dockerhub".into(),
            label: "Docker Hub".into(),
            host: "docker.io".into(),
            host_example: None,
            needs_host: false,
            account: None,
            hint: None,
        })
    }

    /// A debounced search waits (the timer must paint then).
    pub fn waiting(&self) -> bool {
        self.search_at.is_some()
    }

    pub fn progress(&mut self, line: String) {
        self.lines.push(line);
        if self.lines.len() > 200 {
            self.lines.drain(..self.lines.len() - 200);
        }
    }

    pub fn done(&mut self, result: Result<String, String>) {
        self.step = Step::Done;
        self.result = Some(result);
    }

    /// The typed text changed: search Docker Hub after a short pause.
    fn on_input(&mut self) {
        self.active = 0;
        self.step = Step::Search;
        let q = self.input.content.trim().to_string();
        if q.is_empty() || looks_full(&q) || self.location != "dockerhub" || !self.supported {
            self.results.clear();
            self.search_at = None;
            return;
        }
        self.search_at = Some(Instant::now() + Duration::from_millis(300));
    }

    /// "Pull <typed>", then the search results.
    fn options(&self) -> Vec<(bool, HubResult)> {
        let q = self.input.content.trim();
        let mut out = Vec::new();
        if !q.is_empty() {
            let same = self.results.iter().find(|r| r.name == q).cloned();
            let mut typed = same.unwrap_or(HubResult { name: String::new(), description: String::new(), star_count: 0, is_official: false });
            typed.name = q.to_string();
            out.push((true, typed));
        }
        out.extend(self.results.iter().filter(|r| r.name != q).cloned().map(|r| (false, r)));
        out
    }
}

fn start_pull(d: &Desktop, p: &mut PullPanel, image: String) {
    let loc = p.location();
    if loc.needs_host && loc.host.is_empty() {
        p.after_host = Step::Search;
        p.host.set_content("");
        p.step = Step::Host;
        return;
    }
    p.step = Step::Pulling;
    p.lines = vec![d.tr.t("pull.working")];
    p.pulling = image.clone();
    p.result = None;
    let host = (!loc.host.is_empty()).then_some(loc.host.as_str());
    d.api.pull(&image, Some(&loc.id), host);
}

pub fn paint(d: &mut Desktop, ui: &mut Ui) {
    let t = ui.theme;
    let bounds = ui.bounds();
    let Some(mut p) = d.pull.take() else { return };
    // A debounced search that is due.
    if let Some(at) = p.search_at {
        if at <= Instant::now() {
            p.search_at = None;
            let q = p.input.content.trim().to_string();
            let r = d.api.search(&q);
            if p.location == "dockerhub" && p.input.content.trim() == q {
                p.supported = r.supported;
                p.search_error = r.error;
                p.results = r.results;
            }
        } else {
            ui.wake_at(at);
        }
    }
    let busy = p.step == Step::Pulling;
    let mut close = false;
    // Esc steps back first (a menu, the tag or host step), then closes.
    if ui.key_pressed(NamedKey::Escape).is_some() {
        if p.menu_open {
            p.menu_open = false;
        } else if matches!(p.step, Step::Tag | Step::Host) {
            p.step = Step::Search;
            ui.focus(Some(p.input.id));
        } else if !busy {
            close = true;
        }
    }
    let w = (bounds.w - 32.).min(560.);
    let panel_h = (bounds.h - 64. - 72.).min(560.);
    let card = Rect::new(bounds.right() - 24. - w, bounds.y + 72., w, panel_h);
    ui.on_layer(layer::MODAL, |ui| {
        ui.p.fill(bounds, t.backdrop);
        let backdrop = Id::of("pull-backdrop");
        ui.p.hitbox(bounds, backdrop, CursorIcon::Default);
        if ui.clicked(backdrop) && !busy {
            close = true;
        }
        ui.p.shadow(card, 12., 20., t.shadow);
        ui.p.bordered(card, 12., t.surface, 1., t.line);
        ui.p.hitbox(card, Id::of("pull-card"), CursorIcon::Default);
        let mut r = card;
        let head = r.cut_top(52.);
        let foot = r.cut_bottom(36.);
        ui.p.border_bottom(head, t.line);
        ui.p.fill(foot.with_h(1.), t.line);
        // Head: the input and where to pull from.
        let loc = p.location();
        let loc_label = if loc.id == "custom" && loc.host.is_empty() { d.tr.t("pull.myRegistry") } else { loc.label.clone() };
        let lstyle = ui.style().with_size(12.5).weight(600);
        let lw = ui.p.layout(&loc_label, lstyle, Some(180.)).width + 38.;
        let lb = Rect::new(head.right() - 10. - lw, head.y + 12., lw, 28.);
        let lid = Id::of("loc-button");
        ui.p.bordered(lb, 7., if ui.hovered(lid) { t.hover } else { t.sunken }, 1., t.line);
        ui.p.label(lb.inset(10., 0., 22., 0.), &loc_label, lstyle, t.ink);
        ui.p.icon(own_ui::icons::CHEVRON_DOWN, Rect::new(lb.right() - 19., lb.y + 7., 13., 13.), t.ink2);
        if !busy {
            ui.p.hitbox(lb, lid, CursorIcon::Pointer);
            if ui.clicked(lid) {
                p.menu_open = !p.menu_open;
                p.menu_search.set_content("");
                if p.menu_open {
                    ui.focus(Some(p.menu_search.id));
                }
            }
        }
        let searching = loc.id == "dockerhub" && p.supported;
        let placeholder = if searching { d.tr.t("pull.searchPlaceholder") } else { d.tr.tv("pull.refPlaceholder", &[("name", &loc.label)]) };
        p.input.set_placeholder(&placeholder);
        let input_r = Rect::new(head.x + 14., head.y + 10., lb.x - head.x - 24., 32.);
        if p.step == Step::Search && !p.menu_open && ui.p.focused().is_none() {
            ui.focus(Some(p.input.id));
        }
        if plain_field(ui, &mut p.input, input_r, Some(Icon::Search.id()), !busy) {
            p.on_input();
        }
        // Body.
        let body = r.inset(8., 8., 8., 8.);
        match p.step {
            Step::Search => search_body(d, ui, &mut p, body),
            Step::Tag => tag_body(d, ui, &mut p, body),
            Step::Host => host_body(d, ui, &mut p, body),
            Step::Pulling | Step::Done => {
                if progress_body(d, ui, &mut p, body) {
                    close = true;
                }
            }
        }
        // Foot: the keys.
        let style = ui.style().with_size(12.);
        let keys = format!(
            "↑ ↓ {}   Enter {}   Esc {}",
            d.tr.t("pull.keyMove"),
            d.tr.t("pull.keyPull"),
            d.tr.t("pull.keyClose")
        );
        ui.p.label(foot.inset(12., 0., 12., 0.), &keys, style, t.muted);
        let anywhere = format!("{} {}", if cfg!(target_os = "macos") { "⌘⇧P" } else { "Ctrl+Shift+P" }, d.tr.t("pull.keyAnywhere"));
        let aw = ui.p.layout(&anywhere, style, None).width;
        ui.p.label(Rect::new(foot.right() - 12. - aw, foot.y, aw + 2., foot.h), &anywhere, style, t.muted);
        if p.menu_open {
            location_menu(d, ui, &mut p, lb, card);
        }
    });
    if close {
        ui.focus(None);
        return;
    }
    d.pull = Some(p);
}

fn search_body(d: &mut Desktop, ui: &mut Ui, p: &mut PullPanel, body: Rect) {
    let t = ui.theme;
    let options = p.options();
    let mut y = body.y;
    let note = |ui: &mut Ui, y: &mut f32, text: &str, color: Color| {
        let h = ui.p.layout_wrapped(text, ui.style().with_size(13.), body.w - 40.).height + 20.;
        let r = Rect::new(body.x + 8., *y + 8., body.w - 16., h);
        ui.p.rounded(r, 8., t.sunken);
        ui.paragraph(r.x + 12., r.y + 10., r.w - 24., text, ui.style().with_size(13.), color);
        *y += h + 8.;
    };
    if !p.supported && p.location == "dockerhub" {
        note(ui, &mut y, &d.tr.t("pull.noSearch"), t.ink2);
    }
    if let Some(e) = p.search_error.clone() {
        note(ui, &mut y, &e, t.red);
    }
    if options.is_empty() {
        let key = if p.location == "dockerhub" && p.supported { "pull.hint" } else { "pull.hintRef" };
        note(ui, &mut y, &d.tr.t(key), t.ink2);
        return;
    }
    if p.active >= options.len() {
        p.active = 0;
    }
    if ui.key_pressed(NamedKey::ArrowDown).is_some() {
        p.active = (p.active + 1) % options.len();
    }
    if ui.key_pressed(NamedKey::ArrowUp).is_some() {
        p.active = (p.active + options.len() - 1) % options.len();
    }
    let mut chosen = if ui.key_pressed(NamedKey::Enter).is_some() { Some(p.active) } else { None };
    let name_style = ui.style().weight(600);
    let desc_style = ui.style().with_size(12.5);
    ui.clip(body, |ui| {
        for (i, (typed, o)) in options.iter().enumerate() {
            let h = if o.description.is_empty() { 40. } else { 54. };
            let r = Rect::new(body.x, y, body.w, h);
            y += h + 1.;
            let id = Id::of(("pull-option", i));
            if ui.hovered(id) && p.active != i {
                p.active = i;
                ui.repaint();
            }
            let on = i == p.active;
            if on {
                ui.p.rounded(r, 8., t.accent_soft);
            }
            let fg = if on { t.accent_text } else { t.ink2 };
            let icon = if *typed { Icon::Pull } else { Icon::Images };
            ui.p.icon(icon.id(), Rect::new(r.x + 10., r.y + (r.h - 18.) / 2., 18., 18.), fg);
            let mut right = r.right() - 10.;
            if !*typed || o.star_count > 0 {
                let stars = o.star_count.to_string();
                let sl = ui.p.layout(&stars, ui.style().with_size(12.), None);
                right -= sl.width;
                ui.p.draw_text(&sl, right, r.y + (r.h - sl.height) / 2., t.muted);
                right -= 17.;
                ui.p.icon(Icon::Star.id(), Rect::new(right, r.y + (r.h - 13.) / 2., 13., 13.), t.muted);
                right -= 10.;
            }
            let text = if *typed { d.tr.tv("pull.pullThis", &[("name", &o.name)]) } else { o.name.clone() };
            let ty = if o.description.is_empty() { r.y + 10. } else { r.y + 8. };
            let nl = ui.p.layout(&text, name_style, Some(right - r.x - 38.));
            ui.p.draw_text(&nl, r.x + 38., ty, t.ink);
            if o.is_official {
                let tag = d.tr.t("pull.official");
                let tl = ui.p.layout(&tag, TextStyle::new(11.).weight(600).line_height(16.), None);
                let tr = Rect::new(r.x + 44. + nl.width, ty + 2., tl.width + 12., 16.);
                ui.p.rounded(tr, 4., t.green_soft);
                ui.p.draw_text(&tl, tr.x + 6., tr.y, t.green);
            }
            if !o.description.is_empty() {
                ui.p.label(Rect::new(r.x + 38., ty + 22., right - r.x - 38., 18.), &o.description, desc_style, t.ink2);
            }
            ui.p.hitbox(r, id, CursorIcon::Pointer);
            if ui.clicked(id) {
                chosen = Some(i);
            }
        }
    });
    if let Some(i) = chosen {
        let (typed, o) = options[i].clone();
        if typed {
            start_pull(d, p, o.name);
        } else {
            p.chosen = Some(o);
            p.tag.set_content("latest");
            p.tag.select_all();
            p.step = Step::Tag;
            ui.focus(Some(p.tag.id));
        }
    }
}

fn form_label(ui: &mut Ui, r: Rect, text: &str) {
    let style = ui.style().with_size(13.).weight(600);
    let ink = ui.theme.ink;
    ui.p.label(r, text, style, ink);
}

fn tag_body(d: &mut Desktop, ui: &mut Ui, p: &mut PullPanel, body: Rect) {
    let name = p.chosen.as_ref().map(|c| c.name.clone()).unwrap_or_default();
    let r = body.inset(8., 8., 8., 0.);
    form_label(ui, r.with_h(20.), &d.tr.tv("pull.tagFor", &[("name", &name)]));
    text_field(ui, &mut p.tag, Rect::new(r.x, r.y + 28., r.w, 34.), None, true);
    let label = d.tr.t("action.pull");
    let w = button::width(ui, &label, None, false);
    let enter = ui.key_pressed(NamedKey::Enter).is_some();
    if button::button(ui, Id::of("pull-tag-go"), Rect::new(r.right() - w, r.y + 76., w, 32.), &label, None, ButtonKind::Primary, true) || enter {
        let tag = p.tag.content.trim();
        let image = format!("{name}:{}", if tag.is_empty() { "latest" } else { tag });
        start_pull(d, p, image);
    }
}

fn host_body(d: &mut Desktop, ui: &mut Ui, p: &mut PullPanel, body: Rect) {
    let loc = p.location();
    let r = body.inset(8., 8., 8., 0.);
    form_label(ui, r.with_h(20.), &d.tr.tv("pull.host", &[("name", &loc.label)]));
    p.host.set_placeholder(loc.host_example.as_deref().unwrap_or("registry.example.com"));
    ui.focus(Some(p.host.id));
    text_field(ui, &mut p.host, Rect::new(r.x, r.y + 28., r.w, 34.), None, true);
    let label = d.tr.t("action.save");
    let w = button::width(ui, &label, None, false);
    let enter = ui.key_pressed(NamedKey::Enter).is_some();
    if button::button(ui, Id::of("pull-host-save"), Rect::new(r.right() - w, r.y + 76., w, 32.), &label, None, ButtonKind::Primary, true) || enter {
        let v = p.host.content.trim().to_string();
        if v.is_empty() {
            return;
        }
        d.pull_hosts.retain(|(id, _)| *id != loc.id);
        d.pull_hosts.push((loc.id.clone(), v));
        p.locations = d.api.registries(&d.pull_hosts);
        p.step = p.after_host;
        ui.focus(Some(p.input.id));
    }
}

/// Returns true to close the panel.
fn progress_body(d: &mut Desktop, ui: &mut Ui, p: &mut PullPanel, body: Rect) -> bool {
    let t = ui.theme;
    let r = body.inset(8., 8., 8., 0.);
    if p.step == Step::Pulling {
        let title = d.tr.tv("pull.pulling", &[("name", &p.pulling)]);
        let h = ui.paragraph(r.x, r.y, r.w, &title, ui.style().weight(600), t.ink);
        let log = Rect::new(r.x, r.y + h + 8., r.w, (r.h - h - 16.).min(260.));
        ui.p.rounded(log, 8., t.sunken);
        let mono = TextStyle::new(12.).mono().line_height(18.);
        let start = p.lines.len().saturating_sub(12);
        let text = p.lines[start..].join("\n");
        ui.clip(log, |ui| ui.paragraph(log.x + 12., log.y + 10., log.w - 24., &text, mono, t.ink));
        return false;
    }
    let (ok, text) = match &p.result {
        Some(Ok(name)) => (true, d.tr.tv("done.pull", &[("name", name)])),
        Some(Err(e)) => (false, e.clone()),
        None => (true, String::new()),
    };
    let style = if ok { ui.style().weight(600) } else { ui.style() };
    let h = ui.paragraph(r.x, r.y, r.w, &text, style, if ok { t.ink } else { t.red });
    let close_label = d.tr.t("pull.close");
    let another = d.tr.t("pull.another");
    let cw = button::width(ui, &close_label, None, false);
    let aw = button::width(ui, &another, None, false);
    let y = r.y + h + 16.;
    let enter = ui.key_pressed(NamedKey::Enter).is_some();
    if button::button(ui, Id::of("pull-close"), Rect::new(r.right() - cw, y, cw, 32.), &close_label, None, ButtonKind::Primary, true) || enter {
        return true;
    }
    if button::button(ui, Id::of("pull-another"), Rect::new(r.right() - cw - 8. - aw, y, aw, 32.), &another, None, ButtonKind::Normal, true) {
        p.step = Step::Search;
        p.result = None;
        p.input.set_content("");
        p.results.clear();
        ui.focus(Some(p.input.id));
    }
    false
}

fn location_menu(d: &mut Desktop, ui: &mut Ui, p: &mut PullPanel, button_r: Rect, card: Rect) {
    let t = ui.theme;
    let w = (card.w - 20.).min(400.);
    let h = (ui.bounds().bottom() - button_r.bottom() - 40.).min(420.);
    let menu = Rect::new(card.right() - 10. - w, button_r.bottom() + 8., w, h);
    let menu_id = Id::of("loc-menu");
    ui.on_layer(layer::MODAL_POPUP, |ui| {
        ui.p.shadow(menu, 10., 14., t.shadow);
        ui.p.bordered(menu, 10., t.surface, 1., t.line);
        ui.p.hitbox(menu, menu_id, CursorIcon::Default);
        let inner = menu.inset(6., 6., 6., 6.);
        let title_style = ui.style().with_size(11.5).weight(600);
        ui.p.label(Rect::new(inner.x + 8., inner.y + 2., inner.w, 18.), &d.tr.t("pull.location"), title_style, t.muted);
        ui.focus(Some(p.menu_search.id));
        text_field(ui, &mut p.menu_search, Rect::new(inner.x + 4., inner.y + 24., inner.w - 8., 30.), None, true);
        let terms: Vec<String> = p.menu_search.content.trim().to_lowercase().split_whitespace().map(str::to_string).collect();
        let list = Rect::new(inner.x, inner.y + 60., inner.w, inner.h - 60.);
        let mut y = list.y;
        let label_style = ui.style().with_size(13.5);
        let mut pick = None;
        ui.clip(list, |ui| {
            for l in &p.locations {
                let label = if l.needs_host && !l.host.is_empty() {
                    format!("{} ({})", l.label, l.host)
                } else if l.id == "custom" {
                    d.tr.t("pull.myRegistry")
                } else {
                    l.label.clone()
                };
                let hay = [label.as_str(), &l.id, &l.host, l.host_example.as_deref().unwrap_or("")].join(" ").to_lowercase();
                if !terms.iter().all(|t| hay.contains(t)) && l.id != "custom" {
                    continue;
                }
                let r = Rect::new(list.x, y, list.w, 32.);
                y += 33.;
                if r.y > list.bottom() {
                    continue;
                }
                let id = Id::of(("loc", l.id.as_str()));
                let chosen = l.id == p.location;
                if chosen || ui.hovered(id) {
                    ui.p.rounded(r, 7., t.hover);
                }
                ui.p.label(r.inset(36., 0., 30., 0.), &label, label_style, t.ink);
                if chosen {
                    ui.p.icon(own_ui::icons::CHECK, Rect::new(r.right() - 24., r.y + 9., 15., 15.), t.accent_text);
                }
                if let Some(acc) = &l.account {
                    let al = ui.p.layout(acc, ui.style().with_size(12.), None);
                    ui.p.draw_text(&al, r.right() - 34. - al.width, r.y + (r.h - al.height) / 2., t.ink2);
                }
                ui.p.icon(Icon::Images.id(), Rect::new(r.x + 10., r.y + 7., 18., 18.), t.ink2);
                ui.p.hitbox(r, id, CursorIcon::Pointer);
                if ui.clicked(id) {
                    pick = Some(l.clone());
                }
            }
        });
        if let Some(l) = pick {
            p.location = l.id.clone();
            p.results.clear();
            p.menu_open = false;
            if l.needs_host {
                p.after_host = Step::Search;
                p.host.set_content(&l.host);
                p.step = Step::Host;
            } else {
                p.on_input();
                ui.focus(Some(p.input.id));
            }
        }
    });
    if ui.key_pressed(NamedKey::Enter).is_some() {
        p.menu_open = false;
    }
}
