//! The window's state and the shell: top bar, sidebar, status bar, history, timers,
//! backend events and the benchmark hooks. The pages are in `views`.

use std::collections::HashSet;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use bench_api::i18n::I18n;
use bench_api::{
    Backend, Connection, Container, DockerCommand, EngineInfo, Event as ApiEvent, Features, Image, Kind,
    KubeCounts, KubeKind, Network, Settings, Updates, VmStatus, Volume, fmt,
};
use own_ui::ui::{Theme, Ui, UiApp};
use own_ui::widgets::button::{self, IconKind};
use own_ui::widgets::logs::LogView;
use own_ui::widgets::scroll::ScrollState;
use own_ui::widgets::toast::Toasts;
use own_ui::winit::keyboard::NamedKey;
use own_ui::{Color, CursorIcon, Cx, Id, Rect, TextInput, TextStyle, VirtualList};

use crate::dialogs::{self, Dialog};
use crate::icons::Icon;
use crate::theme;
use crate::views;

const SIDEBAR_MIN: f32 = 160.;
const SIDEBAR_MAX: f32 = 360.;
const RAIL: f32 = 56.;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Page {
    Migrate,
    Containers,
    Images,
    Volumes,
    Networks,
    Training,
    Kubernetes,
    Settings,
}

impl Page {
    pub fn kind(self) -> Option<Kind> {
        match self {
            Page::Containers => Some(Kind::Containers),
            Page::Images => Some(Kind::Images),
            Page::Volumes => Some(Kind::Volumes),
            Page::Networks => Some(Kind::Networks),
            _ => None,
        }
    }

    pub fn of(kind: Kind) -> Page {
        match kind {
            Kind::Containers => Page::Containers,
            Kind::Images => Page::Images,
            Kind::Volumes => Page::Volumes,
            Kind::Networks => Page::Networks,
        }
    }

    /// The names of the `nav <view>` command.
    pub fn parse(name: &str) -> Option<Page> {
        Some(match name {
            "containers" => Page::Containers,
            "images" => Page::Images,
            "volumes" => Page::Volumes,
            "networks" => Page::Networks,
            "kubernetes" => Page::Kubernetes,
            "settings" => Page::Settings,
            "training" | "tutorials" => Page::Training,
            "migrate" | "migration" => Page::Migrate,
            _ => return None,
        })
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tab {
    Info,
    Logs,
    Inspect,
}

impl Tab {
    pub fn key(self) -> &'static str {
        match self {
            Tab::Info => "detail.info",
            Tab::Logs => "detail.logs",
            Tab::Inspect => "detail.inspect",
        }
    }
}

pub struct Detail {
    pub kind: Kind,
    pub id: String,
    pub tab: Tab,
    /// Inspect JSON, as lines.
    pub inspect: LogView,
    pub inspect_loaded: bool,
}

#[derive(Clone, PartialEq, Debug)]
struct Entry {
    page: Page,
    detail: Option<(Kind, String, Tab)>,
    kube: KubeKind,
}

pub enum Msg {
    Stdin(String),
    Api(ApiEvent),
}

enum Pending {
    First(Instant),
    Filter(Instant),
    View(Page, Instant),
}

/// The lists of the engine, plus a lower-case search text per item.
#[derive(Default)]
pub struct Lists {
    pub containers: Vec<Container>,
    pub images: Vec<Image>,
    pub volumes: Vec<Volume>,
    pub networks: Vec<Network>,
    pub hay: [Vec<String>; 4],
    pub errors: [Option<String>; 4],
    /// Filtered indices per kind, for the current search text.
    pub shown: [Vec<usize>; 4],
    shown_for: [Option<String>; 4],
}

impl Lists {
    pub fn len(&self, kind: Kind) -> usize {
        match kind {
            Kind::Containers => self.containers.len(),
            Kind::Images => self.images.len(),
            Kind::Volumes => self.volumes.len(),
            Kind::Networks => self.networks.len(),
        }
    }

    /// app.js `matches`, with the fields lower-cased once per refresh.
    fn build_hay(&mut self) {
        let lower = |v: Vec<&str>| v.join("\n").to_lowercase();
        self.hay[0] = self
            .containers
            .iter()
            .map(|c| lower(vec![c.name(), &c.image, &c.id, &c.state, &c.ports_text()]))
            .collect();
        self.hay[1] = self
            .images
            .iter()
            .map(|i| lower(i.repo_tags.iter().map(|s| s.as_str()).chain([i.id.as_str()]).collect()))
            .collect();
        self.hay[2] = self.volumes.iter().map(|v| lower(vec![&v.name, &v.driver])).collect();
        self.hay[3] = self.networks.iter().map(|n| lower(vec![&n.name, &n.driver, &n.id, n.subnet()])).collect();
        self.shown_for = Default::default();
    }

    /// Recompute the filtered indices if the search text changed.
    pub fn filter(&mut self, kind: Kind, q: &str) -> &[usize] {
        let i = kind_index(kind);
        let q = q.trim().to_lowercase();
        if self.shown_for[i].as_deref() != Some(q.as_str()) {
            self.shown[i] = self.hay[i].iter().enumerate().filter(|(_, h)| q.is_empty() || h.contains(&q)).map(|(i, _)| i).collect();
            self.shown_for[i] = Some(q);
        }
        &self.shown[i]
    }
}

pub fn kind_index(kind: Kind) -> usize {
    match kind {
        Kind::Containers => 0,
        Kind::Images => 1,
        Kind::Volumes => 2,
        Kind::Networks => 3,
    }
}

pub struct VmForm {
    pub cpus: TextInput,
    pub memory: TextInput,
    pub idle: TextInput,
    pub dirty: bool,
    pub error: String,
}

pub struct Desktop {
    pub api: Backend,
    pub tr: I18n,
    pub lang: &'static str,
    pub page: Page,
    pub detail: Option<Detail>,
    pub connection: Connection,
    pub contexts: Vec<String>,
    pub engine: Option<EngineInfo>,
    pub lists: Lists,
    pub loaded: bool,
    pub live: bool,
    pub features: Features,
    pub settings: Settings,
    pub busy: HashSet<String>,
    pub search: [TextInput; 4],
    pub tables: [VirtualList; 4],
    pub logs: LogView,
    pub logs_generation: u64,
    pub vm: Option<VmStatus>,
    pub vm_busy: bool,
    pub vm_form: VmForm,
    pub updates: Option<Updates>,
    pub docker: Option<DockerCommand>,
    pub docker_switching: Option<String>,
    pub launch_at_login: Option<bool>,
    pub kube: views::kubernetes::KubeState,
    pub kube_counts: Option<KubeCounts>,
    pub kube_expanded: bool,
    pub dialog: Option<Dialog>,
    pub pull: Option<views::pull::PullPanel>,
    pub pull_hosts: Vec<(String, String)>,
    pub toasts: Toasts,
    pub sidebar_w: f32,
    pub collapsed: bool,
    sidebar_drag: Option<(f32, f32)>,
    pub settings_scroll: ScrollState,
    pub detail_scroll: ScrollState,
    pub open_sections: HashSet<&'static str>,
    history: Vec<Entry>,
    history_at: usize,
    pending: Option<Pending>,
    refresh_at: Option<Instant>,
    poll_at: Instant,
    vm_poll_at: Instant,
    t0: Instant,
}

impl Desktop {
    pub fn new(api: Backend, t0: Instant) -> Self {
        // Work around bench-api: it starts with no engine selected (""), where mock.js
        // selects the scenario's engine.
        if api.connection().name.is_empty() {
            let engine = if api.options().scenario == bench_api::Scenario::Docker { "docker" } else { "podbag" };
            let _ = api.set_engine(engine);
        }
        let settings = api.get_settings();
        let tr = I18n::new(&settings.language);
        let lang = tr.lang();
        let search_style = TextStyle::new(14.).line_height(20.);
        let search = std::array::from_fn(|i| TextInput::new(Id::of(("search", i)), "Search", search_style, Color::TRANSPARENT));
        let num = |name: &str| TextInput::new(Id::of(("vm", name)), "", search_style, Color::TRANSPARENT);
        let now = Instant::now();
        let mut d = Self {
            connection: api.connection(),
            contexts: api.contexts(),
            api,
            tr,
            lang,
            page: Page::Containers,
            detail: None,
            engine: None,
            lists: Lists::default(),
            loaded: false,
            live: false,
            features: Features::default(),
            sidebar_w: (settings.sidebar_width as f32).clamp(SIDEBAR_MIN, SIDEBAR_MAX),
            collapsed: settings.sidebar_collapsed,
            settings,
            busy: HashSet::new(),
            search,
            tables: std::array::from_fn(|i| VirtualList::new(if i == 0 { 58. } else { 40. }, 40.)),
            logs: LogView::default(),
            logs_generation: 0,
            vm: None,
            vm_busy: false,
            vm_form: VmForm { cpus: num("cpus"), memory: num("memory"), idle: num("idle"), dirty: false, error: String::new() },
            updates: None,
            docker: None,
            docker_switching: None,
            launch_at_login: None,
            kube: views::kubernetes::KubeState::new(),
            kube_counts: None,
            kube_expanded: false,
            dialog: None,
            pull: None,
            pull_hosts: Vec::new(),
            toasts: Toasts::default(),
            sidebar_drag: None,
            settings_scroll: ScrollState::default(),
            detail_scroll: ScrollState::default(),
            open_sections: HashSet::new(),
            history: Vec::new(),
            history_at: 0,
            pending: None,
            refresh_at: None,
            poll_at: now + Duration::from_secs(3),
            vm_poll_at: now + Duration::from_secs(5),
            t0,
        };
        d.relabel();
        d.updates = Some(d.api.updates());
        d.launch_at_login = d.api.launch_at_login().ok();
        d.connect(false);
        // The rows are in the UI layer from here on; RENDER counts from this point.
        d.pending = Some(Pending::First(Instant::now()));
        d.refresh_kube_counts();
        d.remember();
        d
    }

    // ---- strings ----

    pub fn t(&self, key: &str) -> String {
        self.tr.t(key)
    }

    pub fn tv(&self, key: &str, vars: &[(&str, &dyn std::fmt::Display)]) -> String {
        self.tr.tv(key, vars)
    }

    pub fn now(&self) -> i64 {
        SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_secs() as i64)
    }

    pub fn ago(&self, when: i64) -> String {
        fmt::ago(when, self.now(), self.lang)
    }

    /// Texts kept inside widgets (placeholders) follow the language.
    fn relabel(&mut self) {
        let placeholder = self.t("search.placeholder");
        for s in &mut self.search {
            s.set_placeholder(&placeholder);
        }
        self.kube.search.set_placeholder(&placeholder);
    }

    pub fn set_language(&mut self, setting: &str, ui: &mut Ui) {
        self.settings.language = setting.to_string();
        self.save_settings();
        self.lang = self.tr.load(setting);
        ui.p.text.set_language(self.lang);
        self.relabel();
    }

    pub fn save_settings(&mut self) {
        if let Err(e) = self.api.set_settings(&self.settings) {
            self.toasts.push(e, true);
        }
    }

    // ---- engine and data ----

    pub fn is_podbag(&self) -> bool {
        self.engine.as_ref().is_none_or(|e| e.engine == "podbag")
    }

    pub fn has_vm(&self) -> bool {
        self.is_podbag() && self.engine.as_ref().is_some_and(|e| e.platform != "linux")
    }

    pub fn reachable(&self) -> bool {
        self.engine.as_ref().is_some_and(|e| e.reachable)
    }

    pub fn connect(&mut self, start_vm: bool) {
        self.engine = Some(self.api.engine(start_vm));
        self.refresh_vm();
        self.docker = self.api.docker_command();
        if self.reachable() {
            self.refresh();
            self.api.watch(true);
        } else {
            self.loaded = false;
        }
    }

    /// After an engine switch: read the connection again (app.js reloads the page).
    pub fn reconnect(&mut self) {
        self.connection = self.api.connection();
        self.contexts = self.api.contexts();
        self.features = Features::default();
        self.detail = None;
        self.connect(false);
    }

    /// The search text of a list changed (typed).
    pub fn on_search(&mut self, kind: Kind) {
        if kind == Kind::Containers {
            self.pending = Some(Pending::Filter(Instant::now()));
            let q = self.search[0].content.clone();
            self.lists.filter(Kind::Containers, &q);
        }
    }

    pub fn refresh(&mut self) {
        let l = &mut self.lists;
        let mut ok = false;
        macro_rules! load {
            ($field:ident, $call:ident, $i:expr) => {
                match self.api.$call() {
                    Ok(v) => {
                        l.$field = v;
                        l.errors[$i] = None;
                        ok = true;
                    }
                    Err(e) => {
                        l.$field = Vec::new();
                        l.errors[$i] = Some(e);
                    }
                }
            };
        }
        load!(containers, containers, 0);
        load!(images, images, 1);
        load!(volumes, volumes, 2);
        load!(networks, networks, 3);
        l.build_hay();
        self.loaded = ok;
        if !ok && let Some(e) = &mut self.engine {
            e.reachable = false;
            e.error = self.lists.errors[0].clone();
        }
        if self.loaded && self.lists.errors[0].is_none() && self.features == Features::default() {
            let sample = self.lists.containers.iter().find(|c| c.state == "running").map(|c| c.id.clone());
            self.features = self.api.features(sample.as_deref());
        }
        if let Some(d) = &self.detail
            && !self.exists(d.kind, &d.id)
        {
            self.close_detail();
        }
    }

    pub fn refresh_soon(&mut self) {
        self.refresh_at = Some(Instant::now() + Duration::from_millis(200));
    }

    pub fn refresh_vm(&mut self) {
        self.vm = if self.has_vm() { self.api.vm_status() } else { None };
        if !self.vm_form.dirty {
            views::settings::fill_vm_form(self);
        }
    }

    pub fn refresh_kube_counts(&mut self) {
        let ctx = self.kube.context.clone();
        self.kube_counts = self.api.kube_counts(ctx.as_deref(), self.kube.all_namespaces).ok();
    }

    pub fn exists(&self, kind: Kind, id: &str) -> bool {
        match kind {
            Kind::Containers => self.lists.containers.iter().any(|c| c.id == id),
            Kind::Images => self.lists.images.iter().any(|i| i.id == id),
            Kind::Volumes => self.lists.volumes.iter().any(|v| v.name == id),
            Kind::Networks => self.lists.networks.iter().any(|n| n.id == id),
        }
    }

    // ---- actions ----

    pub fn act(&mut self, id: &str, name: &str, action: &str) {
        match self.api.act(id, action) {
            Ok(()) => {
                let text = self.tv(&format!("done.{action}"), &[("name", &name)]);
                self.toasts.push(text, false);
            }
            Err(e) => self.toasts.push(e, true),
        }
        self.refresh_soon();
    }

    pub fn ask_remove(&mut self, kind: Kind, id: &str, name: &str, up: bool) {
        let key = match kind {
            Kind::Containers if up => "confirm.removeRunning",
            Kind::Containers => "confirm.removeContainer",
            Kind::Images => "confirm.removeImage",
            Kind::Volumes => "confirm.removeVolume",
            Kind::Networks => "confirm.removeNetwork",
        };
        let text = self.tv(key, &[("name", &name)]);
        self.dialog = Some(Dialog::confirm(self, text, None, dialogs::Then::Remove { kind, id: id.into(), name: name.into(), force: up }));
    }

    pub fn remove(&mut self, kind: Kind, id: &str, name: &str, force: bool) {
        match self.api.remove(kind, id, force) {
            Ok(()) => {
                let text = self.tv("done.remove", &[("name", &name)]);
                self.toasts.push(text, false);
                if self.detail.as_ref().is_some_and(|d| d.id == id) {
                    self.close_detail();
                }
            }
            Err(e) => self.toasts.push(e, true),
        }
        self.refresh_soon();
    }

    pub fn ask_prune(&mut self, kind: Kind) {
        let key = match kind {
            Kind::Containers => "confirm.pruneContainers",
            Kind::Images => "confirm.pruneImages",
            Kind::Volumes => "confirm.pruneVolumes",
            Kind::Networks => "confirm.pruneNetworks",
        };
        let text = self.t(key);
        let yes = self.t("action.prune");
        self.dialog = Some(Dialog::confirm(self, text, Some(yes), dialogs::Then::Prune(kind)));
    }

    pub fn prune(&mut self, kind: Kind) {
        match self.api.prune(kind) {
            Ok(p) => {
                let size = fmt::size(p.bytes, self.lang);
                let text = self.tv("done.prune", &[("n", &p.count), ("size", &size)]);
                self.toasts.push(text, false);
            }
            Err(e) => self.toasts.push(e, true),
        }
        self.refresh_soon();
    }

    pub fn vm_action(&mut self, action: &str) {
        let n = self.vm.as_ref().and_then(|v| v.containers).unwrap_or(0);
        if (action == "stop" || action == "restart") && n > 0 && !matches!(self.dialog, Some(Dialog::Confirm { .. })) {
            let key = if action == "stop" { "confirm.stopVm" } else { "confirm.restartVm" };
            let text = self.tv(key, &[("n", &n)]);
            let yes = self.t(if action == "stop" { "action.stopVm" } else { "action.restartVm" });
            self.dialog = Some(Dialog::confirm(self, text, Some(yes), dialogs::Then::Vm(action.into())));
            return;
        }
        self.run_vm_action(action);
    }

    pub fn run_vm_action(&mut self, action: &str) {
        self.vm_busy = true;
        if let Err(e) = self.api.vm(action) {
            self.toasts.push(e, true);
        }
        self.vm_busy = false;
        self.refresh_vm();
    }

    pub fn copy(&mut self, text: &str, ui: &mut Ui) {
        ui.p.clipboard().write(text.to_string());
        let t = self.t("action.copied");
        self.toasts.push(t, false);
    }

    // ---- navigation ----

    pub fn go(&mut self, page: Page) {
        if self.detail.is_some() {
            self.close_detail_quiet();
        }
        if page == Page::Kubernetes {
            self.kube_expanded = true;
            if self.page != Page::Kubernetes {
                self.kube.load(&self.api);
            }
        }
        self.page = page;
        self.remember();
    }

    pub fn go_kube(&mut self, kind: KubeKind) {
        let changed = kind != self.kube.kind || self.page != Page::Kubernetes;
        if self.detail.is_some() {
            self.close_detail_quiet();
        }
        self.kube.kind = kind;
        self.kube_expanded = true;
        self.page = Page::Kubernetes;
        if changed {
            self.kube.search.set_content("");
            self.kube.load(&self.api);
        }
        self.remember();
    }

    pub fn open_detail(&mut self, kind: Kind, id: &str, tab: Tab) {
        if self.detail.as_ref().is_some_and(|d| d.tab == Tab::Logs) {
            self.api.logs_stop();
        }
        self.page = Page::of(kind);
        self.detail = Some(Detail { kind, id: id.into(), tab, inspect: LogView::default(), inspect_loaded: false });
        self.detail_scroll = ScrollState::default();
        self.enter_tab();
        self.remember();
    }

    /// Start what a detail tab needs (logs stream, inspect JSON).
    pub fn enter_tab(&mut self) {
        let Some(d) = &mut self.detail else { return };
        match d.tab {
            Tab::Logs => {
                self.logs.clear();
                self.logs_generation = self.api.logs_start(&d.id);
            }
            Tab::Inspect if !d.inspect_loaded => {
                let text = match self.api.inspect(d.kind, &d.id) {
                    Ok(v) => bench_api::pretty_json(&v),
                    Err(e) => e,
                };
                d.inspect.follow = false;
                d.inspect.push(text.lines().map(str::to_string));
                d.inspect_loaded = true;
            }
            _ => {}
        }
    }

    pub fn set_tab(&mut self, tab: Tab) {
        let Some(d) = &mut self.detail else { return };
        if d.tab == Tab::Logs && tab != Tab::Logs {
            self.api.logs_stop();
        }
        d.tab = tab;
        self.enter_tab();
    }

    pub fn close_detail(&mut self) {
        self.close_detail_quiet();
        self.remember();
    }

    fn close_detail_quiet(&mut self) {
        if self.detail.as_ref().is_some_and(|d| d.tab == Tab::Logs) {
            self.api.logs_stop();
        }
        self.detail = None;
    }

    fn entry(&self) -> Entry {
        Entry { page: self.page, detail: self.detail.as_ref().map(|d| (d.kind, d.id.clone(), d.tab)), kube: self.kube.kind }
    }

    fn remember(&mut self) {
        let e = self.entry();
        if self.history.get(self.history_at) == Some(&e) {
            return;
        }
        self.history.truncate(self.history_at + 1);
        self.history.push(e);
        if self.history.len() > 50 {
            self.history.remove(0);
        }
        self.history_at = self.history.len() - 1;
    }

    pub fn can_travel(&self, step: isize) -> bool {
        let i = self.history_at as isize + step;
        i >= 0 && (i as usize) < self.history.len()
    }

    pub fn travel(&mut self, step: isize) {
        if !self.can_travel(step) {
            return;
        }
        self.history_at = (self.history_at as isize + step) as usize;
        let e = self.history[self.history_at].clone();
        self.close_detail_quiet();
        self.page = e.page;
        if e.page == Page::Kubernetes && e.kube != self.kube.kind {
            self.kube.kind = e.kube;
            self.kube.load(&self.api);
        }
        if let Some((kind, id, tab)) = e.detail {
            self.detail = Some(Detail { kind, id, tab, inspect: LogView::default(), inspect_loaded: false });
            self.enter_tab();
        }
    }

    pub fn toggle_sidebar(&mut self) {
        self.collapsed = !self.collapsed;
        self.settings.sidebar_collapsed = self.collapsed;
        self.save_settings();
    }

    pub fn theme(&self, system_dark: bool) -> Theme {
        let dark = match self.settings.theme.as_str() {
            "dark" => true,
            "light" => false,
            _ => system_dark,
        };
        if dark { theme::dark() } else { theme::light() }
    }

    // ---- events, timers, the benchmark ----

    fn api_event(&mut self, ev: ApiEvent) {
        match ev {
            ApiEvent::Changed => self.refresh_soon(),
            ApiEvent::Live(on) => self.live = on,
            ApiEvent::Logs { generation, lines } => {
                if generation == self.logs_generation || self.logs_generation == 0 {
                    self.logs.push(lines);
                }
            }
            ApiEvent::PullProgress(line) => {
                if let Some(p) = &mut self.pull {
                    p.progress(line);
                }
            }
            ApiEvent::PullDone(result) => {
                if let Ok(name) = &result {
                    let text = self.tv("done.pull", &[("name", name)]);
                    self.toasts.push(text, false);
                    self.refresh_soon();
                }
                if let Some(p) = &mut self.pull {
                    p.done(result);
                }
            }
            ApiEvent::EngineChanged(_) => self.connect(false),
            ApiEvent::VmStatus(state) => {
                if let Some(e) = &mut self.engine
                    && e.vm.as_deref() != Some(state.as_str())
                {
                    e.vm = Some(state.clone());
                    if state == "stopped" {
                        e.reachable = false;
                        self.loaded = false;
                        self.api.watch(false);
                    } else if !e.reachable {
                        self.connect(false);
                    }
                    self.refresh_vm();
                }
            }
            ApiEvent::DockerSwitching(to) => self.docker_switching = Some(to),
            ApiEvent::DockerChanged(cmd) => {
                self.docker_switching = None;
                self.docker = Some(cmd);
            }
        }
    }

    fn command(&mut self, line: &str, cx: &mut Cx) {
        let line = line.trim();
        if line == "quit" {
            cx.quit();
        } else if let Some(q) = line.strip_prefix("filter ") {
            let start = Instant::now();
            if self.page != Page::Containers || self.detail.is_some() {
                self.go(Page::Containers);
            }
            self.search[0].set_content(q);
            self.lists.filter(Kind::Containers, q);
            self.pending = Some(Pending::Filter(start));
        } else if let Some(name) = line.strip_prefix("nav ") {
            let start = Instant::now();
            if let Some(page) = Page::parse(name.trim()) {
                self.go(page);
                self.pending = Some(Pending::View(page, start));
            }
        }
        cx.notify();
    }

    /// Run what is due; returns true if something changed on screen.
    fn timers(&mut self) -> bool {
        let now = Instant::now();
        let mut changed = false;
        if self.refresh_at.is_some_and(|t| t <= now) {
            self.refresh_at = None;
            self.refresh();
            changed = true;
        }
        if self.poll_at <= now {
            self.poll_at = now + Duration::from_secs(3);
            if !self.live && self.reachable() {
                self.refresh();
                changed = true;
            }
        }
        if self.vm_poll_at <= now {
            self.vm_poll_at = now + Duration::from_secs(5);
            if self.has_vm() {
                let old = self.vm.clone();
                self.refresh_vm();
                changed |= old != self.vm;
            }
        }
        changed
    }

    fn next_due(&self) -> Instant {
        let mut t = self.vm_poll_at;
        if !self.live {
            t = t.min(self.poll_at);
        }
        if let Some(r) = self.refresh_at {
            t = t.min(r);
        }
        t
    }

    fn report(&mut self, ui: &mut Ui) {
        let Some(p) = self.pending.take() else { return };
        let t0 = self.t0;
        let visible = self.lists.shown[0].len();
        ui.p.on_next_frame(move || {
            let ms = |i: Instant| i.elapsed().as_secs_f64() * 1000.;
            match p {
                Pending::First(start) => {
                    crate::emit(format!("READY {:.1}", ms(t0)));
                    crate::emit(format!("RENDER {:.1}", ms(start)));
                }
                Pending::Filter(start) => crate::emit(format!("FILTER {:.1} {visible}", ms(start))),
                Pending::View(page, start) => {
                    crate::emit(format!("VIEW {} {:.1}", format!("{page:?}").to_lowercase(), ms(start)))
                }
            }
        });
    }

    fn keys(&mut self, ui: &mut Ui) {
        let in_dialog = self.dialog.is_some() || self.pull.is_some();
        let mac = cfg!(target_os = "macos");
        let keys: Vec<(usize, own_ui::winit::event::KeyEvent, own_ui::winit::keyboard::ModifiersState)> =
            ui.keys().map(|(i, e, m)| (i, e.clone(), m)).collect();
        for (i, e, m) in keys {
            let letter = own_ui::shortcut_letter(&e);
            let cmd = own_ui::shortcut_modifier(m);
            let text = e.logical_key.to_text();
            let toggle = if mac { m.control_key() && m.super_key() && letter == Some('s') } else { m.control_key() && !m.shift_key() && letter == Some('b') };
            if toggle {
                self.toggle_sidebar();
            } else if cmd && !m.shift_key() && matches!(letter, Some('f') | Some('k')) && !in_dialog {
                if let Some(kind) = self.page.kind().filter(|_| self.detail.is_none()) {
                    let input = &mut self.search[kind_index(kind)];
                    ui.focus(Some(input.id));
                    input.select_all();
                } else if self.page == Page::Kubernetes {
                    ui.focus(Some(self.kube.search.id));
                }
            } else if cmd && m.shift_key() && letter == Some('p') && !in_dialog {
                self.open_pull();
            } else if (mac && m.super_key() && text == Some("[")) || (!mac && m.alt_key() && e.logical_key == own_ui::winit::keyboard::Key::Named(NamedKey::ArrowLeft)) {
                if !in_dialog {
                    self.travel(-1);
                }
            } else if (mac && m.super_key() && text == Some("]")) || (!mac && m.alt_key() && e.logical_key == own_ui::winit::keyboard::Key::Named(NamedKey::ArrowRight)) {
                if !in_dialog {
                    self.travel(1);
                }
            } else if cmd && letter == Some('q') {
                ui.p.quit();
            } else if !mac && m.control_key() && text == Some(",") {
                self.go(Page::Settings);
            } else if e.logical_key == own_ui::winit::keyboard::Key::Named(NamedKey::Escape) && !in_dialog && self.detail.is_some() {
                self.close_detail();
            } else {
                continue;
            }
            ui.consume_key(i);
        }
    }

    pub fn open_pull(&mut self) {
        if !self.reachable() {
            return;
        }
        let registries = self.api.registries(&self.pull_hosts);
        self.pull = Some(views::pull::PullPanel::new(registries, &self.t("pull.searchPlaceholder")));
    }

    // ---- painting: the shell ----

    fn paint(&mut self, ui: &mut Ui) {
        let t = ui.theme;
        let b = ui.bounds();
        ui.p.fill(b, t.page);
        let mut r = b;
        let top = r.cut_top(40.);
        let status = r.cut_bottom(27.);
        let banner = self.banner_shown().then(|| r.cut_bottom(36.));
        let width = if self.collapsed { RAIL } else { self.sidebar_w };
        let side = r.cut_left(width);
        self.paint_topbar(ui, top);
        self.paint_sidebar(ui, side);
        self.paint_splitter(ui, side);
        views::paint_main(self, ui, r);
        if let Some(banner) = banner {
            self.paint_banner(ui, banner);
        }
        self.paint_status(ui, status);
        if self.pull.is_some() {
            views::pull::paint(self, ui);
        }
        if self.dialog.is_some() {
            dialogs::paint(self, ui);
        }
        self.toasts.paint(ui);
    }

    fn paint_topbar(&mut self, ui: &mut Ui, top: Rect) {
        let t = ui.theme;
        ui.p.border_bottom(top, t.line);
        let mut row = own_ui::widgets::layout::Row::new(top.inset(10., 0., 10., 1.), 2.);
        let toggle = row.left_h(30., 30.);
        if button::icon_button(ui, Id::of("sidebar-toggle"), toggle, Icon::Sidebar.id(), IconKind::Plain, true) {
            self.toggle_sidebar();
        }
        let back = row.left_h(30., 30.);
        if button::icon_button(ui, Id::of("nav-back"), back, Icon::Back.id(), IconKind::Plain, self.can_travel(-1)) {
            self.travel(-1);
        }
        let fwd = row.left_h(30., 30.);
        if button::icon_button(ui, Id::of("nav-forward"), fwd, Icon::Forward.id(), IconKind::Plain, self.can_travel(1)) {
            self.travel(1);
        }
        let settings = row.right_h(30., 30.);
        if self.page == Page::Settings {
            ui.p.rounded(settings, 7., t.accent_soft);
        }
        if button::icon_button(ui, Id::of("top-settings"), settings, Icon::Settings.id(), IconKind::Plain, true) {
            self.go(Page::Settings);
        }
    }

    fn nav_item(&mut self, ui: &mut Ui, r: Rect, id: Id, icon: Icon, label: &str, count: Option<usize>, current: bool) -> bool {
        let t = ui.theme;
        let hovered = ui.hovered(id);
        if current {
            ui.p.rounded(r, 7., t.accent_soft);
        } else if hovered {
            ui.p.rounded(r, 7., t.hover);
        }
        let fg = if current { t.accent_text } else if hovered { t.ink } else { t.ink2 };
        let icon_r = if self.collapsed { r.center(18., 18.) } else { Rect::new(r.x + 10., r.y + (r.h - 18.) / 2., 18., 18.) };
        ui.p.icon(icon.id(), icon_r, fg);
        if !self.collapsed {
            let mut inner = r.inset(38., 0., 10., 0.);
            if let Some(n) = count {
                let style = ui.style().with_size(12.);
                let text = ui.p.layout(&n.to_string(), style, None);
                let cr = inner.cut_right(text.width);
                ui.p.draw_text(&text, cr.x, cr.y + (cr.h - text.height) / 2., if current { t.accent_text } else { t.muted });
                inner.w -= 6.;
            }
            let style = ui.style().weight(if current { 600 } else { 400 });
            ui.p.label(inner, label, style, fg);
        }
        ui.p.hitbox(r, id, CursorIcon::Pointer);
        ui.clicked(id)
    }

    fn paint_sidebar(&mut self, ui: &mut Ui, side: Rect) {
        let t = ui.theme;
        ui.p.fill(Rect::new(side.right() - 1., side.y, 1., side.h), t.line);
        let pad = if self.collapsed { 4. } else { 8. };
        let inner = side.inset(pad, 12., pad + 1., 12.);
        let item_h = 34.;
        let mut y = inner.y;
        let item = |y: &mut f32, h: f32| {
            let r = Rect::new(inner.x, *y, inner.w, h);
            *y += h + 2.;
            r
        };
        // Migration, the four lists, Training.
        let r = item(&mut y, item_h);
        let label = self.t("migration.title");
        if self.nav_item(ui, r, Id::of("nav-migrate"), Icon::Migration, &label, None, self.page == Page::Migrate) {
            self.go(Page::Migrate);
        }
        y += 6.;
        for (kind, icon) in [(Kind::Containers, Icon::Containers), (Kind::Images, Icon::Images), (Kind::Volumes, Icon::Volumes), (Kind::Networks, Icon::Networks)] {
            let r = item(&mut y, item_h);
            let count = (self.loaded && self.lists.errors[kind_index(kind)].is_none()).then(|| self.lists.len(kind));
            let label = self.t(&format!("nav.{}", kind.as_str()));
            if self.nav_item(ui, r, Id::of(("nav", kind.as_str())), icon, &label, count, self.page == Page::of(kind)) {
                self.go(Page::of(kind));
            }
        }
        y += 6.;
        let r = item(&mut y, item_h);
        let label = self.t("nav.tutorials");
        if self.nav_item(ui, r, Id::of("nav-training"), Icon::Tutorials, &label, None, self.page == Page::Training) {
            self.go(Page::Training);
        }
        y += 6.;
        // Kubernetes, with its resources below when expanded.
        let r = item(&mut y, item_h);
        let total = self.kube_counts.map(|c| c.total());
        let label = self.t("nav.kubernetes");
        let open_r = if self.collapsed { r } else { r.inset(0., 0., 32., 0.) };
        let current = self.page == Page::Kubernetes && !self.kube_expanded;
        if self.nav_item(ui, open_r, Id::of("nav-kube"), Icon::Kubernetes, &label, total, current) {
            self.go(Page::Kubernetes);
        }
        if !self.collapsed {
            let tr = Rect::new(r.right() - 30., r.y + 2., 30., 30.);
            let tid = Id::of("nav-kube-toggle");
            if ui.hovered(tid) {
                ui.p.bordered(tr, 7., t.hover, 1., t.line);
            }
            let icon = if self.kube_expanded { own_ui::icons::CHEVRON_DOWN } else { own_ui::icons::CHEVRON_RIGHT };
            ui.p.icon(icon, tr.center(14., 14.), t.ink2);
            ui.p.hitbox(tr, tid, CursorIcon::Pointer);
            if ui.clicked(tid) {
                self.kube_expanded = !self.kube_expanded;
                if self.kube_expanded {
                    self.refresh_kube_counts();
                }
            }
        }
        if self.kube_expanded {
            let sub_x = if self.collapsed { 0. } else { 28. };
            let top = y;
            for (kind, icon) in [(KubeKind::Pods, Icon::KubePods), (KubeKind::Services, Icon::KubeServices), (KubeKind::Deployments, Icon::KubeDeployments), (KubeKind::Claims, Icon::KubeClaims)] {
                let r = item(&mut y, 30.);
                let r = r.inset(sub_x, 0., 0., 0.);
                let label = self.t(&format!("kube.{}", kind.as_str()));
                let count = self.kube_counts.map(|c| c.get(kind));
                let current = self.page == Page::Kubernetes && self.kube.kind == kind;
                if self.nav_item(ui, r, Id::of(("nav-kube", kind.as_str())), icon, &label, count, current) {
                    self.go_kube(kind);
                }
            }
            if !self.collapsed {
                ui.p.fill(Rect::new(inner.x + 18., top, 1., y - top - 2.), t.line);
            }
        }
        // The bottom: settings, the VM card or the engine line.
        let mut bottom = inner.bottom();
        let vm_card = self.vm.is_some() && self.has_vm();
        if vm_card {
            bottom = views::vm_card(self, ui, inner, bottom);
        } else {
            bottom = self.paint_engine_line(ui, inner, bottom);
        }
        let r = Rect::new(inner.x, bottom - 8. - item_h, inner.w, item_h);
        let label = self.t("nav.settings");
        if self.nav_item(ui, r, Id::of("nav-settings"), Icon::Settings, &label, None, self.page == Page::Settings) {
            self.go(Page::Settings);
        }
    }

    pub fn engine_state(&self) -> (&'static str, String) {
        let Some(e) = &self.engine else { return ("checking", self.t("engine.checking")) };
        if e.engine != "podbag" {
            return if e.reachable { ("ok", self.t("engine.running")) } else { ("down", self.t("engine.down")) };
        }
        match (e.vm.as_deref(), e.reachable) {
            (Some("running"), _) => ("ok", self.t("engine.vmRunning")),
            (Some(_), false) => ("off", self.t("engine.vmStopped")),
            (_, true) => ("ok", self.t("engine.running")),
            _ => ("down", self.t("engine.down")),
        }
    }

    pub fn state_color(&self, t: &Theme, cls: &str) -> Color {
        match cls {
            "ok" => t.green,
            "down" => t.red,
            "checking" => t.amber,
            _ => t.muted,
        }
    }

    fn paint_engine_line(&mut self, ui: &mut Ui, inner: Rect, bottom: f32) -> f32 {
        let t = ui.theme;
        let (cls, text) = self.engine_state();
        let name = self.engine.as_ref().map_or("podbag".to_string(), |e| e.engine_name.clone());
        let r = Rect::new(inner.x, bottom - 32., inner.w, 32.);
        ui.p.fill(Rect::new(r.x, r.y, r.w, 1.), t.line);
        let dot = Rect::new(r.x + if self.collapsed { (r.w - 8.) / 2. } else { 10. }, r.y + 16., 8., 8.);
        ui.p.rounded(dot, 4., self.state_color(&t, cls));
        if !self.collapsed {
            let style = ui.style().with_size(13.);
            ui.p.label(Rect::new(dot.right() + 8., r.y + 10., r.w - 28., 20.), &format!("{name} · {text}"), style, t.ink2);
        }
        r.y
    }

    fn paint_splitter(&mut self, ui: &mut Ui, side: Rect) {
        let t = ui.theme;
        let id = Id::of("splitter");
        let r = Rect::new(side.right() - 5., side.y, 9., side.h);
        if ui.hovered(id) || self.sidebar_drag.is_some() {
            ui.p.fill(Rect::new(r.x + 4., r.y, 1.5, r.h), t.accent);
        }
        ui.p.hitbox(r, id, CursorIcon::ColResize);
        if let Some((pos, _)) = ui.pressed(id) {
            self.sidebar_drag = Some((pos.x, if self.collapsed { RAIL } else { self.sidebar_w }));
        }
        if let Some((x0, w0)) = self.sidebar_drag {
            if ui.is_active(id) {
                if let Some(p) = ui.pointer() {
                    let w = w0 + p.x - x0;
                    let threshold = if w0 == RAIL { 80. } else { 128. };
                    if w <= threshold {
                        self.collapsed = true;
                    } else {
                        self.collapsed = false;
                        self.sidebar_w = w.clamp(SIDEBAR_MIN, SIDEBAR_MAX);
                    }
                }
            } else {
                self.sidebar_drag = None;
                self.settings.sidebar_width = self.sidebar_w as u32;
                self.settings.sidebar_collapsed = self.collapsed;
                self.save_settings();
            }
        }
    }

    fn banner_shown(&self) -> bool {
        self.docker.as_ref().is_some_and(|d| d.installed && !d.is_podbag) && self.is_podbag() && self.reachable()
    }

    fn paint_banner(&mut self, ui: &mut Ui, r: Rect) {
        let t = ui.theme;
        ui.p.fill(r, t.amber_soft);
        ui.p.fill(r.with_h(1.), t.line);
        let name = self.docker.as_ref().map(|d| d.name.clone()).unwrap_or_default();
        let text = match &self.docker_switching {
            Some(_) => self.tv("docker.switching", &[("name", &"podbag")]),
            None => self.tv("docker.banner", &[("name", &name)]),
        };
        ui.p.icon(Icon::Warning.id(), Rect::new(r.x + 16., r.y + 9., 18., 18.), t.amber);
        let style = ui.style().with_size(13.).weight(600);
        ui.p.label(Rect::new(r.x + 44., r.y, r.w - 120., r.h), &text, style, t.ink);
        let b = Rect::new(r.right() - 74., r.y + 3., 30., 30.);
        if button::icon_button(ui, Id::of("banner-switch"), b, Icon::Switch.id(), IconKind::Accent, self.docker_switching.is_none()) {
            self.api.docker_switch("use");
        }
    }

    fn paint_status(&mut self, ui: &mut Ui, r: Rect) {
        let t = ui.theme;
        ui.p.fill(r.with_h(1.), t.line);
        let style = ui.style().with_size(12.);
        let mut row = own_ui::widgets::layout::Row::new(r.inset(8., 3., 8., 2.), 2.);
        let item = |ui: &mut Ui, row: &mut own_ui::widgets::layout::Row, right: bool, text: &str, icon: Option<Icon>, color: Color, id: Option<Id>| -> bool {
            let layout = ui.p.layout(text, style, None);
            let icon_w = if icon.is_some() { 18. } else { 0. };
            let w = layout.width + icon_w + 14.;
            let s = if right { row.right(w) } else { row.left(w) };
            if let Some(id) = id
                && ui.hovered(id)
            {
                ui.p.rounded(s, 5., t.hover);
            }
            if let Some(icon) = icon {
                ui.p.icon(icon.id(), Rect::new(s.x + 7., s.y + (s.h - 13.) / 2., 13., 13.), color);
            }
            ui.p.draw_text(&layout, s.x + 7. + icon_w, s.y + (s.h - layout.height) / 2., color);
            match id {
                Some(id) => {
                    ui.p.hitbox(s, id, CursorIcon::Pointer);
                    ui.clicked(id)
                }
                None => false,
            }
        };
        if let Some(u) = self.updates.clone()
            && item(ui, &mut row, false, &format!("podbag {}", u.engine), None, t.ink2, Some(Id::of("status-version")))
        {
            self.go(Page::Settings);
            self.open_sections.insert("updates");
        }
        let terminal = self.t("status.terminal");
        if item(ui, &mut row, false, &terminal, Some(Icon::Shell), t.ink2, Some(Id::of("status-terminal")))
            && self.api.open_terminal("plain").is_err()
        {
            let text = self.t("terminal.none");
            self.toasts.push(text, true);
        }
        // Right side, from the right edge.
        let mut items: Vec<(String, Option<Icon>, Color, Option<Color>)> = Vec::new();
        if let Some(vm) = &self.vm
            && let Some(total) = vm.memory_total_mib
        {
            let text = format!("{} / {}", fmt::mib(Some(vm.memory_used_mib.unwrap_or(0)), self.lang), fmt::mib(Some(total), self.lang));
            items.push((text, None, t.ink2, None));
        }
        if self.loaded {
            let total = self.lists.containers.len();
            let running = self.lists.containers.iter().filter(|c| c.state == "running").count();
            items.push((self.tv("status.running", &[("n", &running), ("total", &total)]), None, t.ink2, None));
        }
        let (cls, text) = if let Some(vm) = self.vm.as_ref().filter(|_| self.has_vm()) {
            let state = self.t(&format!("vm.state.{}", views::vm_state_key(&vm.state)));
            (if vm.state == "running" { "ok" } else { "off" }, format!("{}: {state}", self.t("vm.title")))
        } else {
            let (cls, text) = self.engine_state();
            let name = self.engine.as_ref().map_or("podbag".to_string(), |e| e.engine_name.clone());
            (cls, format!("{name}: {text}"))
        };
        items.push((text, None, t.ink2, Some(self.state_color(&t, cls))));
        if let Some(d) = &self.docker {
            let text = if !d.installed {
                self.t("docker.missingShort")
            } else if d.is_podbag {
                format!("{} · {}", self.t("docker.command"), self.t("docker.applied"))
            } else {
                format!("{} · {}", self.t("docker.command"), self.tv("docker.using", &[("name", &d.name)]))
            };
            items.insert(0, (text, None, t.ink2, None));
        }
        for (i, (text, icon, color, dot)) in items.iter().enumerate() {
            let layout = ui.p.layout(text, style, None);
            let dot_w = if dot.is_some() { 13. } else { 0. };
            let w = layout.width + dot_w + 14. + icon.map_or(0., |_| 18.);
            let s = row.right(w);
            if let Some(dc) = dot {
                ui.p.rounded(Rect::new(s.x + 7., s.y + (s.h - 8.) / 2., 8., 8.), 4., *dc);
            }
            ui.p.draw_text(&layout, s.x + 7. + dot_w, s.y + (s.h - layout.height) / 2., *color);
            if i + 1 < items.len() {
                ui.p.fill(Rect::new(s.x - 2., s.y + (s.h - 12.) / 2., 1., 12.), t.line);
            }
        }
    }
}

impl UiApp for Desktop {
    type Message = Msg;

    fn ui(&mut self, ui: &mut Ui) {
        if self.timers() {
            ui.repaint();
        }
        ui.wake_at(self.next_due());
        self.report(ui);
        self.keys(ui);
        self.paint(ui);
    }

    fn message(&mut self, msg: Msg, cx: &mut Cx) {
        match msg {
            Msg::Stdin(line) => self.command(&line, cx),
            Msg::Api(ev) => {
                self.api_event(ev);
                cx.notify();
            }
        }
    }

    fn tick(&mut self, cx: &mut Cx) -> bool {
        let changed = self.timers();
        cx.wake_at(self.next_due());
        let pull = self.pull.as_ref().is_some_and(|p| p.waiting());
        changed || pull || self.toasts.expire()
    }

    fn theme(&self, system_dark: bool) -> Theme {
        Desktop::theme(self, system_dark)
    }
}
