//! The Kubernetes page (kubernetes.js): resource tabs, all-namespaces toggle, cluster
//! context, and a table of the chosen resource.

use bench_api::serde_json::Value;
use bench_api::{Backend, KubeKind, pretty_json};
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, IconKind};
use own_ui::widgets::checkbox;
use own_ui::widgets::layout::Row;
use own_ui::widgets::logs::LogView;
use own_ui::widgets::select::{Item, select};
use own_ui::widgets::table::{Column, Width, table};
use own_ui::widgets::tabs::tabs;
use own_ui::widgets::text_field::text_field;
use own_ui::{Color, Id, Rect, TextInput, TextStyle, VirtualList};

use crate::app::Desktop;
use crate::dialogs::Dialog;
use crate::icons::Icon;
use crate::views::title_bar;

pub struct KubeState {
    pub kind: KubeKind,
    pub all_namespaces: bool,
    /// None: the current context.
    pub context: Option<String>,
    pub contexts: Vec<String>,
    pub search: TextInput,
    pub items: Vec<Value>,
    /// The context and namespace of the loaded list.
    pub shown_context: String,
    pub namespace: String,
    pub error: Option<String>,
    pub loaded: bool,
    table: VirtualList,
}

impl KubeState {
    pub fn new() -> Self {
        Self {
            kind: KubeKind::Pods,
            all_namespaces: false,
            context: None,
            contexts: Vec::new(),
            search: TextInput::new(Id::of("kube-search"), "Search", TextStyle::new(14.).line_height(20.), Color::TRANSPARENT),
            items: Vec::new(),
            shown_context: String::new(),
            namespace: String::new(),
            error: None,
            loaded: false,
            table: VirtualList::new(40., 40.),
        }
    }

    pub fn load(&mut self, api: &Backend) {
        if let Ok(names) = api.kube_contexts() {
            self.contexts = names;
        }
        match api.kube_list(self.kind, self.all_namespaces, self.context.as_deref()) {
            Ok(list) => {
                self.items = list.items;
                self.shown_context = list.context;
                self.namespace = list.namespace;
                self.error = None;
            }
            Err(e) => {
                self.items.clear();
                self.error = Some(e);
            }
        }
        self.loaded = true;
        self.table.set_offset(0.);
    }
}

impl Default for KubeState {
    fn default() -> Self {
        Self::new()
    }
}

fn columns(kind: KubeKind) -> Vec<&'static str> {
    let mut v = vec!["col.name", "kube.namespace"];
    v.extend_from_slice(match kind {
        KubeKind::Pods => &["kube.phase", "kube.ready", "kube.node"][..],
        KubeKind::Services => &["kube.type", "kube.address", "col.ports"],
        KubeKind::Deployments => &["kube.ready", "col.image"],
        KubeKind::Claims => &["kube.phase", "kube.capacity", "kube.storageClass"],
    });
    v
}

fn s(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Number(n) => n.to_string(),
        _ => String::new(),
    }
}

/// kubernetes.js `kubeCells`.
pub fn cells(kind: KubeKind, item: &Value) -> Vec<String> {
    let (meta, spec, status) = (&item["metadata"], &item["spec"], &item["status"]);
    let mut out = vec![s(&meta["name"]), s(&meta["namespace"])];
    let list = |v: &Value| v.as_array().cloned().unwrap_or_default();
    match kind {
        KubeKind::Pods => {
            let sidecars: Vec<Value> = list(&spec["initContainers"]).into_iter().filter(|c| c["restartPolicy"] == "Always").collect();
            let containers: Vec<Value> = list(&spec["containers"]).into_iter().chain(sidecars).collect();
            let ready: Vec<String> = list(&status["containerStatuses"])
                .into_iter()
                .chain(list(&status["initContainerStatuses"]))
                .filter(|c| c["ready"] == true)
                .map(|c| s(&c["name"]))
                .collect();
            let count = containers.iter().filter(|c| ready.contains(&s(&c["name"]))).count();
            out.extend([s(&status["phase"]), format!("{count}/{}", containers.len()), s(&spec["nodeName"])]);
        }
        KubeKind::Deployments => {
            let images: Vec<String> = list(&spec["template"]["spec"]["containers"]).iter().map(|c| s(&c["image"])).collect();
            let ready = status["readyReplicas"].as_i64().unwrap_or(0);
            let replicas = spec["replicas"].as_i64().unwrap_or(1);
            out.extend([format!("{ready}/{replicas}"), images.join(", ")]);
        }
        KubeKind::Claims => {
            out.extend([s(&status["phase"]), s(&status["capacity"]["storage"]), s(&spec["storageClassName"])]);
        }
        KubeKind::Services => {
            let ports: Vec<String> = list(&spec["ports"])
                .iter()
                .map(|p| {
                    let node = p["nodePort"].as_i64().map(|n| format!(":{n}")).unwrap_or_default();
                    let proto = p["protocol"].as_str().unwrap_or("TCP");
                    format!("{}{node}/{proto}", s(&p["port"]))
                })
                .collect();
            let ips: Vec<String> = list(&spec["clusterIPs"]).iter().map(s).collect();
            let address = spec["externalName"].as_str().map(str::to_string).unwrap_or_else(|| if ips.is_empty() { s(&spec["clusterIP"]) } else { ips.join(", ") });
            out.extend([s(&spec["type"]), address, ports.join(", ")]);
        }
    }
    out
}

pub fn paint(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    let t = ui.theme;
    if !d.kube.loaded {
        d.kube.load(&d.api);
    }
    let mut r = r;
    let bar = r.cut_top(62.);
    let title = d.t("nav.kubernetes");
    let title_right = title_bar(ui, bar, &title);
    let mut row = Row::new(bar.inset(20., 14., 20., 15.), 8.);
    if button::icon_button(ui, Id::of("kube-refresh"), row.right_h(30., 30.), Icon::Refresh.id(), IconKind::Plain, true) {
        d.refresh_kube_counts();
        d.kube.load(&d.api);
    }
    let x = title_right + 12.;
    let w = (row.rest().right() - x - 12.).clamp(0., 280.);
    if w >= 120. {
        text_field(ui, &mut d.kube.search, Rect::new(x, bar.y + 15., w, 32.), Some(Icon::Search.id()), d.kube.error.is_none());
    }
    // Resource tabs and the all-namespaces toggle.
    let tab_bar = r.cut_top(44.);
    ui.p.border_bottom(tab_bar, t.line);
    let kinds = KubeKind::ALL;
    let labels: Vec<String> = kinds.iter().map(|k| d.t(&format!("kube.{}", k.as_str()))).collect();
    let selected = kinds.iter().position(|k| *k == d.kube.kind).unwrap_or(0);
    if let Some(n) = tabs(ui, Id::of("kube-tabs"), tab_bar.inset(20., 0., 20., 0.), &labels, selected) {
        d.go_kube(kinds[n]);
    }
    let all_label = d.t("kube.allNamespaces");
    let cw = checkbox::width(ui, &all_label);
    let mut all = d.kube.all_namespaces;
    if checkbox::checkbox(ui, Id::of("kube-all"), Rect::new(tab_bar.right() - 20. - cw, tab_bar.y, cw, tab_bar.h), Some(&mut all), &all_label, true) {
        d.kube.all_namespaces = all;
        d.refresh_kube_counts();
        d.kube.load(&d.api);
    }
    // The cluster context.
    r.cut_top(12.);
    let ctx_row = r.cut_top(34.).inset(20., 0., 20., 0.);
    let label = d.t("kube.cluster");
    let style = ui.style().with_size(13.);
    let lw = ui.p.layout(&label, style, None).width;
    ui.p.label(ctx_row.with_w(lw + 2.), &label, style, t.ink);
    let current = d.t("kube.current");
    let mut names: Vec<String> = d.kube.contexts.clone();
    if let Some(c) = &d.kube.context
        && !names.contains(c)
    {
        names.push(c.clone());
    }
    let mut items = vec![Item::Option(&current)];
    items.extend(names.iter().map(|n| Item::Option(n.as_str())));
    let sel = d.kube.context.as_ref().and_then(|c| names.iter().position(|n| n == c)).map_or(0, |i| i + 1);
    let sw = 240f32.min(ctx_row.w - lw - 10.);
    if let Some(i) = select(ui, Id::of("kube-context"), Rect::new(ctx_row.x + lw + 10., ctx_row.y, sw, 34.), &items, sel, true) {
        d.kube.context = if i == 0 { None } else { Some(names[i - 1].clone()) };
        d.refresh_kube_counts();
        d.kube.load(&d.api);
    }
    // The scope line.
    r.cut_top(10.);
    if d.kube.error.is_none() && !d.kube.shown_context.is_empty() {
        let ctx = d.tv("kube.context", &[("context", &d.kube.shown_context)]);
        let scope = if d.kube.all_namespaces { d.t("kube.allNamespaces") } else { d.kube.namespace.clone() };
        let line = r.cut_top(20.).inset(20., 0., 20., 0.);
        ui.p.label(line, &format!("{ctx} · {scope}"), ui.style().with_size(12.5), t.ink2);
    }
    let content = r.inset(20., 8., 20., 0.);
    if let Some(err) = d.kube.error.clone() {
        let message = if err == "kubectl-missing" { d.t("kube.missing") } else { err };
        let cx = content.x + content.w / 2.;
        let mut y = content.y + 48.;
        let h2 = ui.style().with_size(18.).weight(700);
        y += crate::views::centered(ui, cx, y, &d.t("kube.error"), h2, t.ink) + 8.;
        let mono = TextStyle::new(12.5).mono().line_height(18.);
        y += crate::views::centered(ui, cx, y, &message, mono, t.red) + 14.;
        let label = d.t("action.retry");
        let w = button::width(ui, &label, Some(Icon::Refresh.id()), false);
        if button::button(ui, Id::of("kube-retry"), Rect::new(cx - w / 2., y, w, 32.), &label, Some(Icon::Refresh.id()), button::Kind::Primary, true) {
            d.kube.load(&d.api);
        }
        return;
    }
    let kind = d.kube.kind;
    let q = d.kube.search.content.trim().to_lowercase();
    // The rows that match the search, with their index in `items`.
    let (item_ix, rows): (Vec<usize>, Vec<Vec<String>>) = d
        .kube
        .items
        .iter()
        .map(|item| cells(kind, item))
        .enumerate()
        .filter(|(_, v)| q.is_empty() || v.iter().any(|c| c.to_lowercase().contains(&q)))
        .unzip();
    if rows.is_empty() {
        let text = if d.kube.items.is_empty() {
            d.t(&format!("kube.empty.{}", kind.as_str()))
        } else {
            d.tv("empty.search", &[("q", &d.kube.search.content.trim())])
        };
        ui.paragraph(content.x + 10., content.y + 24., content.w - 20., &text, ui.style(), t.ink2);
        return;
    }
    let keys = columns(kind);
    let labels: Vec<String> = keys.iter().map(|k| d.t(k)).collect();
    let cols: Vec<Column> = labels
        .iter()
        .enumerate()
        .map(|(i, l)| Column { label: l, width: if i == 0 { Width::Flex(0.27 * (keys.len() - 1) as f32 / 0.73) } else { Width::Flex(1.) } })
        .collect();
    let base = ui.style();
    let mut table_state = std::mem::replace(&mut d.kube.table, VirtualList::new(40., 40.));
    let clicked = table(ui, Id::of(("kube-table", kind.as_str())), content, &cols, rows.len(), &mut table_state, |ui, row, col, cell| {
        let v = &rows[row][col];
        let text = if v.is_empty() { "—" } else { v.as_str() };
        if col == 0 {
            ui.p.label(cell, text, base.weight(600), t.ink);
        } else {
            ui.p.label(cell, text, base, t.ink);
        }
    });
    d.kube.table = table_state;
    if let Some(row) = clicked {
        let item = &d.kube.items[item_ix[row]];
        let title = format!("{} / {}", s(&item["metadata"]["namespace"]), s(&item["metadata"]["name"]));
        let context = d.tv("kube.context", &[("context", &d.kube.shown_context)]);
        let mut lines = LogView::default();
        lines.follow = false;
        lines.push(pretty_json(item).lines().map(str::to_string));
        d.dialog = Some(Dialog::KubeObject { title, context, lines });
    }
}
