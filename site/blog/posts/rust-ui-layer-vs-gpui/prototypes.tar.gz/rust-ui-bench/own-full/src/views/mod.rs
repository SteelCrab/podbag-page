//! The pages, and parts several pages share (toolbar, chips, empty states, fields).

pub mod detail;
pub mod kubernetes;
pub mod pull;
pub mod resources;
pub mod settings;

use bench_api::fmt;
use own_ui::ui::Ui;
use own_ui::widgets::button::{self, IconKind, Kind as ButtonKind};
use own_ui::{Color, Id, Rect, TextStyle};

use crate::app::{Desktop, Page};
use crate::icons::Icon;

pub fn paint_main(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    match d.page {
        Page::Kubernetes => kubernetes::paint(d, ui, r),
        Page::Settings => settings::paint(d, ui, r),
        Page::Training | Page::Migrate => placeholder(d, ui, r),
        page => {
            let kind = page.kind().unwrap();
            if !d.reachable() && d.engine.is_some() {
                let body = toolbar(d, ui, r, &d.t(&format!("nav.{}", kind.as_str())));
                offline(d, ui, body);
            } else if d.detail.is_some() {
                detail::paint(d, ui, r);
            } else {
                resources::paint(d, ui, r, kind);
            }
        }
    }
}

/// The page header: a title and a bottom border. Returns the rest of `r`.
pub fn toolbar(_d: &Desktop, ui: &mut Ui, r: Rect, title: &str) -> Rect {
    let mut r = r;
    let bar = r.cut_top(62.);
    title_bar(ui, bar, title);
    r
}

/// Paints the toolbar frame and title; returns the title's right edge.
pub fn title_bar(ui: &mut Ui, bar: Rect, title: &str) -> f32 {
    let t = ui.theme;
    ui.p.border_bottom(bar, t.line);
    let style = ui.style().with_size(18.).weight(700);
    let layout = ui.p.layout(title, style, Some((bar.w * 0.4).max(80.)));
    ui.p.draw_text(&layout, bar.x + 20., bar.y + (bar.h - 1. - layout.height) / 2., t.ink);
    bar.x + 20. + layout.width
}

fn placeholder(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    let title = match d.page {
        Page::Training => d.t("nav.tutorials"),
        _ => d.t("migration.title"),
    };
    let body = toolbar(d, ui, r, &title);
    let t = ui.theme;
    let icon = if d.page == Page::Training { Icon::Tutorials } else { Icon::Migration };
    let mut y = body.y + 56.;
    let cx = body.x + body.w / 2.;
    ui.p.rounded(Rect::new(cx - 32., y, 64., 64.), 16., t.accent_soft);
    ui.p.icon(icon.id(), Rect::new(cx - 16., y + 16., 32., 32.), t.accent_text);
    y += 76.;
    let style = ui.style().with_size(18.).weight(700);
    centered(ui, cx, y, &title, style, t.ink);
    y += 34.;
    centered(ui, cx, y, "Out of scope for this benchmark port.", ui.style(), t.ink2);
}

pub fn centered(ui: &mut Ui, cx: f32, y: f32, text: &str, style: TextStyle, color: Color) -> f32 {
    let layout = ui.p.layout_wrapped(text, style, 520.);
    ui.p.draw_text(&layout, cx - layout.width / 2., y, color);
    layout.height
}

/// app.js `stateChip`: a pill with a dot. Returns its width.
pub fn chip(d: &Desktop, ui: &mut Ui, x: f32, cy: f32, state: &str, max_w: f32) -> f32 {
    let t = ui.theme;
    let known = ["running", "exited", "created", "paused", "restarting", "dead"];
    let s = if known.contains(&state) { state } else { "created" };
    let (fg, bg) = match s {
        "running" => (t.green, t.green_soft),
        "paused" | "restarting" => (t.amber, t.amber_soft),
        "dead" => (t.red, t.red_soft),
        _ => (t.ink2, t.gray_soft),
    };
    let label = d.t(&format!("state.{s}"));
    pill(ui, x, cy, &label, fg, bg, max_w)
}

pub fn pill(ui: &mut Ui, x: f32, cy: f32, label: &str, fg: Color, bg: Color, max_w: f32) -> f32 {
    let style = ui.style().with_size(12.5).weight(600).line_height(18.);
    let text = ui.p.layout(label, style, Some((max_w - 29.).max(10.)));
    let w = text.width + 29.;
    let r = Rect::new(x, cy - 11., w, 22.);
    ui.p.rounded(r, 11., bg);
    ui.p.rounded(Rect::new(r.x + 8., cy - 3.5, 7., 7.), 3.5, fg);
    ui.p.draw_text(&text, r.x + 20., cy - 9., fg);
    w
}

/// A monospace command with a copy button.
pub fn code_line(d: &mut Desktop, ui: &mut Ui, cx: f32, y: f32, text: &str, id: Id) -> f32 {
    let t = ui.theme;
    let style = TextStyle::new(13.).mono().line_height(18.);
    let layout = ui.p.layout(text, style, None);
    let w = layout.width + 14. + 6. + 30. + 6.;
    let r = Rect::new(cx - w / 2., y, w, 42.);
    ui.p.bordered(r, 8., t.sunken, 1., t.line);
    ui.p.draw_text(&layout, r.x + 14., r.y + 12., t.ink);
    let label = d.t("action.copy");
    let _ = label;
    if button::icon_button(ui, id, Rect::new(r.right() - 36., r.y + 6., 30., 30.), Icon::Copy.id(), IconKind::Plain, true) {
        d.copy(text, ui);
    }
    r.h
}

/// The offline page of app.js.
pub fn offline(d: &mut Desktop, ui: &mut Ui, r: Rect) {
    let t = ui.theme;
    let e = d.engine.clone().unwrap_or_else(|| d.api.engine(false));
    let cx = r.x + r.w / 2.;
    let mut y = r.y + 56.;
    let vm_off = e.error.as_deref() == Some("vm-stopped") || e.vm.as_deref().is_some_and(|v| v != "running");
    ui.p.rounded(Rect::new(cx - 32., y, 64., 64.), 16., t.accent_soft);
    ui.p.icon(Icon::Engine.id(), Rect::new(cx - 16., y + 16., 32., 32.), t.accent_text);
    y += 76.;
    let h2 = ui.style().with_size(18.).weight(700);
    if e.engine == "docker" {
        y += centered(ui, cx, y, &d.t("offline.dockerTitle"), h2, t.ink) + 8.;
        y += centered(ui, cx, y, &d.t("offline.dockerText"), ui.style(), t.ink2) + 14.;
    } else if vm_off {
        y += centered(ui, cx, y, &d.t("offline.vmTitle"), h2, t.ink) + 8.;
        y += centered(ui, cx, y, &d.t("offline.vmText"), ui.style(), t.ink2) + 14.;
        let label = d.t("action.startVm");
        let w = button::width(ui, &label, Some(Icon::Start.id()), false);
        if button::button(ui, Id::of("offline-start"), Rect::new(cx - w / 2., y, w, 32.), &label, Some(Icon::Start.id()), ButtonKind::Primary, true) {
            d.connect(true);
        }
        return;
    } else {
        y += centered(ui, cx, y, &d.t("offline.title"), h2, t.ink) + 8.;
        y += centered(ui, cx, y, &d.t("offline.text"), ui.style(), t.ink2) + 6.;
        if let Some(err) = e.error.as_deref().filter(|e| *e != "vm-stopped") {
            let style = TextStyle::new(12.5).mono().line_height(18.);
            y += centered(ui, cx, y, err, style, t.red) + 6.;
        }
        y += centered(ui, cx, y, &d.t("offline.hint"), ui.style(), t.ink2) + 4.;
        let hint = if e.platform == "linux" { "podbag system service" } else { "podbag vm start" };
        y += code_line(d, ui, cx, y, hint, Id::of("offline-code")) + 14.;
    }
    let label = d.t("action.retry");
    let w = button::width(ui, &label, Some(Icon::Refresh.id()), false);
    if button::button(ui, Id::of("offline-retry"), Rect::new(cx - w / 2., y, w, 32.), &label, Some(Icon::Refresh.id()), ButtonKind::Primary, true) {
        d.connect(false);
    }
}

/// A `dl.fields` grid: labels left, values right; returns the height used.
pub fn fields(ui: &mut Ui, x: f32, y: f32, w: f32, rows: &[(String, String, bool)], none: &str) -> f32 {
    let t = ui.theme;
    let style = ui.style();
    let mono = TextStyle::new(12.5).mono().line_height(20.);
    let label_w = rows.iter().map(|(k, _, _)| ui.p.layout(k, style, None).width).fold(110f32, f32::max).min(w * 0.4);
    let mut yy = y;
    for (k, v, is_mono) in rows {
        ui.p.label(Rect::new(x, yy, label_w, style.line_height), k, style, t.ink2);
        let text = if v.is_empty() { none } else { v.as_str() };
        let s = if *is_mono && !v.is_empty() { mono } else { style };
        let h = ui.paragraph(x + label_w + 22., yy, w - label_w - 22., text, s, t.ink);
        yy += h.max(style.line_height) + 10.;
    }
    yy - y
}

pub fn vm_state_key(state: &str) -> &'static str {
    match state {
        "running" => "running",
        "standby" => "standby",
        "starting" => "starting",
        "stopped" => "stopped",
        "not set up" => "notSetUp",
        _ => "unknown",
    }
}

/// The sidebar's VM card, above `bottom`; returns its top.
pub fn vm_card(d: &mut Desktop, ui: &mut Ui, inner: Rect, bottom: f32) -> f32 {
    let t = ui.theme;
    let Some(vm) = d.vm.clone() else { return bottom };
    let running = vm.state == "running";
    let stoppable = running || vm.state == "standby" || vm.state == "starting";
    let state_text = d.t(&format!("vm.state.{}", vm_state_key(&vm.state)));
    if d.collapsed {
        let r = Rect::new(inner.x + (inner.w - 30.) / 2., bottom - 34., 30., 30.);
        if button::icon_button(ui, Id::of("vm-rail"), r, Icon::Vm.id(), IconKind::Plain, true) {
            d.go(Page::Settings);
            d.open_sections.insert("vm");
        }
        let dot = Rect::new(r.right() - 10., r.bottom() - 10., 7., 7.);
        ui.p.rounded(dot.expand(2.), 5.5, t.page);
        ui.p.rounded(dot, 3.5, if running { t.green } else { t.muted });
        return r.y;
    }
    let small = ui.style().with_size(12.5).line_height(18.);
    let mut rows: Vec<(String, String)> = Vec::new();
    if vm.containers.is_some() || running {
        rows.push((d.t("vm.containers"), vm.containers.unwrap_or(0).to_string()));
    }
    if vm.cpu_percent.is_some() || vm.in_use.is_some() {
        let mut parts = Vec::new();
        if let Some(p) = vm.cpu_percent {
            parts.push(fmt::percent(p, d.lang));
        }
        if let Some(c) = vm.in_use.and_then(|u| u.cpus) {
            parts.push(c.to_string());
        }
        rows.push((d.t("vm.cpu"), parts.join(" · ")));
    }
    if let Some(total) = vm.memory_total_mib {
        rows.push((d.t("vm.memory"), format!("{} / {}", fmt::mib(Some(vm.memory_used_mib.unwrap_or(0)), d.lang), fmt::mib(Some(total), d.lang))));
    }
    let meter = vm.memory_total_mib.is_some();
    let h = 10. + 20. + 8. + rows.len() as f32 * 21. + if meter { 12. } else { 0. } + 8. + 30. + 12.;
    let card = Rect::new(inner.x, bottom - h, inner.w, h);
    ui.p.bordered(card, 10., t.surface, 1., t.line);
    let c = card.inset(12., 10., 12., 12.);
    let mut y = c.y;
    ui.p.rounded(Rect::new(c.x, y + 6., 8., 8.), 4., if running { t.green } else { t.muted });
    let title = ui.style().with_size(13.).weight(600).line_height(20.);
    let st = ui.p.layout(&state_text, small, Some(c.w * 0.55));
    ui.p.draw_text(&st, c.right() - st.width, y + 1., t.ink2);
    ui.p.label(Rect::new(c.x + 15., y, c.w - 20. - st.width, 20.), &d.t("vm.title"), title, t.ink);
    y += 28.;
    for (k, v) in &rows {
        let vl = ui.p.layout(v, small, Some(c.w * 0.65));
        ui.p.draw_text(&vl, c.right() - vl.width, y, t.ink);
        ui.p.label(Rect::new(c.x, y, c.w - vl.width - 6., 18.), k, small, t.ink2);
        y += 21.;
    }
    if let (Some(total), true) = (vm.memory_total_mib, meter) {
        let used = (vm.memory_used_mib.unwrap_or(0) as f32 / total as f32).min(1.);
        let bar = Rect::new(c.x, y + 2., c.w, 4.);
        ui.p.rounded(bar, 2., t.sunken);
        ui.p.rounded(bar.with_w(bar.w * used), 2., t.accent);
        y += 12.;
    }
    y += 8.;
    let (label, kind) = if stoppable {
        (d.t("action.stopVm"), ButtonKind::Normal)
    } else {
        (d.t("action.startVm"), ButtonKind::Primary)
    };
    let enabled = !d.vm_busy && vm.state != "not set up";
    if button::button(ui, Id::of("vm-card-button"), Rect::new(c.x, y, c.w, 30.), &label, None, kind, enabled) {
        d.vm_action(if stoppable { "stop" } else { "start" });
    }
    card.y - 4.
}
