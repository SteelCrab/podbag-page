# Full-port scope: own framework vs GPUI + own widgets

Both ports implement the same features of the current Podbag Desktop, at app scale
(roughly 10,000 lines each is the expected size, not a target to pad toward).

## Reference (source of truth)
Podbag `origin/main` at `ec551fd` (v0.3.2). Read it with
`git -C ~/podbag show ec551fd:<path>` — do not edit that repository.
- `desktop/ui/app.js`, `images.js`, `kubernetes.js`, `index.html`, `style.css`: behavior and look.
- `desktop/ui/api.js`: the command list.
- `desktop/preview/mock.js`: the mocked API. The shared backend ports this.
- `desktop/ui/i18n/*.json` (7 languages) and `desktop/ui/i18n.js`: strings and lookup rules.

When this file and app.js disagree on behavior, match app.js.

## Shared backend: `shared/bench-api` (one crate, used by both ports)
- Rust port of `mock.js`: the same data, the same command results, the same errors.
- Commands are plain Rust functions or a trait, synchronous or with callbacks; no Tauri.
- Events from mock.js (`changed`, `logs`, `pull-progress`, `engine-changed`, `vm-status`)
  are delivered through a channel the UI drains, on a timer where mock.js uses one.
- `--rows N`: replace the mocked container list with the synthetic rows of
  `gpui-app/src/data.rs` (same generator), so the parity benchmark also runs on the full apps.
- i18n: load the 7 JSON files (embed them with `include_str!` from a copy in `shared/`),
  key lookup with the same fallback rules as `i18n.js`, runtime language switch.

## Features in scope (both ports)
1. **Shell**: sidebar with all nav items; engine status (running / stopped, start button);
   toasts; confirm dialog; the views below. Training and Migrate show an "out of scope"
   placeholder.
2. **Containers**: list with search, state pill, ports; start / stop / restart / remove
   (force confirm); rename dialog; detail panel from `inspect` / `container_json`;
   live logs view (logs_start / logs_stop with streamed lines); prune.
3. **Images**: list, search, remove, prune; pull dialog with streamed progress;
   registry search results.
4. **Volumes**: list, create dialog, remove, prune.
5. **Networks**: what app.js shows for networks.
6. **Kubernetes**: context selector, all-namespaces toggle, resource tabs with counts,
   resource tables (as kubernetes.js does, without OpenShift).
7. **Settings**: language (7, switches the UI live), engine choice, VM resources
   (CPU / memory controls), launch at login, the other controls app.js has on this screen.

Out of scope: Training / tutorials / practice labs, Migration, updates and upgrade,
registry login, terminal command install, star prompt. Buttons that open a terminal,
a shell or a browser may just call the mock and show its result.

## Benchmark hooks (same protocol as the parity prototypes)
- `--rows N`, stdout `READY`, `RENDER`, `FILTER <ms> <visible>` on the Containers view.
- stdin `filter <text>`, `quit`, and `nav <view>` (containers, images, volumes, networks,
  kubernetes, settings): switch views, then print `VIEW <name> <ms>` when the next frame
  begins after the new view is presented.
- `BENCH_NO_FOCUS`, `BENCH_LOG` as in the parity prototypes.
- Same `[profile.release]` as gpui-app. Pin versions with `=`. Keep Cargo.lock.

## Report
Line counts per area (framework or widget layer, each view, shared backend not counted
per port), what is missing or worse than Podbag Desktop, and the problems that took the
most time.
