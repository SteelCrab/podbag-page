//! Deterministic synthetic container rows. Same generator as gpui-app and tauri-app.

pub struct Row {
    pub name: String,
    pub image: &'static str,
    pub running: bool,
    pub ports: String,
    pub created: String,
    /// Lower-case text of all columns, for the search filter.
    pub hay: String,
}

const PREFIXES: [&str; 5] = ["web", "api", "db", "cache", "worker"];
const IMAGES: [&str; 5] = [
    "docker.io/library/nginx:1.27",
    "ghcr.io/example/api:2.3.1",
    "docker.io/library/postgres:16",
    "docker.io/library/redis:7.4",
    "quay.io/example/worker:0.9",
];
const INNER_PORTS: [u32; 5] = [80, 8080, 5432, 6379, 9000];

pub fn rows(n: usize) -> Vec<Row> {
    (0..n)
        .map(|i| {
            let p = i % 5;
            let running = i % 3 != 0;
            let name = format!("{}-{:05}", PREFIXES[p], i);
            let ports = if running {
                format!("127.0.0.1:{}->{}/tcp", 8000 + i % 1000, INNER_PORTS[p])
            } else {
                String::new()
            };
            let created = match i % 4 {
                0 => format!("{} minutes ago", 1 + i % 59),
                1 => format!("{} hours ago", 1 + i % 23),
                2 => format!("{} days ago", 1 + i % 6),
                _ => format!("{} weeks ago", 1 + i % 4),
            };
            let state = if running { "running" } else { "exited" };
            let hay = format!("{name}\n{}\n{state}\n{ports}\n{created}", IMAGES[p]).to_lowercase();
            Row { name, image: IMAGES[p], running, ports, created, hay }
        })
        .collect()
}

