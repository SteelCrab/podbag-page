//! Benchmark prototype: a Podbag-like containers screen on our own UI layer (src/ui).
//!
//! Usage: own-app [--rows N]
//! stdout: `READY <ms since main>`, `RENDER <ms>`, `FILTER <ms> <visible rows>`.
//! stdin commands: `filter <text>`, `quit`.
//! Env: BENCH_ROWS, BENCH_NO_FOCUS, BENCH_LOG, BENCH_FONT_PROBE (print font load times, exit).

mod data;

use std::io::{BufRead, Write};
use std::sync::OnceLock;
use std::time::Instant;

use data::Row;
use own_ui::{
    App, Color, CursorIcon, Cx, Event, Id, Paint, Rect, TextInput, TextStyle, View, VirtualList,
    WindowOptions, rgb, shortcut_letter, shortcut_modifier,
};

static T0: OnceLock<Instant> = OnceLock::new();

const NAV: [&str; 8] = [
    "Containers", "Images", "Volumes", "Networks", "Training", "Kubernetes", "Migrate", "Settings",
];
const COLS: [(&str, f32); 5] = [
    ("Name", 0.22),
    ("Image", 0.30),
    ("State", 0.12),
    ("Ports", 0.22),
    ("Created", 0.14),
];
const ROW_H: f32 = 36.;

const TEXT: Color = rgb(0x1f2328);
const MUTED: Color = rgb(0x57606a);
const SUBTLE: Color = rgb(0x6e7781);
const LINE: Color = rgb(0xe3e5e8);
const WHITE: Color = rgb(0xffffff);

const SEARCH: Id = Id(1);
const NAV_ID: u64 = 100;
const ROW_ID: u64 = 1000;

fn base() -> TextStyle {
    TextStyle::new(13.)
}

fn emit(line: String) {
    let mut out = std::io::stdout().lock();
    let _ = writeln!(out, "{line}");
    let _ = out.flush();
}

fn ms(since: Instant) -> f64 {
    since.elapsed().as_secs_f64() * 1000.0
}

enum Pending {
    FirstFrame(Instant),
    Filter(Instant),
}

struct Bench {
    rows: Vec<Row>,
    visible: Vec<usize>,
    query: String,
    search: TextInput,
    nav: usize,
    pressed: Option<Id>,
    list: VirtualList,
    pending: Option<Pending>,
}

impl Bench {
    fn new(rows: Vec<Row>) -> Self {
        // The rows are in the UI layer from here on; RENDER counts from this point.
        let start = Instant::now();
        Self {
            visible: (0..rows.len()).collect(),
            rows,
            query: String::new(),
            search: TextInput::new(SEARCH, "Search", base().line_height(18.), TEXT),
            nav: 0,
            pressed: None,
            list: VirtualList::new(ROW_H, base().line_height),
            pending: Some(Pending::FirstFrame(start)),
        }
    }

    fn search_changed(&mut self, start: Instant) {
        if self.search.content == self.query {
            return;
        }
        self.query = self.search.content.clone();
        let needle = self.query.trim().to_lowercase();
        self.visible = self
            .rows
            .iter()
            .enumerate()
            .filter(|(_, r)| needle.is_empty() || r.hay.contains(&needle))
            .map(|(i, _)| i)
            .collect();
        self.pending = Some(Pending::Filter(start));
    }

    fn command(&mut self, line: &str, cx: &mut Cx) {
        let line = line.trim();
        if line == "quit" {
            cx.quit();
        } else if let Some(q) = line.strip_prefix("filter ") {
            let start = Instant::now();
            self.search.set_content(q);
            self.search_changed(start);
            cx.notify();
        }
    }
}

impl View for Bench {
    type Message = String;

    fn paint(&mut self, p: &mut Paint) {
        // Report once the frame with this content has been presented: the callback runs
        // when the following frame begins.
        if let Some(pending) = self.pending.take() {
            let visible = self.visible.len();
            p.on_next_frame(move || match pending {
                Pending::FirstFrame(start) => {
                    let render = ms(start);
                    emit(format!("READY {:.1}", ms(*T0.get().unwrap())));
                    emit(format!("RENDER {render:.1}"));
                }
                Pending::Filter(start) => emit(format!("FILTER {:.1} {visible}", ms(start))),
            });
        }

        let mut root = p.bounds();
        let side = root.cut_left(216.);
        self.paint_sidebar(p, side);
        let toolbar = root.cut_top(56.);
        self.paint_toolbar(p, toolbar);

        let mut body = root.inset(8., 0., 8., 0.);
        let header = body.cut_top(32.);
        p.border_bottom(header, LINE);
        let header_style = TextStyle::new(12.).weight(600);
        for ((label, _), cell) in COLS.iter().zip(columns(header.inset(12., 0., 12., 1.))) {
            p.label(cell, label, header_style, SUBTLE);
        }

        let (rows, visible) = (&self.rows, &self.visible);
        self.list.paint(p, body, visible.len(), |p, ix, rect| paint_row(p, &rows[visible[ix]], ix, rect));
    }

    fn event(&mut self, event: Event<'_, String>, cx: &mut Cx) {
        match event {
            Event::Message(line) => self.command(&line, cx),
            Event::PointerDown { pos, hit, shift } => {
                self.pressed = hit;
                if hit == Some(SEARCH) {
                    cx.focus(Some(SEARCH));
                    self.search.pointer_down(pos, shift);
                    cx.notify();
                }
            }
            Event::PointerMove { pos } => {
                if self.search.pointer_move(pos) {
                    cx.notify();
                }
            }
            Event::PointerUp { pos, .. } => {
                self.search.pointer_up();
                // A click: press and release on the same nav item.
                if let Some(Id(id)) = self.pressed.take()
                    && (NAV_ID..NAV_ID + NAV.len() as u64).contains(&id)
                    && nav_rects().nth((id - NAV_ID) as usize).is_some_and(|r| r.contains(pos))
                {
                    self.nav = (id - NAV_ID) as usize;
                    cx.notify();
                }
            }
            Event::Timer => {}
            Event::Scroll { pos, delta, .. } => {
                if self.list.contains(pos) && self.list.scroll(&delta) {
                    cx.notify();
                }
            }
            Event::Key { event, mods } => {
                if std::env::var_os("BENCH_LOG").is_some() {
                    eprintln!("key {:?} text {:?} mods {:?}", event.logical_key, event.text, mods);
                }
                if shortcut_modifier(mods) && shortcut_letter(event) == Some('q') {
                    cx.quit();
                } else if cx.focused() == Some(SEARCH)
                    && let Some(changed) = self.search.key(event, mods, cx.clipboard())
                {
                    cx.notify();
                    if changed {
                        self.search_changed(Instant::now());
                    }
                }
            }
            Event::Ime(ime) => {
                if std::env::var_os("BENCH_LOG").is_some() {
                    eprintln!("ime {ime:?}");
                }
                if cx.focused() == Some(SEARCH) && self.search.ime(ime) {
                    cx.notify();
                    self.search_changed(Instant::now());
                }
            }
        }
    }
}

impl Bench {
    fn paint_sidebar(&mut self, p: &mut Paint, side: Rect) {
        p.fill(side, rgb(0xf3f4f6));
        p.fill(Rect::new(side.right() - 1., side.y, 1., side.h), LINE);
        for (i, r) in nav_rects().enumerate() {
            let selected = i == self.nav;
            if p.hovered(r) {
                p.rounded(r, 7., rgb(0xe8ebf0));
            } else if selected {
                p.rounded(r, 7., rgb(0xdfe3ea));
            }
            p.hitbox(r, Id(NAV_ID + i as u64), CursorIcon::Default);
            let style = base().weight(if selected { 600 } else { 400 });
            p.label(r.pad(10., 7.), NAV[i], style, TEXT);
        }
    }

    fn paint_toolbar(&mut self, p: &mut Paint, toolbar: Rect) {
        p.border_bottom(toolbar, LINE);
        let inner = toolbar.inset(16., 0., 16., 1.);

        // Title and count share a baseline; the pair is centered vertically.
        let title = p.layout("Containers", TextStyle::new(18.).weight(600), None);
        let count = p.layout(&format!("{} of {}", self.visible.len(), self.rows.len()), base(), None);
        let above = title.baseline.max(count.baseline);
        let below = (title.height - title.baseline).max(count.height - count.baseline);
        let top = inner.y + (inner.h - above - below) / 2.;
        p.draw_text(&title, inner.x, top + above - title.baseline, TEXT);
        p.draw_text(&count, inner.x + title.width + 8., top + above - count.baseline, SUBTLE);

        let mut row = inner;
        let search = row.cut_right(260.).center_v(32.);
        p.bordered(search, 7., WHITE, 1., rgb(0xd0d7de));
        self.search.paint(p, search.pad(11., 7.), search);
    }
}

/// The nav items' rects: 44 px top padding, 10 px side padding, 2 px gaps.
fn nav_rects() -> impl Iterator<Item = Rect> {
    let h = 7. + base().line_height + 7.;
    (0..NAV.len()).map(move |i| Rect::new(10., 44. + i as f32 * (h + 2.), 216. - 1. - 20., h))
}

/// Column cells for a row's content rect, each with 10 px right padding.
fn columns(inner: Rect) -> impl Iterator<Item = Rect> {
    let mut x = inner.x;
    COLS.iter().map(move |(_, f)| {
        let w = inner.w * f;
        let cell = Rect::new(x, inner.y, (w - 10.).max(0.), inner.h);
        x += w;
        cell
    })
}

fn paint_row(p: &mut Paint, r: &Row, ix: usize, rect: Rect) {
    if p.hovered(rect) {
        p.fill(rect, rgb(0xf3f5f8));
    }
    p.border_bottom(rect, rgb(0xeceef1));
    p.hitbox(rect, Id(ROW_ID + ix as u64), CursorIcon::Default);

    let mut cells = columns(rect.inset(12., 0., 12., 1.));
    let mut next = || cells.next().unwrap();
    p.label(next(), &r.name, base().weight(500), TEXT);
    p.label(next(), r.image, base(), MUTED);

    let (state, fg, bg) =
        if r.running { ("running", rgb(0x1a7f37), rgb(0xdafbe1)) } else { ("exited", MUTED, rgb(0xeaeef2)) };
    let cell = next();
    let text = p.layout(state, TextStyle::new(12.), Some(cell.w - 16.));
    let pill = cell.center_v(text.height + 4.);
    let pill = Rect::new(pill.x, pill.y, (text.width + 16.).min(cell.w), pill.h);
    p.clip(cell, |p| {
        p.rounded(pill, 10., bg);
        p.draw_text(&text, pill.x + 8., pill.y + 2., fg);
    });

    p.label(next(), &r.ports, base(), TEXT);
    p.label(next(), &r.created, base(), MUTED);
}

fn arg_rows() -> usize {
    let args: Vec<String> = std::env::args().collect();
    args.iter()
        .position(|a| a == "--rows")
        .and_then(|i| args.get(i + 1))
        .and_then(|v| v.parse().ok())
        .or_else(|| std::env::var("BENCH_ROWS").ok().and_then(|v| v.parse().ok()))
        .unwrap_or(1000)
}

fn font_probe() {
    let f = own_ui::load_fonts();
    eprintln!("platform fonts: {:.1} ms, {} faces, family {:?} ({})", f.load_ms, f.faces, f.family, f.strategy);
    let (scan, faces) = own_ui::full_scan_ms();
    eprintln!("FontSystem::new() full scan: {scan:.1} ms, {faces} faces");
}

fn main() {
    T0.set(Instant::now()).unwrap();
    if std::env::var_os("BENCH_FONT_PROBE").is_some() {
        return font_probe();
    }
    let app = App::<String>::new();
    let rows = data::rows(arg_rows());

    let proxy = app.proxy();
    std::thread::spawn(move || {
        for line in std::io::stdin().lock().lines() {
            let Ok(line) = line else { break };
            if !proxy.send(line) {
                break;
            }
        }
    });

    let opts = WindowOptions {
        title: "podbag-bench (own)".into(),
        width: 1200.,
        height: 800.,
        min_size: None,
        // BENCH_NO_FOCUS: same switch as the GPUI and Tauri apps.
        focus: std::env::var_os("BENCH_NO_FOCUS").is_none().then_some(SEARCH),
        debug: std::env::var_os("BENCH_LOG").is_some(),
    };
    app.run(opts, move || Bench::new(rows));
}
