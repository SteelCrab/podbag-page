//! `input[type=range]`: a slider. Click or drag on the track sets the value.

use std::cell::Cell;
use std::rc::Rc;

use gpui::{
    App, Bounds, ElementId, MouseButton, Pixels, Window, canvas, div, prelude::*, px, relative,
};

use crate::theme::Theme;

type Handler = Rc<dyn Fn(&f64, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct Slider {
    id: ElementId,
    value: f64,
    min: f64,
    max: f64,
    step: f64,
    t: Theme,
    on_change: Option<Handler>,
}

impl Slider {
    pub fn new(
        id: impl Into<ElementId>,
        value: f64,
        min: f64,
        max: f64,
        step: f64,
        t: &Theme,
    ) -> Self {
        Self {
            id: id.into(),
            value,
            min,
            max,
            step,
            t: *t,
            on_change: None,
        }
    }

    pub fn on_change(mut self, f: impl Fn(&f64, &mut Window, &mut App) + 'static) -> Self {
        self.on_change = Some(Rc::new(f));
        self
    }
}

/// The value at x on a track, snapped to step.
fn value_at(x: Pixels, b: Bounds<Pixels>, min: f64, max: f64, step: f64) -> f64 {
    let w = f32::from(b.size.width).max(1.);
    let frac = ((f32::from(x - b.origin.x)) / w).clamp(0., 1.) as f64;
    let raw = min + frac * (max - min);
    let snapped = if step > 0. {
        min + ((raw - min) / step).round() * step
    } else {
        raw
    };
    snapped.clamp(min, max)
}

impl RenderOnce for Slider {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let (min, max, step) = (self.min, self.max, self.step);
        let frac = if max > min {
            ((self.value - min) / (max - min)).clamp(0., 1.) as f32
        } else {
            0.
        };
        let bounds: Rc<Cell<Option<Bounds<Pixels>>>> = Rc::new(Cell::new(None));
        let (b1, b2, b3) = (bounds.clone(), bounds.clone(), bounds);
        let (f1, f2) = (self.on_change.clone(), self.on_change);
        div()
            .id(self.id)
            .relative()
            .h(px(20.))
            .w_full()
            .min_w(px(60.))
            .cursor_pointer()
            .child(
                canvas(move |b, _, _| b1.set(Some(b)), |_, _, _, _| {})
                    .absolute()
                    .size_full(),
            )
            .child(
                div()
                    .absolute()
                    .top(px(8.))
                    .left_0()
                    .right_0()
                    .h(px(4.))
                    .rounded(px(2.))
                    .bg(t.sunken)
                    .border_1()
                    .border_color(t.line)
                    .child(
                        div()
                            .h_full()
                            .w(relative(frac))
                            .rounded(px(2.))
                            .bg(t.accent),
                    ),
            )
            .child(
                div()
                    .absolute()
                    .top(px(2.))
                    .left(relative(frac))
                    .ml(px(-8.))
                    .size(px(16.))
                    .rounded_full()
                    .bg(t.accent)
                    .border_2()
                    .border_color(t.surface)
                    .shadow_sm(),
            )
            .on_mouse_down(MouseButton::Left, move |e, w, cx| {
                if let (Some(b), Some(f)) = (b2.get(), &f1) {
                    f(&value_at(e.position.x, b, min, max, step), w, cx);
                }
            })
            .on_mouse_move(move |e, w, cx| {
                if e.pressed_button != Some(MouseButton::Left) {
                    return;
                }
                if let (Some(b), Some(f)) = (b3.get(), &f2) {
                    f(&value_at(e.position.x, b, min, max, step), w, cx);
                }
            })
    }
}
