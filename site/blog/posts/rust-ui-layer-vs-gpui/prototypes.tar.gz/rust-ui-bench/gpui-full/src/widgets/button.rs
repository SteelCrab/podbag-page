//! `.button`: a text button with an optional icon (normal, primary, danger).

use std::rc::Rc;

use gpui::{App, ClickEvent, ElementId, FontWeight, SharedString, Window, div, prelude::*, px};

use crate::icons::icon;
use crate::theme::Theme;

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Tone {
    Normal,
    Primary,
    Danger,
}

type Handler = Rc<dyn Fn(&ClickEvent, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct Button {
    id: ElementId,
    label: SharedString,
    icon: Option<&'static str>,
    tone: Tone,
    disabled: bool,
    full: bool,
    t: Theme,
    on_click: Option<Handler>,
}

impl Button {
    pub fn new(id: impl Into<ElementId>, label: impl Into<SharedString>, t: &Theme) -> Self {
        Self {
            id: id.into(),
            label: label.into(),
            icon: None,
            tone: Tone::Normal,
            disabled: false,
            full: false,
            t: *t,
            on_click: None,
        }
    }

    pub fn icon(mut self, name: &'static str) -> Self {
        self.icon = Some(name);
        self
    }

    pub fn tone(mut self, tone: Tone) -> Self {
        self.tone = tone;
        self
    }

    pub fn primary(self) -> Self {
        self.tone(Tone::Primary)
    }

    pub fn disabled(mut self, disabled: bool) -> Self {
        self.disabled = disabled;
        self
    }

    /// The full width of its parent (`.vm-button`).
    pub fn full_width(mut self) -> Self {
        self.full = true;
        self
    }

    pub fn on_click(mut self, f: impl Fn(&ClickEvent, &mut Window, &mut App) + 'static) -> Self {
        self.on_click = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Button {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let (bg, border, fg, hover) = match self.tone {
            Tone::Normal => (t.surface, t.line, t.ink, t.hover),
            Tone::Primary => (t.accent, t.accent, t.accent_ink, t.accent.opacity(0.92)),
            Tone::Danger => (
                t.danger_bg,
                t.danger_bg,
                gpui::white(),
                t.danger_bg.opacity(0.92),
            ),
        };
        let enabled = !self.disabled;
        div()
            .id(self.id)
            .flex()
            .flex_none()
            .items_center()
            .justify_center()
            .gap(px(6.))
            .min_h(px(32.))
            .px(px(12.))
            .when(self.full, |d| d.w_full().flex_shrink())
            .border_1()
            .border_color(border)
            .rounded(px(7.))
            .bg(bg)
            .text_color(fg)
            .font_weight(FontWeight::MEDIUM)
            .whitespace_nowrap()
            .when(self.full, |d| d.whitespace_normal())
            .when(!enabled, |d| d.opacity(0.45))
            .when(enabled, |d| d.cursor_pointer().hover(move |s| s.bg(hover)))
            .when_some(self.icon, |d, name| d.child(icon(name, px(16.), fg)))
            .child(self.label)
            .when_some(self.on_click.filter(|_| enabled), |d, f| {
                d.on_click(move |e, w, cx| f(e, w, cx))
            })
    }
}
