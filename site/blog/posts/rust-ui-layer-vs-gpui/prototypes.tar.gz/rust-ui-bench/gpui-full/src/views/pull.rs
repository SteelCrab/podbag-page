//! The pull panel (images.js): search Docker Hub or type a reference, choose where to
//! pull from, pick a tag, give a registry host, and watch the progress.
//! Registry login is out of scope.

use std::time::Duration;

use bench_api::{HubResult, Registry};
use gpui::{
    AnyElement, Context, Entity, Focusable, FontWeight, SharedString, Subscription, Task, Window,
    div, prelude::*, px,
};

use crate::app::*;
use crate::icons::icon;
use crate::theme::MONO;
use crate::widgets::chip::{dot, tag};
use crate::widgets::dialog::{Modal as ModalBox, Place};
use crate::widgets::{Button, InputEvent, TextInput};

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Step {
    Search,
    Tag,
    Host,
    Pulling,
    Done,
}

pub struct Pull {
    pub input: Entity<TextInput>,
    pub loc_filter: Entity<TextInput>,
    pub tag_input: Entity<TextInput>,
    pub host_input: Entity<TextInput>,
    pub location: String,
    /// Registry hosts the user gave: (registry id, host).
    pub hosts: Vec<(String, String)>,
    pub locations: Vec<Registry>,
    pub results: Vec<HubResult>,
    pub active: usize,
    pub step: Step,
    pub chosen: Option<HubResult>,
    pub search_supported: bool,
    pub search_error: Option<String>,
    pub lines: Vec<String>,
    pub busy: bool,
    pub menu_open: bool,
    pub pulling: String,
    pub pulled: String,
    pub error: Option<String>,
    pub after_host: Step,
    search_task: Option<Task<()>>,
}

/// A row of the result list: what was typed, or a search result.
struct Option_ {
    typed: bool,
    result: HubResult,
}

impl Pull {
    pub fn new(
        window: &mut Window,
        cx: &mut Context<Podbag>,
        subs: &mut Vec<Subscription>,
    ) -> Self {
        let input = cx.new(|cx| TextInput::new(cx, ""));
        let loc_filter = cx.new(|cx| TextInput::new(cx, "Search"));
        let tag_input = cx.new(|cx| TextInput::new(cx, ""));
        let host_input = cx.new(|cx| TextInput::new(cx, ""));
        subs.push(
            cx.subscribe_in(&input, window, |this, _, e: &InputEvent, w, cx| match e {
                InputEvent::Changed => this.pull_input_changed(cx),
                InputEvent::Up => this.pull_move(-1, cx),
                InputEvent::Down => this.pull_move(1, cx),
                InputEvent::Submit => this.pull_choose(None, w, cx),
            }),
        );
        subs.push(cx.subscribe_in(
            &loc_filter,
            window,
            |this, _, e: &InputEvent, w, cx| match e {
                InputEvent::Submit => {
                    if let Some(first) = this.filtered_locations(cx).first().map(|r| r.id.clone()) {
                        this.pick_location(first, w, cx);
                    }
                }
                _ => cx.notify(),
            },
        ));
        subs.push(
            cx.subscribe_in(&tag_input, window, |this, _, e: &InputEvent, w, cx| {
                if *e == InputEvent::Submit {
                    this.pull_tag(w, cx);
                }
            }),
        );
        subs.push(
            cx.subscribe_in(&host_input, window, |this, _, e: &InputEvent, w, cx| {
                if *e == InputEvent::Submit {
                    this.save_host(w, cx);
                }
            }),
        );
        Pull {
            input,
            loc_filter,
            tag_input,
            host_input,
            location: "dockerhub".into(),
            hosts: Vec::new(),
            locations: Vec::new(),
            results: Vec::new(),
            active: 0,
            step: Step::Search,
            chosen: None,
            search_supported: true,
            search_error: None,
            lines: Vec::new(),
            busy: false,
            menu_open: false,
            pulling: String::new(),
            pulled: String::new(),
            error: None,
            after_host: Step::Search,
            search_task: None,
        }
    }

    pub fn close(&mut self) {
        self.menu_open = false;
        self.search_task = None;
    }

    fn current(&self) -> Registry {
        self.locations
            .iter()
            .find(|l| l.id == self.location)
            .cloned()
            .unwrap_or(Registry {
                id: "dockerhub".into(),
                label: "Docker Hub".into(),
                host: "docker.io".into(),
                host_example: None,
                needs_host: false,
                account: None,
                hint: None,
            })
    }
}

/// images.js `looksFull`: a reference with a tag, a digest or a registry host.
fn looks_full(q: &str) -> bool {
    if q.contains(':') || q.contains('@') || q.starts_with("localhost/") {
        return true;
    }
    match q.split_once('/') {
        Some((first, _)) => first.contains('.'),
        None => false,
    }
}

impl Podbag {
    /// images.js `openPullPanel`.
    pub fn open_pull(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if !self.reachable() {
            return;
        }
        let p = &mut self.pull;
        p.step = Step::Search;
        p.results.clear();
        p.active = 0;
        p.lines.clear();
        p.error = None;
        p.menu_open = false;
        p.locations = self.api.registries(&p.hosts);
        let accent = self.theme.accent;
        for input in [&p.input, &p.loc_filter, &p.tag_input, &p.host_input] {
            input.update(cx, |i, _| i.accent = accent);
        }
        p.input.update(cx, |i, cx| {
            i.disabled = false;
            i.set_content("", cx);
        });
        self.update_pull_placeholder(cx);
        window.focus(&self.pull.input.read(cx).focus_handle(cx));
        self.modal = Some(Modal::Pull);
        cx.notify();
    }

    fn update_pull_placeholder(&mut self, cx: &mut Context<Self>) {
        let loc = self.pull.current();
        let text = if loc.id == "dockerhub" && self.pull.search_supported {
            self.tr.t("pull.searchPlaceholder")
        } else {
            self.tr.tv("pull.refPlaceholder", &[("name", &loc.label)])
        };
        self.pull.input.update(cx, |i, _| i.set_placeholder(&text));
    }

    fn pull_query(&self, cx: &Context<Self>) -> String {
        self.pull.input.read(cx).content.trim().to_string()
    }

    /// images.js `onPullInput`: search Docker Hub 300 ms after typing stops.
    fn pull_input_changed(&mut self, cx: &mut Context<Self>) {
        let q = self.pull_query(cx);
        let p = &mut self.pull;
        p.active = 0;
        if p.step != Step::Pulling {
            p.step = Step::Search;
        }
        p.search_task = None;
        if q.is_empty() || looks_full(&q) || p.location != "dockerhub" || !p.search_supported {
            p.results.clear();
            cx.notify();
            return;
        }
        p.search_task = Some(cx.spawn(async move |this, cx| {
            cx.background_executor()
                .timer(Duration::from_millis(300))
                .await;
            let _ = this.update(cx, |this, cx| {
                if this.pull.location != "dockerhub" || this.pull_query(cx) != q {
                    return;
                }
                let r = this.api.search(&q);
                this.pull.search_supported = r.supported;
                this.pull.search_error = r.error;
                this.pull.results = r.results;
                cx.notify();
            });
        }));
        cx.notify();
    }

    /// images.js `pullOptions`.
    fn pull_options(&self, cx: &Context<Self>) -> Vec<Option_> {
        let q = self.pull_query(cx);
        let mut out = Vec::new();
        if !q.is_empty() {
            let same = self.pull.results.iter().find(|r| r.name == q).cloned();
            let result = same.unwrap_or(HubResult {
                name: q.clone(),
                description: String::new(),
                star_count: 0,
                is_official: false,
            });
            out.push(Option_ {
                typed: true,
                result,
            });
        }
        for r in &self.pull.results {
            if r.name != q {
                out.push(Option_ {
                    typed: false,
                    result: r.clone(),
                });
            }
        }
        out
    }

    fn pull_move(&mut self, step: isize, cx: &mut Context<Self>) {
        if self.pull.step != Step::Search {
            return;
        }
        let n = self.pull_options(cx).len() as isize;
        if n == 0 {
            return;
        }
        self.pull.active = ((self.pull.active as isize + step + n) % n) as usize;
        cx.notify();
    }

    /// images.js `chooseOption`: the typed name pulls; a result asks for a tag.
    fn pull_choose(&mut self, ix: Option<usize>, window: &mut Window, cx: &mut Context<Self>) {
        if self.pull.step != Step::Search {
            return;
        }
        let mut options = self.pull_options(cx);
        let ix = ix.unwrap_or(self.pull.active);
        if ix >= options.len() {
            return;
        }
        let o = options.swap_remove(ix);
        if o.typed {
            self.start_pull(o.result.name, window, cx);
        } else {
            self.pull.chosen = Some(o.result);
            self.pull.step = Step::Tag;
            self.pull.tag_input.update(cx, |i, cx| {
                i.set_content("latest", cx);
                i.select_all_text(cx);
            });
            window.focus(&self.pull.tag_input.read(cx).focus_handle(cx));
            cx.notify();
        }
    }

    fn pull_tag(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let Some(chosen) = &self.pull.chosen else {
            return;
        };
        let tag = self.pull.tag_input.read(cx).content.trim().to_string();
        let tag = if tag.is_empty() {
            "latest".to_string()
        } else {
            tag
        };
        let image = format!("{}:{tag}", chosen.name);
        self.start_pull(image, window, cx);
    }

    /// images.js `startPull`.
    fn start_pull(&mut self, image: String, window: &mut Window, cx: &mut Context<Self>) {
        let loc = self.pull.current();
        if loc.needs_host && loc.host.is_empty() {
            self.ask_host(Step::Search, window, cx);
            return;
        }
        let p = &mut self.pull;
        p.step = Step::Pulling;
        p.busy = true;
        p.lines = vec![self.tr.t("pull.working")];
        p.pulling = image.clone();
        p.input.update(cx, |i, _| i.disabled = true);
        self.api.pull(&image, Some(&loc.id), Some(&loc.host));
        cx.notify();
    }

    pub fn pull_line(&mut self, line: String, cx: &mut Context<Self>) {
        if self.pull.step != Step::Pulling {
            return;
        }
        self.pull.lines.push(line);
        let n = self.pull.lines.len();
        if n > 200 {
            self.pull.lines.drain(..n - 200);
        }
        cx.notify();
    }

    pub fn pull_done(&mut self, result: Result<String, String>, cx: &mut Context<Self>) {
        let p = &mut self.pull;
        p.busy = false;
        p.step = Step::Done;
        p.input.update(cx, |i, _| i.disabled = false);
        match result {
            Ok(r) => {
                p.pulled = r.clone();
                p.error = None;
                let msg = self.tv("done.pull", &[("name", &r)]);
                self.toast(msg, false, cx);
                self.refresh_soon(cx);
            }
            Err(e) => self.pull.error = Some(e),
        }
        cx.notify();
    }

    /// Esc steps back first (a menu, the tag or host step), then closes.
    pub fn pull_escape(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let p = &mut self.pull;
        if p.menu_open {
            p.menu_open = false;
        } else if matches!(p.step, Step::Tag | Step::Host) && !p.busy {
            p.step = Step::Search;
            window.focus(&p.input.read(cx).focus_handle(cx));
        } else {
            self.close_modal(window, cx);
            return;
        }
        cx.notify();
    }

    fn ask_host(&mut self, after: Step, window: &mut Window, cx: &mut Context<Self>) {
        let loc = self.pull.current();
        self.pull.step = Step::Host;
        self.pull.after_host = after;
        self.pull.host_input.update(cx, |i, cx| {
            i.set_placeholder(
                loc.host_example
                    .as_deref()
                    .unwrap_or("registry.example.com"),
            );
            i.set_content(&loc.host, cx);
        });
        window.focus(&self.pull.host_input.read(cx).focus_handle(cx));
        cx.notify();
    }

    fn save_host(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let v = self.pull.host_input.read(cx).content.trim().to_string();
        if v.is_empty() {
            return;
        }
        let id = self.pull.location.clone();
        self.pull.hosts.retain(|(i, _)| *i != id);
        self.pull.hosts.push((id, v));
        self.pull.locations = self.api.registries(&self.pull.hosts);
        self.pull.step = Step::Search;
        self.update_pull_placeholder(cx);
        window.focus(&self.pull.input.read(cx).focus_handle(cx));
        cx.notify();
    }

    fn filtered_locations(&self, cx: &Context<Self>) -> Vec<Registry> {
        let q = self.pull.loc_filter.read(cx).content.to_lowercase();
        let terms: Vec<&str> = q.split_whitespace().collect();
        let alias = |id: &str| match id {
            "alibaba" => "Alibaba ACR Aliyun 알리바바 클라우드 阿里云 阿里雲 アリババクラウド",
            "acr" => "Microsoft Azure ACR 애저 에저",
            _ => "",
        };
        self.pull
            .locations
            .iter()
            .filter(|l| {
                let hay = format!(
                    "{} {} {} {} {}",
                    l.label,
                    l.id,
                    l.host,
                    l.host_example.clone().unwrap_or_default(),
                    alias(&l.id)
                )
                .to_lowercase();
                l.id == "custom" || terms.iter().all(|t| hay.contains(t))
            })
            .cloned()
            .collect()
    }

    fn pick_location(&mut self, id: String, window: &mut Window, cx: &mut Context<Self>) {
        self.pull.location = id;
        self.pull.results.clear();
        self.pull.menu_open = false;
        self.update_pull_placeholder(cx);
        let loc = self.pull.current();
        if loc.needs_host {
            self.ask_host(Step::Search, window, cx);
        } else {
            window.focus(&self.pull.input.read(cx).focus_handle(cx));
            self.pull_input_changed(cx);
        }
    }

    fn location_label(&self, l: &Registry) -> String {
        if l.needs_host && !l.host.is_empty() {
            format!("{} ({})", l.label, l.host)
        } else if l.id == "custom" {
            self.tr.t("pull.myRegistry")
        } else {
            l.label.clone()
        }
    }

    pub fn render_pull(&mut self, window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let loc = self.pull.current();
        let busy = self.pull.busy;
        let loc_text = if loc.id == "custom" && loc.host.is_empty() {
            self.tr.t("pull.myRegistry")
        } else {
            loc.label.clone()
        };
        let loc_button = div()
            .id("loc-button")
            .flex()
            .flex_none()
            .items_center()
            .gap(px(6.))
            .h(px(28.))
            .pl(px(10.))
            .pr(px(8.))
            .border_1()
            .border_color(t.line)
            .rounded(px(7.))
            .bg(t.sunken)
            .text_size(px(12.5))
            .font_weight(FontWeight::SEMIBOLD)
            .when(!busy, |d| d.cursor_pointer().hover(move |s| s.bg(t.hover)))
            .when(busy, |d| d.opacity(0.45))
            .when(loc.account.is_some(), |d| d.child(dot(t.green, 6.)))
            .child(loc_text)
            .child(icon("forward", px(13.), t.ink2).with_transformation(
                gpui::Transformation::rotate(gpui::radians(std::f32::consts::FRAC_PI_2)),
            ))
            .when(!busy, |d| {
                d.on_click(cx.listener(|this, _, w, cx| {
                    this.pull.menu_open = !this.pull.menu_open;
                    if this.pull.menu_open {
                        this.pull
                            .loc_filter
                            .update(cx, |i, cx| i.set_content("", cx));
                        w.focus(&this.pull.loc_filter.read(cx).focus_handle(cx));
                    }
                    cx.notify();
                }))
            });
        let head = div()
            .flex()
            .flex_none()
            .items_center()
            .gap(px(8.))
            .pl(px(14.))
            .pr(px(10.))
            .py(px(10.))
            .border_b_1()
            .border_color(t.line)
            .text_color(t.muted)
            .child(icon("search", px(18.), t.muted))
            .child(
                div()
                    .flex_1()
                    .min_w_0()
                    .text_size(px(15.))
                    .text_color(t.ink)
                    .child(self.pull.input.clone()),
            )
            .child(loc_button);
        let body = match self.pull.step {
            Step::Search => self.pull_search_body(cx),
            Step::Tag => self.pull_form(
                self.tv(
                    "pull.tagFor",
                    &[(
                        "name",
                        &self
                            .pull
                            .chosen
                            .as_ref()
                            .map(|c| c.name.clone())
                            .unwrap_or_default(),
                    )],
                ),
                self.pull.tag_input.clone(),
                Button::new("pull-tag", self.t("action.pull"), &t)
                    .primary()
                    .on_click(cx.listener(|this, _, w, cx| this.pull_tag(w, cx))),
            ),
            Step::Host => self.pull_form(
                self.tv("pull.host", &[("name", &loc.label)]),
                self.pull.host_input.clone(),
                Button::new("pull-host", self.t("action.save"), &t)
                    .primary()
                    .on_click(cx.listener(|this, _, w, cx| this.save_host(w, cx))),
            ),
            Step::Pulling | Step::Done => self.pull_progress(cx),
        };
        let mac = cfg!(target_os = "macos");
        let kbd = |k: &str| {
            div()
                .px(px(5.))
                .min_w(px(20.))
                .border_1()
                .border_b_2()
                .border_color(t.line)
                .rounded(px(5.))
                .bg(t.surface)
                .font_family(MONO)
                .text_size(px(11.5))
                .text_color(t.ink)
                .flex()
                .justify_center()
                .child(k.to_string())
        };
        let foot = div()
            .flex()
            .flex_none()
            .flex_wrap()
            .justify_between()
            .gap(px(10.))
            .px(px(12.))
            .py(px(8.))
            .border_t_1()
            .border_color(t.line)
            .text_size(px(12.))
            .text_color(t.muted)
            .child(
                div()
                    .flex()
                    .items_center()
                    .gap(px(4.))
                    .child(kbd("↑"))
                    .child(kbd("↓"))
                    .child(self.t("pull.keyMove"))
                    .child(div().w(px(8.)))
                    .child(kbd("Enter"))
                    .child(self.t("pull.keyPull"))
                    .child(div().w(px(8.)))
                    .child(kbd("Esc"))
                    .child(self.t("pull.keyClose")),
            )
            .child(
                div()
                    .flex()
                    .items_center()
                    .gap(px(4.))
                    .child(kbd(if mac { "⌘⇧P" } else { "Ctrl+Shift+P" }))
                    .child(self.t("pull.keyAnywhere")),
            );
        let menu = self.pull.menu_open.then(|| self.loc_menu(window, cx));
        let panel = div()
            .relative()
            .flex()
            .flex_col()
            .max_h(px(560.))
            .child(head)
            .child(
                div()
                    .id("pull-body")
                    .flex_1()
                    .min_h(px(120.))
                    .overflow_y_scroll()
                    .p(px(8.))
                    .child(body),
            )
            .child(foot)
            .children(menu);
        ModalBox::new(panel, &t)
            .width(560.)
            .place(Place::TopRight)
            .on_dismiss(cx.listener(|this, _, w, cx| this.close_modal(w, cx)))
            .into_any_element()
    }

    fn pull_search_body(&mut self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let note = |text: SharedString, error: bool| {
            div()
                .m(px(8.))
                .px(px(12.))
                .py(px(10.))
                .rounded(px(8.))
                .bg(t.sunken)
                .text_color(if error { t.red } else { t.ink2 })
                .text_size(px(13.))
                .child(text)
        };
        let loc = self.pull.current();
        let mut notes = Vec::new();
        if !self.pull.search_supported && loc.id == "dockerhub" {
            notes.push(note(self.t("pull.noSearch"), false));
        }
        if let Some(e) = &self.pull.search_error {
            notes.push(note(e.clone().into(), true));
        }
        let options = self.pull_options(cx);
        if options.is_empty() {
            let hint = if loc.id == "dockerhub" && self.pull.search_supported {
                self.t("pull.hint")
            } else {
                self.t("pull.hintRef")
            };
            return div()
                .child(note(hint, false))
                .children(notes)
                .into_any_element();
        }
        if self.pull.active >= options.len() {
            self.pull.active = 0;
        }
        let active = self.pull.active;
        let rows = options.into_iter().enumerate().map(|(i, o)| {
            let on = i == active;
            let r = o.result;
            let name: SharedString = if o.typed {
                self.tv("pull.pullThis", &[("name", &r.name)])
            } else {
                r.name.clone().into()
            };
            div()
                .id(("pull-option", i))
                .flex()
                .items_center()
                .gap(px(10.))
                .px(px(10.))
                .py(px(8.))
                .rounded(px(8.))
                .cursor_pointer()
                .text_color(if on { t.accent_text } else { t.ink2 })
                .when(on, |d| d.bg(t.accent_soft))
                .child(icon(
                    if o.typed { "pull" } else { "images" },
                    px(18.),
                    if on { t.accent_text } else { t.ink2 },
                ))
                .child(
                    div()
                        .flex_1()
                        .min_w_0()
                        .flex()
                        .flex_col()
                        .child(
                            div()
                                .flex()
                                .items_center()
                                .gap(px(6.))
                                .font_weight(FontWeight::SEMIBOLD)
                                .text_color(t.ink)
                                .child(div().truncate().child(name))
                                .when(r.is_official, |d| {
                                    d.child(
                                        tag(self.t("pull.official"), t.green, t.green_soft)
                                            .font_weight(FontWeight::SEMIBOLD),
                                    )
                                }),
                        )
                        .when(!r.description.is_empty(), |d| {
                            d.child(
                                div()
                                    .truncate()
                                    .text_size(px(12.5))
                                    .text_color(t.ink2)
                                    .child(r.description.clone()),
                            )
                        }),
                )
                .when(!o.typed || r.star_count > 0, |d| {
                    d.child(
                        div()
                            .flex()
                            .items_center()
                            .gap(px(4.))
                            .text_size(px(12.))
                            .text_color(t.muted)
                            .child(icon("star", px(13.), t.muted))
                            .child(r.star_count.to_string()),
                    )
                })
                .on_hover(cx.listener(move |this, hovered: &bool, _, cx| {
                    if *hovered && this.pull.active != i {
                        this.pull.active = i;
                        cx.notify();
                    }
                }))
                .on_click(cx.listener(move |this, _, w, cx| this.pull_choose(Some(i), w, cx)))
        });
        div()
            .children(notes)
            .child(div().flex().flex_col().gap(px(1.)).children(rows))
            .into_any_element()
    }

    fn pull_form(
        &self,
        label: SharedString,
        input: Entity<TextInput>,
        submit: Button,
    ) -> AnyElement {
        let t = self.theme;
        div()
            .flex()
            .flex_col()
            .gap(px(8.))
            .pt(px(8.))
            .px(px(8.))
            .pb(px(4.))
            .child(
                div()
                    .text_size(px(13.))
                    .font_weight(FontWeight::SEMIBOLD)
                    .child(label),
            )
            .child(
                div()
                    .h(px(34.))
                    .px(px(10.))
                    .flex()
                    .items_center()
                    .border_1()
                    .border_color(t.accent)
                    .rounded(px(7.))
                    .bg(t.surface)
                    .child(input),
            )
            .child(div().flex().justify_end().child(submit))
            .into_any_element()
    }

    fn pull_progress(&self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let form = div()
            .flex()
            .flex_col()
            .gap(px(8.))
            .pt(px(8.))
            .px(px(8.))
            .pb(px(4.));
        if self.pull.step == Step::Pulling {
            let tail: Vec<&str> = self
                .pull
                .lines
                .iter()
                .rev()
                .take(12)
                .rev()
                .map(String::as_str)
                .collect();
            return form
                .child(
                    div()
                        .font_weight(FontWeight::SEMIBOLD)
                        .child(self.tv("pull.pulling", &[("name", &self.pull.pulling)])),
                )
                .child(
                    div()
                        .px(px(12.))
                        .py(px(10.))
                        .max_h(px(260.))
                        .rounded(px(8.))
                        .bg(t.sunken)
                        .font_family(MONO)
                        .text_size(px(12.))
                        .child(tail.join("\n")),
                )
                .into_any_element();
        }
        let (text, color) = match &self.pull.error {
            None => (self.tv("done.pull", &[("name", &self.pull.pulled)]), t.ink),
            Some(e) => (e.clone().into(), t.red),
        };
        form.child(
            div()
                .font_weight(FontWeight::SEMIBOLD)
                .text_color(color)
                .child(text),
        )
        .child(
            div()
                .flex()
                .justify_end()
                .gap(px(8.))
                .child(
                    Button::new("pull-another", self.t("pull.another"), &t).on_click(cx.listener(
                        |this, _, w, cx| {
                            this.pull.step = Step::Search;
                            this.pull.error = None;
                            this.pull.input.update(cx, |i, cx| i.set_content("", cx));
                            w.focus(&this.pull.input.read(cx).focus_handle(cx));
                            cx.notify();
                        },
                    )),
                )
                .child(
                    Button::new("pull-close", self.t("pull.close"), &t)
                        .primary()
                        .on_click(cx.listener(|this, _, w, cx| this.close_modal(w, cx))),
                ),
        )
        .into_any_element()
    }

    /// The "Pull from" menu with its filter.
    fn loc_menu(&self, _window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let rows = self.filtered_locations(cx).into_iter().map(|l| {
            let chosen = l.id == self.pull.location;
            let label = self.location_label(&l);
            let id = l.id.clone();
            div()
                .id(SharedString::from(format!("loc-{}", l.id)))
                .flex()
                .items_center()
                .gap(px(8.))
                .px(px(8.))
                .py(px(6.))
                .rounded(px(7.))
                .cursor_pointer()
                .when(chosen, |d| d.bg(t.hover))
                .hover(move |s| s.bg(t.hover))
                .child(icon("images", px(16.), t.ink2))
                .child(
                    div()
                        .flex_1()
                        .min_w_0()
                        .flex()
                        .flex_col()
                        .child(div().truncate().text_size(px(13.5)).child(label))
                        .when_some(l.account.clone(), |d, a| {
                            d.child(
                                div()
                                    .flex()
                                    .items_center()
                                    .gap(px(5.))
                                    .text_size(px(12.))
                                    .text_color(t.ink2)
                                    .child(dot(t.green, 6.))
                                    .child(a),
                            )
                        }),
                )
                .when(chosen, |d| d.child(icon("check", px(15.), t.accent_text)))
                .on_click(cx.listener(move |this, _, w, cx| this.pick_location(id.clone(), w, cx)))
        });
        div()
            .id("loc-menu")
            .occlude()
            .absolute()
            .top(px(50.))
            .right(px(10.))
            .w(px(400.))
            .max_h(px(420.))
            .overflow_y_scroll()
            .p(px(6.))
            .border_1()
            .border_color(t.line)
            .rounded(px(10.))
            .bg(t.surface)
            .shadow_lg()
            .child(
                div()
                    .px(px(4.))
                    .pt(px(2.))
                    .pb(px(6.))
                    .child(
                        div()
                            .mx(px(4.))
                            .mt(px(4.))
                            .mb(px(6.))
                            .text_size(px(11.5))
                            .font_weight(FontWeight::SEMIBOLD)
                            .text_color(t.muted)
                            .child(self.t("pull.location")),
                    )
                    .child(
                        div()
                            .h(px(30.))
                            .px(px(8.))
                            .flex()
                            .items_center()
                            .border_1()
                            .border_color(t.line)
                            .rounded(px(6.))
                            .bg(t.surface)
                            .child(self.pull.loc_filter.clone()),
                    ),
            )
            .child(div().flex().flex_col().gap(px(1.)).children(rows))
            .into_any_element()
    }
}
