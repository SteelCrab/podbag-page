//! The widget layer: reusable parts with the look of style.css. They know the theme,
//! not the app.

pub mod button;
pub mod checkbox;
pub mod chip;
pub mod code;
pub mod dialog;
pub mod fields;
pub mod icon_button;
pub mod input;
pub mod logs;
pub mod segmented;
pub mod select;
pub mod slider;
pub mod table;
pub mod tabs;
pub mod toast;
pub mod tooltip;

pub use button::{Button, Tone};
pub use checkbox::Checkbox;
pub use icon_button::{IconButton, IconTone};
pub use input::{InputEvent, TextInput};
