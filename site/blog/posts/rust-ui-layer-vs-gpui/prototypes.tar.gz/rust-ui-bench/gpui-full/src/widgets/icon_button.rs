//! `.icon-button`: an icon-only button, named by its tooltip.

use std::rc::Rc;

use gpui::{App, ClickEvent, ElementId, Hsla, SharedString, Window, div, prelude::*, px};

use crate::icons::icon;
use crate::theme::Theme;
use crate::widgets::tooltip::Tooltip;

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum IconTone {
    Normal,
    /// `.accent`: the start button.
    Accent,
    /// `.danger`: red on hover.
    Danger,
}

type Handler = Rc<dyn Fn(&ClickEvent, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct IconButton {
    id: ElementId,
    icon: &'static str,
    label: SharedString,
    tone: IconTone,
    disabled: bool,
    selected: bool,
    size: f32,
    rotate_icon: Option<f32>,
    t: Theme,
    on_click: Option<Handler>,
}

impl IconButton {
    pub fn new(
        id: impl Into<ElementId>,
        icon: &'static str,
        label: impl Into<SharedString>,
        t: &Theme,
    ) -> Self {
        Self {
            id: id.into(),
            icon,
            label: label.into(),
            tone: IconTone::Normal,
            disabled: false,
            selected: false,
            size: 30.,
            rotate_icon: None,
            t: *t,
            on_click: None,
        }
    }

    pub fn tone(mut self, tone: IconTone) -> Self {
        self.tone = tone;
        self
    }

    pub fn disabled(mut self, disabled: bool) -> Self {
        self.disabled = disabled;
        self
    }

    /// `aria-current="page"` in the top bar.
    pub fn selected(mut self, selected: bool) -> Self {
        self.selected = selected;
        self
    }

    pub fn size(mut self, size: f32) -> Self {
        self.size = size;
        self
    }

    /// A chevron's turn in degrees (the disclosure buttons of the sidebar).
    pub fn rotate(mut self, degrees: f32) -> Self {
        self.rotate_icon = Some(degrees);
        self
    }

    pub fn on_click(mut self, f: impl Fn(&ClickEvent, &mut Window, &mut App) + 'static) -> Self {
        self.on_click = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for IconButton {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let fg: Hsla = match (self.selected, self.tone) {
            (true, _) => t.accent_text,
            (_, IconTone::Accent) => t.accent_text,
            _ => t.ink2,
        };
        let enabled = !self.disabled;
        let label = self.label.clone();
        let danger = self.tone == IconTone::Danger;
        let mut glyph = icon(
            self.icon,
            px(if self.rotate_icon.is_some() { 14. } else { 17. }),
            fg,
        );
        if enabled {
            let hover = if danger { t.red } else { t.ink };
            glyph = glyph.group_hover("icon-button", move |s| s.text_color(hover));
        }
        if let Some(deg) = self.rotate_icon {
            glyph = glyph.with_transformation(gpui::Transformation::rotate(gpui::radians(
                deg.to_radians(),
            )));
        }
        div()
            .id(self.id)
            .group("icon-button")
            .flex()
            .flex_none()
            .items_center()
            .justify_center()
            .size(px(self.size))
            .border_1()
            .border_color(gpui::transparent_black())
            .rounded(px(7.))
            .when(self.selected, |d| d.bg(t.accent_soft))
            .when(!enabled, |d| d.opacity(0.45))
            .when(enabled && !danger, |d| {
                d.cursor_pointer()
                    .hover(move |s| s.bg(t.hover).border_color(t.line))
            })
            .when(enabled && danger, |d| {
                d.cursor_pointer().hover(move |s| s.bg(t.red_soft))
            })
            .child(glyph)
            .when(!label.is_empty(), |d| {
                d.tooltip(move |_, cx| Tooltip::view(label.clone(), &t, cx))
            })
            .when_some(self.on_click.filter(|_| enabled), |d, f| {
                d.on_click(move |e, w, cx| {
                    cx.stop_propagation();
                    f(e, w, cx)
                })
            })
    }
}
