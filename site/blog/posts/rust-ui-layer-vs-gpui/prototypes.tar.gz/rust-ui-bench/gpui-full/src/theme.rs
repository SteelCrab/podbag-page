//! The colours of `desktop/ui/style.css` (light and dark), and the fonts.

use gpui::{Hsla, rgb};

#[derive(Clone, Copy)]
pub struct Theme {
    pub page: Hsla,
    pub surface: Hsla,
    pub sunken: Hsla,
    pub hover: Hsla,
    pub ink: Hsla,
    pub ink2: Hsla,
    pub muted: Hsla,
    pub line: Hsla,
    pub accent: Hsla,
    pub accent_text: Hsla,
    pub accent_soft: Hsla,
    pub accent_ink: Hsla,
    pub green: Hsla,
    pub green_soft: Hsla,
    pub amber: Hsla,
    pub amber_soft: Hsla,
    pub red: Hsla,
    pub red_soft: Hsla,
    pub danger_bg: Hsla,
    pub gray_soft: Hsla,
    pub backdrop: Hsla,
}

fn c(hex: u32) -> Hsla {
    rgb(hex).into()
}

impl Theme {
    pub fn light() -> Theme {
        Theme {
            page: c(0xf9f9f7),
            surface: c(0xffffff),
            sunken: c(0xf2f1ed),
            hover: c(0xefeee9),
            ink: c(0x0b0b0b),
            ink2: c(0x52514e),
            muted: c(0x6f6e69),
            line: c(0xe1e0d9),
            accent: c(0x2a78d6),
            accent_text: c(0x1d5fae),
            accent_soft: c(0xe5eefa),
            accent_ink: c(0xffffff),
            green: c(0x1b7f45),
            green_soft: c(0xe3f3e9),
            amber: c(0x8f5a00),
            amber_soft: c(0xfbf0d9),
            red: c(0xb8322d),
            red_soft: c(0xfbe6e5),
            danger_bg: c(0xb8322d),
            gray_soft: c(0xeeede8),
            backdrop: gpui::hsla(0., 0., 0., 0.35),
        }
    }

    pub fn dark() -> Theme {
        Theme {
            page: c(0x0d0d0d),
            surface: c(0x1a1a19),
            sunken: c(0x242422),
            hover: c(0x262624),
            ink: c(0xf0efec),
            ink2: c(0xc3c2b7),
            muted: c(0x9c9b94),
            line: c(0x2c2c2a),
            accent: c(0x3987e5),
            accent_text: c(0x8ab8f3),
            accent_soft: c(0x1b2a3f),
            accent_ink: c(0xffffff),
            green: c(0x5fd08f),
            green_soft: c(0x17301f),
            amber: c(0xf0b54d),
            amber_soft: c(0x352a14),
            red: c(0xf47c76),
            red_soft: c(0x3a1b1a),
            danger_bg: c(0xc4413b),
            gray_soft: c(0x2a2a28),
            backdrop: gpui::hsla(0., 0., 0., 0.35),
        }
    }
}

/// The colour of a settings icon tile (`.setting-<key>`).
pub fn setting_color(key: &str) -> Hsla {
    c(match key {
        "startup" => 0x24846c,
        "language" => 0x3379bd,
        "theme" => 0x8254b2,
        "engine" => 0x516887,
        "vm" => 0xa76528,
        "updates" => 0x316fb9,
        "terminalCommand" => 0x3d7a55,
        _ => 0x677382,
    })
}

/// `--mono`.
pub const MONO: &str = if cfg!(target_os = "macos") {
    "Menlo"
} else if cfg!(target_os = "windows") {
    "Consolas"
} else {
    "DejaVu Sans Mono"
};

/// system-ui.
pub const UI_FONT: &str = if cfg!(target_os = "macos") {
    ".SystemUIFont"
} else if cfg!(target_os = "windows") {
    "Segoe UI"
} else {
    "Noto Sans"
};
