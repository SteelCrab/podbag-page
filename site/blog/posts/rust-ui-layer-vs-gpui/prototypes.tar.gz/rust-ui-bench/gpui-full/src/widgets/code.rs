//! `.code` (a command with a copy button) and `pre.json` (a scrolling text block).

use gpui::{
    App, ClipboardItem, Div, ElementId, SharedString, Stateful, Window, div, prelude::*, px,
};

use crate::theme::{MONO, Theme};
use crate::widgets::icon_button::IconButton;

/// A one-line command with a copy button. `on_copied` runs after the copy.
pub fn code_line(
    id: impl Into<ElementId>,
    text: impl Into<SharedString>,
    copy_label: SharedString,
    t: &Theme,
    on_copied: impl Fn(&mut Window, &mut App) + 'static,
) -> Div {
    let text: SharedString = text.into();
    let copy = text.clone();
    div()
        .flex()
        .items_center()
        .gap(px(6.))
        .max_w_full()
        .mt(px(10.))
        .pl(px(14.))
        .pr(px(6.))
        .py(px(6.))
        .rounded(px(8.))
        .bg(t.sunken)
        .border_1()
        .border_color(t.line)
        .child(
            div()
                .min_w_0()
                .font_family(MONO)
                .text_size(px(13.))
                .whitespace_nowrap()
                .overflow_hidden()
                .child(text),
        )
        .child(
            IconButton::new(id, "copy", copy_label, t).on_click(move |_, w, cx| {
                cx.write_to_clipboard(ClipboardItem::new_string(copy.to_string()));
                on_copied(w, cx);
            }),
        )
}

/// `pre.json`: monospace text that keeps its line breaks, scrolling when long.
pub fn pre(id: impl Into<ElementId>, text: impl Into<SharedString>, t: &Theme) -> Stateful<Div> {
    div()
        .id(id)
        .flex_1()
        .min_h_0()
        .overflow_y_scroll()
        .py(px(12.))
        .px(px(14.))
        .rounded(px(8.))
        .bg(t.surface)
        .border_1()
        .border_color(t.line)
        .font_family(MONO)
        .text_size(px(12.5))
        .line_height(px(19.))
        .text_color(t.ink)
        .child(text.into())
}
