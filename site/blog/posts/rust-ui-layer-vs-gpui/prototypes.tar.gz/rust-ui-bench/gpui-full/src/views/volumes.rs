//! Volumes: columns, cells, the Info fields and the create dialog.

use std::rc::Rc;

use gpui::{AnyElement, Context, FontWeight, Window, div, prelude::*};

use crate::app::*;
use crate::widgets::fields::Fields;
use crate::widgets::table::Column;

impl Podbag {
    pub fn volume_columns(&self) -> Vec<Column> {
        vec![
            Column::flex(self.t("col.name")),
            Column::fixed(self.t("col.driver"), 120.),
            Column::fixed(self.t("col.created"), 160.),
        ]
    }

    pub fn volume_cells(&self, i: usize) -> Vec<AnyElement> {
        let v = &self.lists.volumes[i];
        let created = self.ago(bench_api::fmt::parse_rfc3339(&v.created_at));
        vec![
            div()
                .truncate()
                .font_weight(FontWeight::SEMIBOLD)
                .child(v.name.clone())
                .into_any_element(),
            div().truncate().child(v.driver.clone()).into_any_element(),
            div()
                .truncate()
                .text_color(self.theme.ink2)
                .child(created)
                .into_any_element(),
        ]
    }

    pub fn volume_info(&self, i: usize) -> Fields {
        let v = &self.lists.volumes[i];
        let none = self.tr.t("detail.none");
        Fields::new(&self.theme)
            .text(self.t("col.name"), v.name.clone(), &none, false)
            .text(self.t("col.driver"), v.driver.clone(), &none, false)
            .text(self.t("detail.path"), v.mountpoint.clone(), &none, true)
            .text(
                self.t("col.created"),
                self.ago(bench_api::fmt::parse_rfc3339(&v.created_at)),
                &none,
                false,
            )
    }

    /// app.js `createVolume`.
    pub fn create_volume(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let work: AskWork = Rc::new(|this, name, _, cx| {
            this.api.create_volume(&name)?;
            this.refresh_soon(cx);
            Ok(())
        });
        self.ask(
            self.t("volume.create"),
            self.t("col.name"),
            "",
            "data",
            self.t("volume.create"),
            window,
            cx,
            work,
        );
    }
}
