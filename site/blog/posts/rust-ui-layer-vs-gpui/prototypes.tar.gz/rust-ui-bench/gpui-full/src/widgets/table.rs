//! `.list`: a table with fixed-width and flexible columns. The rows go in a
//! `uniform_list` (only the visible rows are built), so 10,000 rows stay cheap.

use std::ops::Range;

use gpui::{
    AnyElement, App, Div, ElementId, FontWeight, SharedString, Stateful, UniformList,
    UniformListScrollHandle, Window, div, prelude::*, px, uniform_list,
};

use crate::theme::Theme;

#[derive(Clone)]
pub struct Column {
    pub label: SharedString,
    /// None: shares the free width with the other flexible columns.
    pub width: Option<f32>,
}

impl Column {
    pub fn flex(label: impl Into<SharedString>) -> Self {
        Self {
            label: label.into(),
            width: None,
        }
    }

    pub fn fixed(label: impl Into<SharedString>, width: f32) -> Self {
        Self {
            label: label.into(),
            width: Some(width),
        }
    }
}

/// One cell of a column (`td` padding).
pub fn cell(width: Option<f32>) -> Div {
    let d = div()
        .flex()
        .flex_col()
        .justify_center()
        .min_w_0()
        .px(px(10.))
        .overflow_hidden();
    match width {
        Some(w) => d.w(px(w)).flex_none(),
        None => d.flex_1().flex_basis(px(0.)),
    }
}

/// The header row (`th`). `actions`: the width of the actions column, if any.
pub fn header(cols: &[Column], actions: Option<f32>, t: &Theme) -> Div {
    div()
        .flex()
        .flex_none()
        .w_full()
        .items_center()
        .pt(px(10.))
        .pb(px(8.))
        .border_b_1()
        .border_color(t.line)
        .text_size(px(12.))
        .font_weight(FontWeight::SEMIBOLD)
        .text_color(t.muted)
        .children(
            cols.iter()
                .map(|c| cell(c.width).child(div().truncate().child(c.label.clone()))),
        )
        .children(actions.map(|w| cell(Some(w))))
}

/// A body row: cells in column order, then the actions.
pub fn row(
    id: impl Into<ElementId>,
    cols: &[Column],
    cells: Vec<AnyElement>,
    actions: Option<(f32, AnyElement)>,
    height: f32,
    t: &Theme,
) -> Stateful<Div> {
    let hover = t.hover;
    div()
        .id(id)
        .flex()
        .w_full()
        .items_center()
        .h(px(height))
        .border_b_1()
        .border_color(t.line)
        .rounded(px(7.))
        .cursor_pointer()
        .hover(move |s| s.bg(hover))
        .children(
            cells
                .into_iter()
                .zip(cols.iter())
                .map(|(c, col)| cell(col.width).child(c)),
        )
        .children(actions.map(|(w, a)| cell(Some(w)).items_end().child(a)))
}

/// The scrolling body of a table.
pub fn body<R: IntoElement>(
    id: impl Into<ElementId>,
    count: usize,
    scroll: &UniformListScrollHandle,
    render: impl 'static + Fn(Range<usize>, &mut Window, &mut App) -> Vec<R>,
) -> UniformList {
    uniform_list(id, count, render)
        .track_scroll(scroll.clone())
        .flex_1()
}
