//! `dl.fields`: label and value rows. The label column is as wide as the widest label
//! (at least 110 px), as `minmax(110px, max-content)` in style.css.

use gpui::{AnyElement, App, Font, Pixels, SharedString, TextRun, Window, div, prelude::*, px};

use crate::theme::{MONO, Theme};

pub struct Row {
    label: SharedString,
    value: AnyElement,
}

#[derive(IntoElement)]
pub struct Fields {
    rows: Vec<Row>,
    t: Theme,
    gap_y: f32,
    min_label: f32,
}

impl Fields {
    pub fn new(t: &Theme) -> Self {
        Self {
            rows: Vec::new(),
            t: *t,
            gap_y: 10.,
            min_label: 110.,
        }
    }

    /// A text value; empty text shows `none` instead.
    pub fn text(
        self,
        label: impl Into<SharedString>,
        value: impl Into<SharedString>,
        none: &str,
        mono: bool,
    ) -> Self {
        let value: SharedString = value.into();
        let shown = if value.is_empty() {
            SharedString::from(none.to_string())
        } else {
            value
        };
        let el = div()
            .min_w_0()
            .when(mono, |d| d.font_family(MONO).text_size(px(12.5)))
            .child(shown);
        self.row(label, el)
    }

    pub fn row(mut self, label: impl Into<SharedString>, value: impl IntoElement) -> Self {
        self.rows.push(Row {
            label: label.into(),
            value: value.into_any_element(),
        });
        self
    }
}

/// The width of one line of text in the window's font at `size`.
pub fn text_width(text: &SharedString, size: Pixels, window: &mut Window) -> Pixels {
    let style = window.text_style();
    let font: Font = style.font();
    let run = TextRun {
        len: text.len(),
        font,
        color: style.color,
        background_color: None,
        underline: None,
        strikethrough: None,
    };
    window
        .text_system()
        .shape_line(text.clone(), size, &[run], None)
        .width
}

impl RenderOnce for Fields {
    fn render(self, window: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let size = window.text_style().font_size.to_pixels(window.rem_size());
        let widest = self
            .rows
            .iter()
            .map(|r| f32::from(text_width(&r.label, size, window)))
            .fold(self.min_label, f32::max);
        let label_w = widest.ceil() + 1.;
        div()
            .flex()
            .flex_col()
            .gap(px(self.gap_y))
            .children(self.rows.into_iter().map(move |r| {
                div()
                    .flex()
                    .gap(px(22.))
                    .child(
                        div()
                            .flex_none()
                            .w(px(label_w))
                            .text_color(t.ink2)
                            .child(r.label),
                    )
                    .child(div().flex_1().min_w_0().child(r.value))
            }))
    }
}
