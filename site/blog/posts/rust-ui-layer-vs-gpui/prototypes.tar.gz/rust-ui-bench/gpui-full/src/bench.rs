//! Benchmark hooks (same protocol as the parity prototypes): stdout `READY`, `RENDER`,
//! `FILTER <ms> <visible>`, `VIEW <name> <ms>`. A report is printed when the frame after
//! the change begins, so the changed frame has been presented.

use std::io::Write as _;
use std::sync::OnceLock;
use std::time::Instant;

use gpui::Window;

pub static T0: OnceLock<Instant> = OnceLock::new();

pub enum Pending {
    FirstFrame(Instant),
    Filter(Instant),
    View(String, Instant),
}

pub struct Bench {
    pub pending: Vec<Pending>,
    /// When `filter <text>` arrived (the filter time counts from here).
    pub filter_started: Option<Instant>,
}

pub fn emit(line: String) {
    let mut out = std::io::stdout().lock();
    let _ = writeln!(out, "{line}");
    let _ = out.flush();
}

pub fn ms(since: Instant) -> f64 {
    since.elapsed().as_secs_f64() * 1000.0
}

pub fn log_enabled() -> bool {
    std::env::var_os("BENCH_LOG").is_some()
}

impl Bench {
    pub fn new(start: Instant) -> Self {
        Self {
            pending: vec![Pending::FirstFrame(start)],
            filter_started: None,
        }
    }

    /// Called in each render: schedule the reports for this frame.
    pub fn on_render(&mut self, window: &mut Window, visible: usize) {
        for p in self.pending.drain(..) {
            window.on_next_frame(move |_, _| match p {
                Pending::FirstFrame(start) => {
                    let render = ms(start);
                    emit(format!("READY {:.1}", ms(*T0.get().unwrap())));
                    emit(format!("RENDER {render:.1}"));
                }
                Pending::Filter(start) => emit(format!("FILTER {:.1} {visible}", ms(start))),
                Pending::View(name, start) => emit(format!("VIEW {name} {:.1}", ms(start))),
            });
        }
    }
}
