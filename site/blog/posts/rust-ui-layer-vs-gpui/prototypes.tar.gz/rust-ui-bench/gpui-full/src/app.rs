//! The window's state and behaviour (app.js `S` and its functions): connecting,
//! the lists, actions, dialogs, history, backend events and the benchmark hooks.
//! Each view renders from here (views/*.rs); the frame is in shell.rs.

use std::collections::HashSet;
use std::rc::Rc;
use std::time::{Duration, Instant};

use bench_api::i18n::I18n;
use bench_api::*;
use gpui::{
    App, AppContext, Context, Entity, FocusHandle, Focusable, SharedString, Subscription, Task,
    UniformListScrollHandle, Window, WindowAppearance, actions,
};

use crate::bench::{Bench, Pending};
use crate::theme::Theme;
use crate::views::kubernetes::Kube;
use crate::views::pull::Pull;
use crate::views::settings::SettingsUi;
use crate::widgets::logs::LogView;
use crate::widgets::toast::Toasts;
use crate::widgets::{InputEvent, TextInput, Tone};

actions!(
    podbag,
    [
        Back,
        Forward,
        ToggleSidebar,
        FocusSearch,
        Escape,
        OpenPull,
        OpenSettings
    ]
);

/// The pages of the window.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum View {
    Migration,
    Containers,
    Images,
    Volumes,
    Networks,
    Training,
    Kubernetes,
    Settings,
}

impl View {
    pub fn kind(self) -> Option<Kind> {
        match self {
            View::Containers => Some(Kind::Containers),
            View::Images => Some(Kind::Images),
            View::Volumes => Some(Kind::Volumes),
            View::Networks => Some(Kind::Networks),
            _ => None,
        }
    }

    pub fn of(kind: Kind) -> View {
        match kind {
            Kind::Containers => View::Containers,
            Kind::Images => View::Images,
            Kind::Volumes => View::Volumes,
            Kind::Networks => View::Networks,
        }
    }

    /// The names of `nav <view>`.
    pub fn parse(s: &str) -> Option<View> {
        Some(match s {
            "containers" => View::Containers,
            "images" => View::Images,
            "volumes" => View::Volumes,
            "networks" => View::Networks,
            "kubernetes" => View::Kubernetes,
            "settings" => View::Settings,
            "migration" | "migrate" => View::Migration,
            "training" | "tutorials" => View::Training,
            _ => return None,
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DetailTab {
    Info,
    Logs,
    Inspect,
}

pub struct Detail {
    pub kind: Kind,
    pub id: String,
    pub tab: DetailTab,
    /// The inspect JSON, or its error.
    pub inspect: Option<SharedString>,
    /// `top` and `stats` of a running container (title key, text).
    pub extra: Vec<(&'static str, SharedString)>,
}

/// The four engine lists, with lower-case search text and the rows that match.
#[derive(Default)]
pub struct Lists {
    pub containers: Vec<Container>,
    pub images: Vec<Image>,
    pub volumes: Vec<Volume>,
    pub networks: Vec<Network>,
    pub hay: [Vec<String>; 4],
    pub visible: [Vec<usize>; 4],
}

pub fn kind_ix(kind: Kind) -> usize {
    match kind {
        Kind::Containers => 0,
        Kind::Images => 1,
        Kind::Volumes => 2,
        Kind::Networks => 3,
    }
}

impl Lists {
    pub fn len(&self, kind: Kind) -> usize {
        match kind {
            Kind::Containers => self.containers.len(),
            Kind::Images => self.images.len(),
            Kind::Volumes => self.volumes.len(),
            Kind::Networks => self.networks.len(),
        }
    }

    /// app.js `objectId`.
    pub fn id(&self, kind: Kind, i: usize) -> &str {
        match kind {
            Kind::Containers => &self.containers[i].id,
            Kind::Images => &self.images[i].id,
            Kind::Volumes => &self.volumes[i].name,
            Kind::Networks => &self.networks[i].id,
        }
    }

    /// app.js `objectName`.
    pub fn name(&self, kind: Kind, i: usize) -> &str {
        match kind {
            Kind::Containers => self.containers[i].name(),
            Kind::Images => self.images[i].name(),
            Kind::Volumes => &self.volumes[i].name,
            Kind::Networks => &self.networks[i].name,
        }
    }

    pub fn find(&self, kind: Kind, id: &str) -> Option<usize> {
        (0..self.len(kind)).find(|&i| self.id(kind, i) == id)
    }

    /// The fields app.js `matches` searches, joined and in lower case.
    fn build_hay(&mut self, kind: Kind) {
        let hay: Vec<String> = match kind {
            Kind::Containers => self
                .containers
                .iter()
                .map(|c| {
                    format!(
                        "{}\n{}\n{}\n{}\n{}",
                        c.name(),
                        c.image,
                        c.id,
                        c.state,
                        c.ports_text()
                    )
                    .to_lowercase()
                })
                .collect(),
            Kind::Images => self
                .images
                .iter()
                .map(|i| format!("{}\n{}", i.repo_tags.join("\n"), i.id).to_lowercase())
                .collect(),
            Kind::Volumes => self
                .volumes
                .iter()
                .map(|v| format!("{}\n{}", v.name, v.driver).to_lowercase())
                .collect(),
            Kind::Networks => self
                .networks
                .iter()
                .map(|n| {
                    format!("{}\n{}\n{}\n{}", n.name, n.driver, n.id, n.subnet()).to_lowercase()
                })
                .collect(),
        };
        self.hay[kind_ix(kind)] = hay;
    }

    pub fn filter(&mut self, kind: Kind, query: &str) {
        let q = query.trim().to_lowercase();
        let hay = &self.hay[kind_ix(kind)];
        self.visible[kind_ix(kind)] = (0..hay.len())
            .filter(|&i| q.is_empty() || hay[i].contains(&q))
            .collect();
    }
}

#[derive(Clone, PartialEq)]
struct HistoryEntry {
    view: View,
    detail: Option<(Kind, String, DetailTab)>,
    kube: Option<KubeKind>,
}

/// A dialog's answer handler.
pub type OnYes = Box<dyn FnOnce(&mut Podbag, &mut Window, &mut Context<Podbag>)>;
pub type AskWork =
    Rc<dyn Fn(&mut Podbag, String, &mut Window, &mut Context<Podbag>) -> Result<(), String>>;
pub type OnChoose = Box<dyn FnOnce(&mut Podbag, &str, &mut Window, &mut Context<Podbag>)>;

pub enum Modal {
    Confirm {
        title: SharedString,
        text: SharedString,
        yes: SharedString,
        cancel: SharedString,
        tone: Tone,
        on_yes: Option<OnYes>,
    },
    Ask {
        title: SharedString,
        label: SharedString,
        ok: SharedString,
        input: Entity<TextInput>,
        progress: SharedString,
        work: AskWork,
        _sub: Subscription,
    },
    Choose {
        title: SharedString,
        text: SharedString,
        buttons: Vec<(SharedString, SharedString, Tone)>,
        on: Option<OnChoose>,
    },
    KubeObject {
        title: SharedString,
        context: SharedString,
        json: SharedString,
    },
    Pull,
    Import {
        items: Vec<(DockerImage, bool)>,
        status: SharedString,
        busy: bool,
    },
}

pub struct Sidebar {
    pub width: f32,
    pub collapsed: bool,
    /// While the divider is dragged: (start x, start width, width now).
    pub drag: Option<(f32, f32, f32)>,
}

pub const SIDEBAR_MIN: f32 = 160.;
pub const SIDEBAR_MAX: f32 = 360.;
pub const SIDEBAR_RAIL: f32 = 56.;

pub struct Podbag {
    pub api: Backend,
    pub tr: I18n,
    pub theme: Theme,
    pub focus: FocusHandle,
    pub settings: Settings,
    pub connection: Connection,
    pub contexts: Vec<String>,
    pub engine: Option<EngineInfo>,
    pub vm: Option<VmStatus>,
    pub vm_busy: bool,
    pub docker: Option<DockerCommand>,
    pub docker_switch_to: Option<String>,
    pub banner_closed: bool,
    pub updates: Option<Updates>,
    pub view: View,
    pub detail: Option<Detail>,
    pub lists: Lists,
    pub list_errors: [Option<String>; 4],
    pub loaded: bool,
    pub live: bool,
    pub features: Features,
    pub busy: HashSet<String>,
    pub search: [Entity<TextInput>; 4],
    pub queries: [String; 4],
    pub scroll: [UniformListScrollHandle; 4],
    pub logs: Option<(u64, Entity<LogView>)>,
    pub kube: Kube,
    pub pull: Pull,
    pub settings_ui: SettingsUi,
    pub sidebar: Sidebar,
    pub modal: Option<Modal>,
    /// The open drop-down menu, by name.
    pub menu: Option<&'static str>,
    pub toasts: Toasts,
    history: Vec<HistoryEntry>,
    history_ix: usize,
    refresh_task: Option<Task<()>>,
    pub bench: Bench,
    _subs: Vec<Subscription>,
}

impl Podbag {
    pub fn new(api: Backend, window: &mut Window, cx: &mut Context<Self>) -> Self {
        let start = Instant::now();
        let settings = api.get_settings();
        let tr = I18n::new(&settings.language);
        let theme = Theme::light();
        let search: [Entity<TextInput>; 4] =
            std::array::from_fn(|_| cx.new(|cx| TextInput::new(cx, "Search")));
        let mut subs = Vec::new();
        for kind in Kind::ALL {
            let input = search[kind_ix(kind)].clone();
            subs.push(
                cx.subscribe(&input, move |this, input, e: &InputEvent, cx| {
                    if *e == InputEvent::Changed {
                        let q = input.read(cx).content.to_string();
                        this.set_query(kind, q, cx);
                    }
                }),
            );
        }
        let kube = Kube::new(cx, &mut subs);
        let pull = Pull::new(window, cx, &mut subs);
        let settings_ui = SettingsUi::new(cx);
        let sidebar = Sidebar {
            width: settings.sidebar_width as f32,
            collapsed: settings.sidebar_collapsed,
            drag: None,
        };
        let connection = api.connection();
        let mut me = Self {
            tr,
            theme,
            focus: cx.focus_handle(),
            settings,
            connection,
            contexts: Vec::new(),
            engine: None,
            vm: None,
            vm_busy: false,
            docker: None,
            docker_switch_to: None,
            banner_closed: false,
            updates: None,
            view: View::Containers,
            detail: None,
            lists: Lists::default(),
            list_errors: Default::default(),
            loaded: false,
            live: false,
            features: Features::default(),
            busy: HashSet::new(),
            search,
            queries: Default::default(),
            scroll: std::array::from_fn(|_| UniformListScrollHandle::new()),
            logs: None,
            kube,
            pull,
            settings_ui,
            sidebar,
            modal: None,
            menu: None,
            toasts: Toasts::default(),
            history: Vec::new(),
            history_ix: 0,
            refresh_task: None,
            bench: Bench::new(start),
            _subs: subs,
            api,
        };
        me.contexts = me.api.contexts();
        me.apply_theme(window);
        me.apply_language(cx);
        me.refresh_kube_counts();
        me.updates = Some(me.api.updates());
        me.connect(false, cx);
        me.remember();
        me.start_vm_poll(cx);
        cx.observe_window_appearance(window, |this, window, cx| {
            this.apply_theme(window);
            cx.notify();
        })
        .detach();
        me
    }

    // ---- text ----

    pub fn t(&self, key: &str) -> SharedString {
        self.tr.t(key).into()
    }

    pub fn tv(&self, key: &str, vars: &[(&str, &dyn std::fmt::Display)]) -> SharedString {
        self.tr.tv(key, vars).into()
    }

    pub fn lang(&self) -> &'static str {
        self.tr.lang()
    }

    pub fn ago(&self, when: i64) -> String {
        if when == 0 {
            return String::new();
        }
        bench_api::fmt::ago(when, self.api.now(), self.lang())
    }

    /// Set the language and the placeholders that come from it.
    pub fn apply_language(&mut self, cx: &mut Context<Self>) {
        self.tr.load(&self.settings.language);
        let placeholder = self.tr.t("search.placeholder");
        for input in self
            .search
            .iter()
            .chain([&self.kube.search, &self.pull.loc_filter])
        {
            input.update(cx, |i, _| i.set_placeholder(&placeholder));
        }
    }

    /// Light, dark, or the system's appearance.
    pub fn apply_theme(&mut self, window: &Window) {
        let dark = match self.settings.theme.as_str() {
            "dark" => true,
            "light" => false,
            _ => matches!(
                window.appearance(),
                WindowAppearance::Dark | WindowAppearance::VibrantDark
            ),
        };
        self.theme = if dark { Theme::dark() } else { Theme::light() };
    }

    pub fn save_settings(&mut self) {
        self.settings.sidebar_width = self.sidebar.width.round() as u32;
        self.settings.sidebar_collapsed = self.sidebar.collapsed;
        if let Err(e) = self.api.set_settings(&self.settings) {
            self.toasts.push(e, true);
        }
    }

    // ---- toasts ----

    pub fn toast(&mut self, text: impl Into<SharedString>, error: bool, cx: &mut Context<Self>) {
        let stay = self.toasts.push(text, error);
        cx.spawn(async move |this, cx| {
            cx.background_executor()
                .timer(stay + Duration::from_millis(20))
                .await;
            let _ = this.update(cx, |this, cx| {
                if this.toasts.expire() {
                    cx.notify();
                }
            });
        })
        .detach();
        cx.notify();
    }

    // ---- engine and data ----

    pub fn is_podbag(&self) -> bool {
        self.engine.as_ref().is_none_or(|e| e.engine == "podbag")
    }

    pub fn has_vm(&self) -> bool {
        self.is_podbag() && self.engine.as_ref().is_some_and(|e| e.platform != "linux")
    }

    pub fn reachable(&self) -> bool {
        self.engine.as_ref().is_some_and(|e| e.reachable)
    }

    /// app.js `connect`.
    pub fn connect(&mut self, start_vm: bool, cx: &mut Context<Self>) {
        self.engine = Some(self.api.engine(start_vm));
        self.refresh_vm(cx);
        self.docker = self.api.docker_command();
        if self.reachable() {
            self.refresh(cx);
            self.api.watch(true);
        } else {
            self.loaded = false;
        }
        cx.notify();
    }

    /// app.js `refreshVm`: true if it changed.
    pub fn refresh_vm(&mut self, cx: &mut Context<Self>) -> bool {
        let vm = if self.has_vm() {
            self.api.vm_status()
        } else {
            None
        };
        if vm == self.vm {
            return false;
        }
        self.vm = vm;
        self.fill_vm_form(false, cx);
        true
    }

    fn start_vm_poll(&mut self, cx: &mut Context<Self>) {
        cx.spawn(async move |this, cx| {
            loop {
                cx.background_executor().timer(Duration::from_secs(5)).await;
                let ok = this.update(cx, |this, cx| {
                    if this.has_vm() && this.refresh_vm(cx) {
                        cx.notify();
                    }
                });
                if ok.is_err() {
                    break;
                }
            }
        })
        .detach();
    }

    /// app.js `refresh`: read the four lists.
    pub fn refresh(&mut self, cx: &mut Context<Self>) {
        let mut any = false;
        macro_rules! load {
            ($kind:expr, $field:ident, $call:ident) => {
                match self.api.$call() {
                    Ok(v) => {
                        self.lists.$field = v;
                        self.list_errors[kind_ix($kind)] = None;
                        any = true;
                    }
                    Err(e) => {
                        self.lists.$field = Vec::new();
                        self.list_errors[kind_ix($kind)] = Some(e);
                    }
                }
            };
        }
        load!(Kind::Containers, containers, containers);
        load!(Kind::Images, images, images);
        load!(Kind::Volumes, volumes, volumes);
        load!(Kind::Networks, networks, networks);
        for kind in Kind::ALL {
            self.lists.build_hay(kind);
            self.lists.filter(kind, &self.queries[kind_ix(kind)]);
        }
        self.loaded = any;
        if !any {
            if let Some(e) = &mut self.engine {
                e.reachable = false;
                e.error = self.list_errors[0].clone();
            }
        }
        if self.loaded && self.features == Features::default() && self.list_errors[0].is_none() {
            let sample = self
                .lists
                .containers
                .iter()
                .find(|c| c.state == "running")
                .map(|c| c.id.clone());
            self.features = self.api.features(sample.as_deref());
        }
        if let Some(d) = &self.detail {
            if self.lists.find(d.kind, &d.id).is_none() {
                self.close_detail(true, cx);
            }
        }
        cx.notify();
    }

    /// app.js `refreshSoon`: refresh after 200 ms, once.
    pub fn refresh_soon(&mut self, cx: &mut Context<Self>) {
        self.refresh_task = Some(cx.spawn(async move |this, cx| {
            cx.background_executor()
                .timer(Duration::from_millis(200))
                .await;
            let _ = this.update(cx, |this, cx| this.refresh(cx));
        }));
    }

    pub fn set_query(&mut self, kind: Kind, q: String, cx: &mut Context<Self>) {
        let ix = kind_ix(kind);
        if self.queries[ix] == q {
            return;
        }
        let start = self
            .bench
            .filter_started
            .take()
            .unwrap_or_else(Instant::now);
        self.lists.filter(kind, &q);
        self.queries[ix] = q;
        if kind == Kind::Containers {
            self.bench.pending.push(Pending::Filter(start));
        }
        cx.notify();
    }

    // ---- actions ----

    /// app.js `act`.
    pub fn act(&mut self, id: String, action: &'static str, cx: &mut Context<Self>) {
        let name = self
            .lists
            .find(Kind::Containers, &id)
            .map(|i| self.lists.containers[i].name().to_string())
            .unwrap_or_default();
        self.busy.insert(id.clone());
        match self.api.act(&id, action) {
            Ok(()) => {
                let msg = self.tv(&format!("done.{action}"), &[("name", &name)]);
                self.toast(msg, false, cx);
            }
            Err(e) => self.toast(e, true, cx),
        }
        self.busy.remove(&id);
        self.refresh_soon(cx);
        cx.notify();
    }

    /// app.js `remove`: confirm, then remove.
    pub fn remove(&mut self, kind: Kind, id: String, cx: &mut Context<Self>) {
        let Some(i) = self.lists.find(kind, &id) else {
            return;
        };
        let name = self.lists.name(kind, i).to_string();
        let running = kind == Kind::Containers && self.lists.containers[i].is_up();
        let key = match kind {
            Kind::Containers if running => "confirm.removeRunning",
            Kind::Containers => "confirm.removeContainer",
            Kind::Images => "confirm.removeImage",
            Kind::Volumes => "confirm.removeVolume",
            Kind::Networks => "confirm.removeNetwork",
        };
        let text = self.tv(key, &[("name", &name)]);
        self.confirm(text, None, Tone::Danger, cx, move |this, _, cx| {
            this.busy.insert(id.clone());
            match this.api.remove(kind, &id, running) {
                Ok(()) => {
                    let msg = this.tv("done.remove", &[("name", &name)]);
                    this.toast(msg, false, cx);
                    if this.detail.as_ref().is_some_and(|d| d.id == id) {
                        this.close_detail(false, cx);
                    }
                }
                Err(e) => this.toast(e, true, cx),
            }
            this.busy.remove(&id);
            this.refresh_soon(cx);
        });
    }

    /// app.js `prune`.
    pub fn prune(&mut self, kind: Kind, cx: &mut Context<Self>) {
        let key = match kind {
            Kind::Containers => "confirm.pruneContainers",
            Kind::Images => "confirm.pruneImages",
            Kind::Volumes => "confirm.pruneVolumes",
            Kind::Networks => "confirm.pruneNetworks",
        };
        let text = self.t(key);
        let yes = self.t("action.prune");
        self.confirm(text, Some(yes), Tone::Danger, cx, move |this, _, cx| {
            match this.api.prune(kind) {
                Ok(p) => {
                    let size = bench_api::fmt::size(p.bytes, this.lang());
                    let msg = this.tv("done.prune", &[("n", &p.count), ("size", &size)]);
                    this.toast(msg, false, cx);
                }
                Err(e) => this.toast(e, true, cx),
            }
            this.refresh_soon(cx);
        });
    }

    /// app.js `shell`: open a terminal in the container, or show the command.
    pub fn shell(&mut self, id: String, cx: &mut Context<Self>) {
        if let Err(command) = self.api.open_shell(&id) {
            let text: SharedString = format!("{}\n\n{command}", self.t("shell.manual")).into();
            self.modal = Some(Modal::Confirm {
                title: self.t("action.shell"),
                text,
                yes: self.t("action.copy"),
                cancel: self.t("action.back"),
                tone: Tone::Danger,
                on_yes: Some(Box::new(move |this, _, cx| {
                    cx.write_to_clipboard(gpui::ClipboardItem::new_string(command));
                    let msg = this.t("action.copied");
                    this.toast(msg, false, cx);
                })),
            });
            cx.notify();
        }
    }

    pub fn open_terminal(&mut self, cx: &mut Context<Self>) {
        if self.api.open_terminal("plain").is_err() {
            let msg = self.t("terminal.none");
            self.toast(msg, true, cx);
        }
    }

    // ---- dialogs ----

    /// app.js `confirmDialog`. `yes`: the button text (Remove by default).
    pub fn confirm(
        &mut self,
        text: SharedString,
        yes: Option<SharedString>,
        tone: Tone,
        cx: &mut Context<Self>,
        on_yes: impl FnOnce(&mut Podbag, &mut Window, &mut Context<Podbag>) + 'static,
    ) {
        self.modal = Some(Modal::Confirm {
            title: self.t("confirm.title"),
            text,
            yes: yes.unwrap_or_else(|| self.t("action.remove")),
            cancel: self.t("action.cancel"),
            tone,
            on_yes: Some(Box::new(on_yes)),
        });
        cx.notify();
    }

    /// app.js `askDialog`: one line of text, then `work` while the dialog stays open.
    pub fn ask(
        &mut self,
        title: SharedString,
        label: SharedString,
        value: &str,
        placeholder: &str,
        ok: SharedString,
        window: &mut Window,
        cx: &mut Context<Self>,
        work: AskWork,
    ) {
        let input = cx.new(|cx| TextInput::new(cx, placeholder));
        input.update(cx, |i, cx| {
            i.accent = self.theme.accent;
            i.set_content(value, cx);
            i.select_all_text(cx);
        });
        let sub = cx.subscribe_in(&input, window, |this, _, e: &InputEvent, window, cx| {
            if *e == InputEvent::Submit {
                this.submit_ask(window, cx);
            }
        });
        window.focus(&input.read(cx).focus_handle(cx));
        self.modal = Some(Modal::Ask {
            title,
            label,
            ok,
            input,
            progress: "".into(),
            work,
            _sub: sub,
        });
        cx.notify();
    }

    pub fn submit_ask(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let Some(Modal::Ask { input, work, .. }) = &self.modal else {
            return;
        };
        let text = input.read(cx).content.trim().to_string();
        if text.is_empty() {
            return;
        }
        let work = work.clone();
        match work(self, text, window, cx) {
            Ok(()) => self.close_modal(window, cx),
            Err(e) => {
                if let Some(Modal::Ask { progress, .. }) = &mut self.modal {
                    *progress = e.into();
                }
            }
        }
        cx.notify();
    }

    /// app.js `chooseDialog`: several answers; `on` gets the chosen value.
    pub fn choose(
        &mut self,
        title: SharedString,
        text: SharedString,
        buttons: Vec<(SharedString, SharedString, Tone)>,
        cx: &mut Context<Self>,
        on: impl FnOnce(&mut Podbag, &str, &mut Window, &mut Context<Podbag>) + 'static,
    ) {
        self.modal = Some(Modal::Choose {
            title,
            text,
            buttons,
            on: Some(Box::new(on)),
        });
        cx.notify();
    }

    pub fn close_modal(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if matches!(self.modal, Some(Modal::Pull)) {
            self.pull.close();
        }
        self.modal = None;
        self.menu = None;
        window.focus(&self.focus);
        cx.notify();
    }

    /// The answer of a Confirm or Choose dialog.
    pub fn answer(&mut self, value: &str, window: &mut Window, cx: &mut Context<Self>) {
        match self.modal.take() {
            Some(Modal::Confirm {
                on_yes: Some(f), ..
            }) if value == "yes" => f(self, window, cx),
            Some(Modal::Choose { on: Some(f), .. }) => f(self, value, window, cx),
            _ => {}
        }
        if self.modal.is_none() {
            window.focus(&self.focus);
        }
        cx.notify();
    }

    // ---- navigation ----

    /// app.js `go`.
    pub fn go(&mut self, view: View, window: &mut Window, cx: &mut Context<Self>) {
        if self.detail.is_some() {
            self.close_detail(true, cx);
        }
        self.menu = None;
        if view == View::Kubernetes {
            self.kube.expanded = true;
            if self.view == view {
                return;
            }
        }
        let was = self.view;
        self.view = view;
        if view != was {
            self.shown(window, cx);
        }
        self.remember();
        cx.notify();
    }

    /// Kubernetes with a resource (the sidebar's sub-items).
    pub fn go_kube(&mut self, kind: KubeKind, window: &mut Window, cx: &mut Context<Self>) {
        let changed = kind != self.kube.kind;
        self.kube.kind = kind;
        if self.view == View::Kubernetes && self.detail.is_none() {
            self.kube.expanded = true;
            if changed {
                self.kube_switch(cx);
                self.remember();
            }
            cx.notify();
            return;
        }
        self.go(View::Kubernetes, window, cx);
    }

    /// Work when a page appears.
    fn shown(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let _ = window;
        match self.view {
            View::Kubernetes => self.kube_reload(cx),
            View::Settings => self.settings_shown(cx),
            _ => {}
        }
    }

    /// app.js `openDetail`.
    pub fn open_detail(
        &mut self,
        kind: Kind,
        id: String,
        tab: DetailTab,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.close_detail(true, cx);
        self.view = View::of(kind);
        self.detail = Some(Detail {
            kind,
            id,
            tab: DetailTab::Info,
            inspect: None,
            extra: Vec::new(),
        });
        self.set_tab(tab, window, cx);
        self.remember();
        cx.notify();
    }

    /// Switch the detail's tab, starting or stopping what the tab needs.
    pub fn set_tab(&mut self, tab: DetailTab, _window: &mut Window, cx: &mut Context<Self>) {
        let Some(d) = &mut self.detail else { return };
        if d.tab == DetailTab::Logs && tab != DetailTab::Logs {
            self.api.logs_stop();
            self.logs = None;
        }
        d.tab = tab;
        let (kind, id) = (d.kind, d.id.clone());
        match tab {
            DetailTab::Inspect => {
                let text = match self.api.inspect(kind, &id) {
                    Ok(v) => pretty_json(&v),
                    Err(e) => e,
                };
                if let Some(d) = &mut self.detail {
                    d.inspect = Some(text.into());
                }
            }
            DetailTab::Logs => {
                let mut view = LogView::new(self.theme);
                view.empty_text = self.t("detail.noLogs");
                let entity = cx.new(|_| view);
                let generation = self.api.logs_start(&id);
                self.logs = Some((generation, entity));
            }
            DetailTab::Info => self.load_extra(cx),
        }
        cx.notify();
    }

    /// app.js `closeDetail`. quiet: another page comes next.
    pub fn close_detail(&mut self, quiet: bool, cx: &mut Context<Self>) {
        if self
            .detail
            .as_ref()
            .is_some_and(|d| d.tab == DetailTab::Logs)
        {
            self.api.logs_stop();
        }
        self.logs = None;
        self.detail = None;
        if !quiet {
            self.remember();
            cx.notify();
        }
    }

    fn entry(&self) -> HistoryEntry {
        HistoryEntry {
            view: self.view,
            detail: self.detail.as_ref().map(|d| (d.kind, d.id.clone(), d.tab)),
            kube: (self.view == View::Kubernetes).then_some(self.kube.kind),
        }
    }

    /// app.js `remember`.
    pub fn remember(&mut self) {
        let entry = self.entry();
        if self.history.get(self.history_ix) == Some(&entry) {
            return;
        }
        if !self.history.is_empty() {
            self.history.truncate(self.history_ix + 1);
        }
        self.history.push(entry);
        if self.history.len() > 50 {
            self.history.remove(0);
        }
        self.history_ix = self.history.len() - 1;
    }

    pub fn can_travel(&self, step: isize) -> bool {
        let ix = self.history_ix as isize + step;
        ix >= 0 && (ix as usize) < self.history.len()
    }

    /// app.js `travel`: back (-1) or forward (1).
    pub fn travel(&mut self, step: isize, window: &mut Window, cx: &mut Context<Self>) {
        if !self.can_travel(step) {
            return;
        }
        self.history_ix = (self.history_ix as isize + step) as usize;
        let entry = self.history[self.history_ix].clone();
        self.close_detail(true, cx);
        let was = self.view;
        self.view = entry.view;
        if let Some(k) = entry.kube {
            self.kube.expanded = true;
            if k != self.kube.kind {
                self.kube.kind = k;
                if was == View::Kubernetes {
                    self.kube_switch(cx);
                }
            }
        }
        if was != self.view {
            self.shown(window, cx);
        }
        if let Some((kind, id, tab)) = entry.detail {
            self.detail = Some(Detail {
                kind,
                id,
                tab: DetailTab::Info,
                inspect: None,
                extra: Vec::new(),
            });
            self.set_tab(tab, window, cx);
        }
        cx.notify();
    }

    // ---- the sidebar ----

    pub fn sidebar_width(&self) -> f32 {
        match self.sidebar.drag {
            Some((_, _, w)) => w,
            None if self.sidebar.collapsed => SIDEBAR_RAIL,
            None => self.sidebar.width.clamp(SIDEBAR_MIN, SIDEBAR_MAX),
        }
    }

    pub fn toggle_sidebar(&mut self, cx: &mut Context<Self>) {
        self.sidebar.collapsed = !self.sidebar.collapsed;
        self.save_settings();
        cx.notify();
    }

    /// The divider moved to x (while dragging).
    pub fn drag_sidebar(&mut self, x: f32, cx: &mut Context<Self>) {
        let Some((x0, w0, _)) = self.sidebar.drag else {
            return;
        };
        let w = w0 + (x - x0);
        let threshold = if w0 == SIDEBAR_RAIL { 80. } else { 128. };
        let w = if w <= threshold {
            SIDEBAR_RAIL
        } else {
            w.clamp(SIDEBAR_MIN, SIDEBAR_MAX)
        };
        self.sidebar.drag = Some((x0, w0, w));
        cx.notify();
    }

    pub fn end_drag(&mut self, cx: &mut Context<Self>) {
        let Some((_, w0, w)) = self.sidebar.drag.take() else {
            return;
        };
        if w != w0 {
            self.sidebar.collapsed = w == SIDEBAR_RAIL;
            if !self.sidebar.collapsed {
                self.sidebar.width = w;
            }
            self.save_settings();
        }
        cx.notify();
    }

    // ---- the VM ----

    /// app.js `vmAction`: start, stop or restart, with a confirm when containers run.
    pub fn vm_action(&mut self, action: &'static str, cx: &mut Context<Self>) {
        let n = self.vm.as_ref().and_then(|v| v.containers).unwrap_or(0);
        if (action == "stop" || action == "restart") && n > 0 {
            let (key, yes) = if action == "stop" {
                ("confirm.stopVm", "action.stopVm")
            } else {
                ("confirm.restartVm", "action.restartVm")
            };
            let text = self.tv(key, &[("n", &n)]);
            let yes = self.t(yes);
            self.confirm(text, Some(yes), Tone::Danger, cx, move |this, _, cx| {
                this.run_vm_action(action, cx)
            });
            return;
        }
        self.run_vm_action(action, cx);
    }

    fn run_vm_action(&mut self, action: &str, cx: &mut Context<Self>) {
        self.vm_busy = true;
        if let Err(e) = self.api.vm(action) {
            self.toast(e, true, cx);
        }
        self.vm_busy = false;
        self.refresh_vm(cx);
        cx.notify();
    }

    // ---- backend events ----

    pub fn on_event(&mut self, event: Event, window: &mut Window, cx: &mut Context<Self>) {
        match event {
            Event::Changed => self.refresh_soon(cx),
            Event::Live(on) => {
                self.live = on;
                cx.notify();
            }
            Event::Logs { generation, lines } => {
                if let Some((g, view)) = &self.logs {
                    if *g == generation {
                        view.update(cx, |v, cx| v.push(lines, cx));
                    }
                }
            }
            Event::PullProgress(line) => self.pull_line(line, cx),
            Event::PullDone(result) => self.pull_done(result, cx),
            Event::EngineChanged(_) => self.connect(false, cx),
            Event::VmStatus(state) => {
                if let Some(e) = &mut self.engine {
                    e.vm = Some(state);
                }
                self.connect(false, cx);
            }
            Event::DockerSwitching(to) => {
                self.docker_switch_to = Some(to);
                cx.notify();
            }
            Event::DockerChanged(d) => self.docker_changed(d, cx),
        }
        let _ = window;
    }

    fn docker_changed(&mut self, d: DockerCommand, cx: &mut Context<Self>) {
        self.docker_switch_to = None;
        let msg = if !d.installed {
            (self.t("docker.missing"), true)
        } else if d.is_podbag {
            (self.t("docker.nowPodbag"), false)
        } else {
            (self.tv("docker.nowOther", &[("name", &d.name)]), false)
        };
        self.docker = Some(d);
        self.toast(msg.0, msg.1, cx);
    }

    // ---- benchmark hooks ----

    /// A line of stdin: `filter <text>`, `nav <view>`, `quit`.
    pub fn command(&mut self, line: &str, window: &mut Window, cx: &mut Context<Self>) {
        let line = line.trim();
        if line == "quit" {
            cx.quit();
        } else if let Some(q) = line.strip_prefix("filter ") {
            self.bench.filter_started = Some(Instant::now());
            let q = q.to_string();
            if self.view != View::Containers || self.detail.is_some() {
                self.go(View::Containers, window, cx);
            }
            self.search[0].update(cx, |s, cx| s.set_content(&q, cx));
        } else if let Some(rest) = line.strip_prefix("do ") {
            self.test_command(rest, window, cx);
        } else if let Some(name) = line.strip_prefix("nav ") {
            let name = name.trim();
            match View::parse(name) {
                Some(view) => {
                    let start = Instant::now();
                    self.modal = None;
                    self.go(view, window, cx);
                    self.bench
                        .pending
                        .push(Pending::View(name.to_string(), start));
                    cx.notify();
                }
                None => eprintln!("nav: unknown view {name}"),
            }
        }
    }

    // ---- keys ----

    pub fn on_escape(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.menu.is_some() {
            self.menu = None;
            cx.notify();
        } else if matches!(self.modal, Some(Modal::Pull)) {
            self.pull_escape(window, cx);
        } else if self.modal.is_some() {
            self.close_modal(window, cx);
        } else if self.detail.is_some() {
            self.close_detail(false, cx);
        }
    }

    pub fn focus_search(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let input = match (self.view.kind(), self.detail.is_some()) {
            (Some(kind), false) => self.search[kind_ix(kind)].clone(),
            _ if self.view == View::Kubernetes => self.kube.search.clone(),
            _ => return,
        };
        window.focus(&input.read(cx).focus_handle(cx));
    }
}

impl Focusable for Podbag {
    fn focus_handle(&self, _: &App) -> FocusHandle {
        self.focus.clone()
    }
}
