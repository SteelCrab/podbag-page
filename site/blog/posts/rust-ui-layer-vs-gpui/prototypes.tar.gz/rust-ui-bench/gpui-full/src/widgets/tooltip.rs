//! A small tooltip (the web app uses the browser's `title`).

use gpui::{AnyView, App, Context, SharedString, Window, div, prelude::*, px};

use crate::theme::Theme;

pub struct Tooltip {
    text: SharedString,
    t: Theme,
}

impl Tooltip {
    pub fn view(text: SharedString, t: &Theme, cx: &mut App) -> AnyView {
        cx.new(|_| Tooltip { text, t: *t }).into()
    }
}

impl Render for Tooltip {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let t = self.t;
        div().pl(px(8.)).pt(px(10.)).child(
            div()
                .px(px(8.))
                .py(px(4.))
                .rounded(px(6.))
                .bg(t.ink)
                .text_color(t.page)
                .text_size(px(12.))
                .shadow_md()
                .child(self.text.clone()),
        )
    }
}
