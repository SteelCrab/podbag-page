//! Settings (app.js): launch at login, language (switches the UI live), theme, the
//! engine choice with the docker command, the VM's state and resources, and About.
//! Updates and the terminal command are out of scope.

use std::collections::HashSet;

use bench_api::{VmChange, VmStatus};
use gpui::{
    AnyElement, Context, Div, Entity, FontWeight, SharedString, Window, div, prelude::*, px,
};

use crate::app::*;
use crate::icons::icon;
use crate::shell::vm_state_key;
use crate::theme::setting_color;
use crate::views::resources::{heading, toolbar};
use crate::widgets::fields::Fields;
use crate::widgets::segmented::Segmented;
use crate::widgets::select::Select;
use crate::widgets::slider::Slider;
use crate::widgets::{Button, Checkbox, IconButton, TextInput, Tone};

pub struct VmForm {
    pub cpus: Entity<TextInput>,
    pub memory: Entity<TextInput>,
    pub idle: Entity<TextInput>,
    /// The values last put in (the form is "dirty" when they differ).
    pub filled: [String; 3],
    pub error: SharedString,
}

pub struct SettingsUi {
    /// Open `details` sections, by id.
    pub open: HashSet<&'static str>,
    pub form: VmForm,
    /// Launch at login; None while unknown.
    pub launch: Option<bool>,
    pub language_names: Vec<(&'static str, String)>,
}

impl SettingsUi {
    pub fn new(cx: &mut Context<Podbag>) -> Self {
        let input = |cx: &mut Context<Podbag>| cx.new(|cx| TextInput::new(cx, ""));
        SettingsUi {
            open: HashSet::new(),
            form: VmForm {
                cpus: input(cx),
                memory: input(cx),
                idle: input(cx),
                filled: Default::default(),
                error: "".into(),
            },
            launch: None,
            language_names: bench_api::i18n::names(),
        }
    }
}

/// A number as the form shows it: 6 → "6", 5.5 → "5.5".
fn num(v: f64) -> String {
    let s = format!("{v:.2}");
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}

impl Podbag {
    pub fn settings_shown(&mut self, cx: &mut Context<Self>) {
        self.settings_ui.launch = self.api.launch_at_login().ok();
        self.contexts = self.api.contexts();
        self.refresh_vm(cx);
        self.fill_vm_form(true, cx);
    }

    fn form_values(&self, cx: &Context<Self>) -> [String; 3] {
        let f = &self.settings_ui.form;
        [
            f.cpus.read(cx).content.to_string(),
            f.memory.read(cx).content.to_string(),
            f.idle.read(cx).content.to_string(),
        ]
    }

    /// app.js `fillVmForm`; without `force` only when the user has not typed.
    pub fn fill_vm_form(&mut self, force: bool, cx: &mut Context<Self>) {
        let Some(vm) = &self.vm else { return };
        if !force && self.form_values(cx) != self.settings_ui.form.filled {
            return;
        }
        let next = vm.next;
        let values = [
            next.cpus.map(|c| c.to_string()).unwrap_or_default(),
            next.memory_mib
                .map(|m| num(m as f64 / 1024.))
                .unwrap_or_default(),
            next.idle_seconds
                .map(|s| ((s as f64) / 60.).round().to_string())
                .unwrap_or_default(),
        ];
        let accent = self.theme.accent;
        let f = &mut self.settings_ui.form;
        for (input, v) in [&f.cpus, &f.memory, &f.idle].into_iter().zip(&values) {
            input.update(cx, |i, cx| {
                i.accent = accent;
                i.set_content(v, cx);
            });
        }
        f.filled = values;
    }

    /// app.js `switchEngine`: save the choice and connect again.
    pub fn switch_engine(&mut self, name: String, _window: &mut Window, cx: &mut Context<Self>) {
        if self.connection.name == name {
            return;
        }
        if let Err(e) = self.api.set_engine(&name) {
            self.toast(e, true, cx);
            return;
        }
        self.connection = self.api.connection();
        self.features = Default::default();
        self.close_detail(true, cx);
        self.connect(false, cx);
    }

    fn set_language(&mut self, lang: String, cx: &mut Context<Self>) {
        self.settings.language = lang;
        self.save_settings();
        self.apply_language(cx);
        self.update_vm_placeholders(cx);
        cx.notify();
    }

    fn update_vm_placeholders(&mut self, _cx: &mut Context<Self>) {}

    /// app.js `applyVm`: check the values, ask when the VM runs, then save.
    fn apply_vm(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let Some(vm) = self.vm.clone() else { return };
        let l = vm.limits;
        let [cpus_s, mem_s, idle_s] = self.form_values(cx);
        let bad = |label: &str, min: String, max: String| {
            format!(
                "{label}: {}",
                self.tr
                    .tv("settings.limits", &[("min", &min), ("max", &max)])
            )
        };
        let cpus = match cpus_s.trim().parse::<u32>() {
            Ok(c) if c >= l.cpus_min && c <= l.cpus_max => c,
            _ => {
                return self.vm_error(
                    bad(
                        &self.tr.t("settings.cpus"),
                        l.cpus_min.to_string(),
                        l.cpus_max.to_string(),
                    ),
                    cx,
                );
            }
        };
        let mem = match mem_s.trim().replace(',', ".").parse::<f64>() {
            Ok(m)
                if m * 1024. >= l.memory_min_mib as f64
                    && m * 1024. <= l.memory_max_mib as f64
                    && (m * 4.).fract() == 0. =>
            {
                (m * 1024.).round() as u32
            }
            _ => {
                return self.vm_error(
                    bad(
                        &self.tr.t("settings.memory"),
                        num(l.memory_min_mib as f64 / 1024.),
                        num(l.memory_max_mib as f64 / 1024.),
                    ),
                    cx,
                );
            }
        };
        let idle = match idle_s.trim().parse::<u32>() {
            Ok(i) if i <= 1440 => i * 60,
            _ => {
                return self.vm_error(
                    bad(&self.tr.t("settings.idle"), "0".into(), "1440".into()),
                    cx,
                );
            }
        };
        self.settings_ui.form.error = "".into();
        let next = vm.next;
        let mut change = VmChange {
            cpus: (Some(cpus) != next.cpus).then_some(cpus),
            memory_mib: (Some(mem) != next.memory_mib).then_some(mem),
            idle_seconds: (Some(idle) != next.idle_seconds).then_some(idle),
            restart: false,
        };
        let none =
            change.cpus.is_none() && change.memory_mib.is_none() && change.idle_seconds.is_none();
        if none && !vm.pending {
            let msg = self.t("settings.vmSame");
            self.toast(msg, false, cx);
            return;
        }
        if none {
            change.cpus = Some(cpus);
        }
        let in_use = vm.in_use.unwrap_or(vm.next);
        let differs = Some(cpus) != in_use.cpus
            || Some(mem) != in_use.memory_mib
            || Some(idle) != in_use.idle_seconds;
        if vm.state == "running" && differs {
            let n = vm.containers.unwrap_or(0);
            let text: SharedString = if n > 0 {
                format!(
                    "{}\n\n{}",
                    self.tr.t("settings.vmApplyText"),
                    self.tr.tv("settings.vmApplyWarn", &[("n", &n)])
                )
                .into()
            } else {
                self.t("settings.vmApplyText")
            };
            let buttons = vec![
                ("".into(), self.t("action.cancel"), Tone::Normal),
                ("later".into(), self.t("settings.nextStart"), Tone::Normal),
                (
                    "now".into(),
                    self.t("settings.restartNow"),
                    if n > 0 { Tone::Danger } else { Tone::Primary },
                ),
            ];
            self.choose(
                self.t("settings.vmApplyTitle"),
                text,
                buttons,
                cx,
                move |this, answer, _, cx| {
                    if !answer.is_empty() {
                        this.save_vm(
                            VmChange {
                                restart: answer == "now",
                                ..change
                            },
                            cx,
                        );
                    }
                },
            );
            return;
        }
        let _ = window;
        self.save_vm(change, cx);
    }

    fn vm_error(&mut self, e: String, cx: &mut Context<Self>) {
        self.settings_ui.form.error = e.into();
        cx.notify();
    }

    fn save_vm(&mut self, change: VmChange, cx: &mut Context<Self>) {
        match self.api.vm_set(change) {
            Ok(_) => {
                let msg = self.t(if change.restart {
                    "settings.vmRestarted"
                } else {
                    "settings.vmSaved"
                });
                self.toast(msg, false, cx);
                self.refresh_vm(cx);
                self.fill_vm_form(true, cx);
            }
            Err(e) => self.settings_ui.form.error = e.into(),
        }
        cx.notify();
    }

    fn setting_title(&self, key: &str, symbol: &'static str) -> Div {
        div()
            .flex()
            .items_center()
            .gap(px(12.))
            .font_weight(FontWeight::SEMIBOLD)
            .child(
                div()
                    .flex()
                    .flex_none()
                    .items_center()
                    .justify_center()
                    .size(px(32.))
                    .rounded(px(8.))
                    .bg(setting_color(key))
                    .child(icon(symbol, px(20.), gpui::white())),
            )
            .child(self.t(&format!("settings.{key}")))
    }

    /// A `details` section: a summary row that opens a body.
    fn section(
        &self,
        id: &'static str,
        key: &str,
        symbol: &'static str,
        value: Option<SharedString>,
        body: Option<AnyElement>,
        cx: &mut Context<Self>,
    ) -> Div {
        let t = self.theme;
        let open = self.settings_ui.open.contains(id);
        div()
            .border_t_1()
            .border_color(t.line)
            .child(
                div()
                    .id(id)
                    .flex()
                    .items_center()
                    .gap(px(12.))
                    .min_h(px(61.))
                    .py(px(10.))
                    .rounded(px(6.))
                    .cursor_pointer()
                    .hover(move |s| s.bg(t.hover))
                    .child(self.setting_title(key, symbol))
                    .child(
                        div()
                            .ml_auto()
                            .text_size(px(13.))
                            .text_color(t.ink2)
                            .children(value),
                    )
                    .child(icon("forward", px(14.), t.muted).with_transformation(
                        gpui::Transformation::rotate(gpui::radians(if open {
                            std::f32::consts::FRAC_PI_2
                        } else {
                            0.
                        })),
                    ))
                    .on_click(cx.listener(move |this, _, _, cx| {
                        if !this.settings_ui.open.remove(id) {
                            this.settings_ui.open.insert(id);
                        }
                        cx.notify();
                    })),
            )
            .when(open, |d| {
                d.children(body.map(|b| div().pl(px(44.)).pb(px(18.)).child(b)))
            })
    }

    pub fn render_settings(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let card = || {
            div()
                .w_full()
                .max_w(px(780.))
                .px(px(16.))
                .bg(t.surface)
                .border_1()
                .border_color(t.line)
                .rounded(px(10.))
        };
        let pref = || {
            div()
                .flex()
                .flex_wrap()
                .items_center()
                .justify_between()
                .gap(px(12.))
                .min_h(px(61.))
                .py(px(10.))
        };
        // Startup.
        let launch = self.settings_ui.launch;
        let startup = pref().child(self.setting_title("startup", "power")).child(
            Checkbox::new("launch-at-login", launch.unwrap_or(false), &t)
                .indeterminate(launch.is_none())
                .disabled(launch.is_none())
                .label(self.t("settings.launchAtLogin"))
                .on_toggle(cx.listener(|this, on: &bool, _, cx| {
                    if let Err(e) = this.api.set_launch_at_login(*on) {
                        this.toast(e, true, cx);
                    }
                    this.settings_ui.launch = this.api.launch_at_login().ok();
                    cx.notify();
                })),
        );
        // Language: each language in its own name.
        let mut lang = Select::new(
            "language",
            self.settings.language.clone(),
            self.menu == Some("language"),
            &t,
        )
        .width(190.)
        .option("system", self.t("settings.system"));
        for (code, name) in &self.settings_ui.language_names {
            lang = lang.option(*code, name.clone());
        }
        let lang = lang
            .on_toggle(cx.listener(|this, open: &bool, _, cx| {
                this.menu = open.then_some("language");
                cx.notify();
            }))
            .on_pick(
                cx.listener(|this, v: &SharedString, _, cx| this.set_language(v.to_string(), cx)),
            );
        let language = pref()
            .border_t_1()
            .border_color(t.line)
            .child(self.setting_title("language", "globe"))
            .child(lang);
        // Theme.
        let themes = ["system", "light", "dark"];
        let selected = themes
            .iter()
            .position(|v| *v == self.settings.theme)
            .unwrap_or(0);
        let theme = pref()
            .border_t_1()
            .border_color(t.line)
            .child(self.setting_title("theme", "appearance"))
            .child(
                Segmented::new("theme", selected, &t)
                    .option("display", self.t("settings.system"))
                    .option("sun", self.t("settings.light"))
                    .option("moon", self.t("settings.dark"))
                    .on_select(cx.listener(move |this, i: &usize, w, cx| {
                        this.settings.theme = themes[*i].into();
                        this.apply_theme(w);
                        this.save_settings();
                        cx.notify();
                    })),
            );
        let e = self.engine.clone();
        let engine_name = e
            .as_ref()
            .map(|e| SharedString::from(e.engine_name.clone()));
        let engine_body = self.engine_body(cx);
        let vm = self.vm.clone().filter(|_| self.has_vm());
        let vm_section = vm.as_ref().map(|vm| {
            let value = self.t(&format!("vm.state.{}", vm_state_key(&vm.state)));
            let body = self.vm_body(vm, cx);
            self.section("vm-settings", "vm", "vm", Some(value), Some(body), cx)
        });
        let about = self.section(
            "about-settings",
            "about",
            "inspect",
            None,
            Some(
                div()
                    .text_color(t.ink2)
                    .child(self.t("settings.aboutText"))
                    .into_any_element(),
            ),
            cx,
        );
        let engine = self
            .section(
                "engine-settings",
                "engine",
                "engine",
                engine_name,
                Some(engine_body),
                cx,
            )
            .border_t_0();
        div()
            .flex()
            .flex_col()
            .size_full()
            .child(toolbar(&t).child(heading(self.t("settings.title"))))
            .child(
                div()
                    .id("settings")
                    .flex_1()
                    .min_h_0()
                    .overflow_y_scroll()
                    .flex()
                    .flex_col()
                    .gap(px(18.))
                    .px(px(20.))
                    .pt(px(20.))
                    .pb(px(24.))
                    .child(card().child(startup).child(language).child(theme))
                    .child(card().child(engine).children(vm_section).child(about)),
            )
            .into_any_element()
    }

    fn engine_body(&self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let name = self.connection.name.clone();
        let mut select = Select::new(
            "engine-picker",
            name.clone(),
            self.menu == Some("engine-picker"),
            &t,
        )
        .width(260.)
        .option("podbag", "podbag")
        .option("docker", "Docker")
        .option("podman", "Podman")
        .option("kiri", "Kiri");
        if !self.contexts.is_empty() {
            select = select.group(self.t("engine.contexts"));
            for c in &self.contexts {
                select = select.option(format!("context:{c}"), c.clone());
            }
        }
        let known = ["podbag", "docker", "podman", "kiri"].contains(&name.as_str())
            || self.contexts.iter().any(|c| format!("context:{c}") == name);
        if !known {
            select = select.option(name.clone(), name.clone());
        }
        if !cfg!(target_os = "windows")
            && self.engine.as_ref().is_none_or(|e| e.platform != "windows")
        {
            select = select.option("custom", self.t("engine.socket"));
        }
        let select = select
            .on_toggle(cx.listener(|this, open: &bool, _, cx| {
                this.menu = open.then_some("engine-picker");
                cx.notify();
            }))
            .on_pick(cx.listener(|this, v: &SharedString, w, cx| {
                if v == "custom" {
                    let work: AskWork = std::rc::Rc::new(|this, socket, w, cx| {
                        this.switch_engine(socket, w, cx);
                        Ok(())
                    });
                    this.ask(
                        this.t("engine.socket"),
                        this.t("settings.socket"),
                        "",
                        "unix:///path/to/docker.sock",
                        this.t("engine.connect"),
                        w,
                        cx,
                        work,
                    );
                } else {
                    this.switch_engine(v.to_string(), w, cx);
                }
            }));
        let e = self.engine.clone();
        let none = self.tr.t("detail.none");
        let fields = Fields::new(&t)
            .text(
                self.t("settings.socket"),
                e.as_ref().map(|e| e.endpoint.clone()).unwrap_or_default(),
                &none,
                true,
            )
            .text(
                self.t("settings.version"),
                e.as_ref()
                    .and_then(|e| e.version.clone())
                    .unwrap_or_default(),
                &none,
                false,
            );
        div()
            .child(
                div()
                    .flex()
                    .flex_wrap()
                    .items_center()
                    .gap(px(14.))
                    .mb(px(8.))
                    .child(div().text_color(t.ink2).child(self.t("settings.engine")))
                    .child(select),
            )
            .child(
                div()
                    .mt(px(6.))
                    .text_size(px(12.5))
                    .text_color(t.muted)
                    .child(self.t("settings.engineNote")),
            )
            .child(div().mt(px(10.)).child(fields))
            .children(self.docker_settings(cx))
            .into_any_element()
    }

    /// images.js `dockerSettings`: where the docker command goes, and the switch.
    fn docker_settings(&self, cx: &mut Context<Self>) -> Option<Div> {
        let t = self.theme;
        let d = self.docker.clone()?;
        let row = div()
            .flex()
            .items_center()
            .gap(px(8.))
            .mt(px(12.))
            .pt(px(12.))
            .border_t_1()
            .border_color(t.line)
            .child(
                div()
                    .flex_none()
                    .text_color(t.ink2)
                    .child(self.t("docker.command")),
            );
        if !d.installed {
            return Some(row.child(div().truncate().child(self.t("docker.missing"))));
        }
        let (bg, fg) = if self.docker_switch_to.is_some() {
            (t.accent_soft, t.accent_text)
        } else if d.is_podbag {
            (t.green_soft, t.green)
        } else {
            (t.gray_soft, t.ink)
        };
        let route = self
            .docker_route(&d)
            .px(px(8.))
            .py(px(3.))
            .rounded(px(6.))
            .bg(bg)
            .text_color(fg)
            .text_size(px(13.))
            .font_weight(FontWeight::SEMIBOLD);
        let switch = (!(d.is_podbag && d.previous.is_none())).then(|| {
            let (symbol, label, to) = if d.is_podbag {
                (
                    "undo",
                    self.tv(
                        "docker.back",
                        &[("name", &d.previous.clone().unwrap_or_default())],
                    ),
                    "back",
                )
            } else {
                ("switch", self.t("docker.use"), "use")
            };
            IconButton::new("docker-switch", symbol, label, &t)
                .disabled(self.docker_switch_to.is_some())
                .on_click(cx.listener(move |this, _, _, cx| {
                    this.api.docker_switch(to);
                    cx.notify();
                }))
        });
        Some(row.child(route).children(switch))
    }

    fn vm_body(&self, vm: &VmStatus, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let lang = self.lang();
        let running = vm.state == "running";
        let stoppable = running || vm.state == "standby" || vm.state == "starting";
        let mut fields = Fields::new(&t).row(
            self.t("settings.vmState"),
            div().flex().child(self.vm_chip(&vm.state)),
        );
        let none = self.tr.t("detail.none");
        if let Some(u) = vm.in_use {
            let idle = match u.idle_seconds {
                Some(s) if s > 0 => self.tr.tv(
                    "settings.idleAfter",
                    &[("time", &bench_api::fmt::duration(Some(s as u64), lang))],
                ),
                _ => self.tr.t("settings.idleNever"),
            };
            let text = format!(
                "{} · {} · {idle}",
                self.tr
                    .tv("settings.cpusValue", &[("n", &u.cpus.unwrap_or(0))]),
                bench_api::fmt::mib(u.memory_mib, lang)
            );
            fields = fields.text(self.t("settings.vmInUse"), text, &none, false);
        }
        if vm.uptime_seconds.is_some() {
            fields = fields.text(
                self.t("settings.vmUptime"),
                bench_api::fmt::duration(vm.uptime_seconds, lang),
                &none,
                false,
            );
        }
        if let Some(disk) = &vm.disk {
            let used = bench_api::fmt::size(disk.allocated_bytes, lang);
            let size = bench_api::fmt::size(disk.size_bytes, lang);
            fields = fields.text(
                self.t("settings.vmDisk"),
                self.tr
                    .tv("settings.vmDiskValue", &[("used", &used), ("size", &size)]),
                &none,
                false,
            );
        }
        let busy = self.vm_busy;
        let buttons = div()
            .flex()
            .flex_wrap()
            .gap(px(8.))
            .mt(px(14.))
            .child(
                Button::new("vm-start", self.t("action.startVm"), &t)
                    .icon("start")
                    .tone(if stoppable {
                        Tone::Normal
                    } else {
                        Tone::Primary
                    })
                    .disabled(busy || stoppable || vm.state == "not set up")
                    .on_click(cx.listener(|this, _, _, cx| this.vm_action("start", cx))),
            )
            .child(
                Button::new("vm-stop", self.t("action.stopVm"), &t)
                    .icon("stop")
                    .disabled(busy || !stoppable)
                    .on_click(cx.listener(|this, _, _, cx| this.vm_action("stop", cx))),
            )
            .child(
                Button::new("vm-restart", self.t("action.restartVm"), &t)
                    .icon("restart")
                    .disabled(busy || !running)
                    .on_click(cx.listener(|this, _, _, cx| this.vm_action("restart", cx))),
            );
        let form: AnyElement = if vm.resources_editable {
            self.vm_form(vm, cx)
        } else {
            div()
                .mt(px(6.))
                .text_size(px(12.5))
                .text_color(t.muted)
                .child(self.t("settings.vmWsl"))
                .into_any_element()
        };
        div()
            .child(fields)
            .child(buttons)
            .child(form)
            .into_any_element()
    }

    fn vm_chip(&self, state: &str) -> Div {
        let key = vm_state_key(state);
        let cls = match key {
            "running" => "running",
            "starting" => "restarting",
            _ => "created",
        };
        crate::widgets::chip::chip(cls, self.t(&format!("vm.state.{key}")), &self.theme)
    }

    fn vm_form(&self, vm: &VmStatus, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let lang = self.lang();
        let l = vm.limits;
        let f = &self.settings_ui.form;
        let over = |field: &str| {
            vm.overridden_by
                .iter()
                .find(|n| {
                    matches!(
                        (n.as_str(), field),
                        ("PODBAG_VM_CPUS", "cpus")
                            | ("PODBAG_VM_MEMORY", "memory")
                            | ("PODBAG_VM_IDLE", "idle")
                    )
                })
                .cloned()
        };
        let values = self.form_values(cx);
        let field = |id: &'static str,
                     label: SharedString,
                     input: &Entity<TextInput>,
                     slider: Option<Slider>,
                     hint: String,
                     over: Option<String>| {
            div()
                .flex()
                .flex_col()
                .gap(px(5.))
                .flex_1()
                .min_w(px(150.))
                .child(
                    div()
                        .text_size(px(13.))
                        .font_weight(FontWeight::SEMIBOLD)
                        .child(label),
                )
                .child(
                    div()
                        .id(id)
                        .h(px(34.))
                        .px(px(10.))
                        .flex()
                        .items_center()
                        .border_1()
                        .border_color(t.line)
                        .rounded(px(7.))
                        .bg(t.surface)
                        .child(input.clone()),
                )
                .children(slider)
                .child(div().text_size(px(12.5)).text_color(t.muted).child(hint))
                .children(over.map(|name| {
                    div()
                        .text_size(px(12.5))
                        .text_color(t.amber)
                        .child(self.tr.tv("settings.vmOverridden", &[("name", &name)]))
                }))
        };
        let cpus_v = values[0].trim().parse::<f64>().unwrap_or(l.cpus_min as f64);
        let mem_v = values[1]
            .trim()
            .replace(',', ".")
            .parse::<f64>()
            .unwrap_or(l.memory_min_mib as f64 / 1024.);
        let cpus_input = f.cpus.clone();
        let mem_input = f.memory.clone();
        let cpus_slider = Slider::new(
            "vm-cpus-range",
            cpus_v,
            l.cpus_min as f64,
            l.cpus_max as f64,
            1.,
            &t,
        )
        .on_change(cx.listener(move |_, v: &f64, _, cx| {
            let v = num(*v);
            cpus_input.update(cx, |i, cx| i.set_content(&v, cx));
            cx.notify();
        }));
        let mem_slider = Slider::new(
            "vm-memory-range",
            mem_v,
            l.memory_min_mib as f64 / 1024.,
            l.memory_max_mib as f64 / 1024.,
            0.25,
            &t,
        )
        .on_change(cx.listener(move |_, v: &f64, _, cx| {
            let v = num(*v);
            mem_input.update(cx, |i, cx| i.set_content(&v, cx));
            cx.notify();
        }));
        let grid = div()
            .flex()
            .flex_wrap()
            .gap(px(14.))
            .child(field(
                "vm-cpus",
                self.t("settings.cpus"),
                &f.cpus,
                Some(cpus_slider),
                self.tr.tv(
                    "settings.limits",
                    &[("min", &l.cpus_min), ("max", &l.cpus_max)],
                ),
                over("cpus"),
            ))
            .child(field(
                "vm-memory",
                self.t("settings.memory"),
                &f.memory,
                Some(mem_slider),
                self.tr.tv(
                    "settings.limits",
                    &[
                        ("min", &bench_api::fmt::mib(Some(l.memory_min_mib), lang)),
                        ("max", &bench_api::fmt::mib(Some(l.memory_max_mib), lang)),
                    ],
                ),
                over("memory"),
            ))
            .child(field(
                "vm-idle",
                self.t("settings.idle"),
                &f.idle,
                None,
                self.tr.t("settings.idleHint"),
                over("idle"),
            ));
        div()
            .mt(px(18.))
            .pt(px(16.))
            .border_t_1()
            .border_color(t.line)
            .child(grid)
            .when(vm.pending, |d| {
                d.child(
                    div()
                        .mt(px(6.))
                        .text_size(px(12.5))
                        .text_color(t.muted)
                        .child(self.t("settings.vmPending")),
                )
            })
            .when(!f.error.is_empty(), |d| {
                d.child(div().mt(px(6.)).text_color(t.red).child(f.error.clone()))
            })
            .child(
                div().flex().mt(px(14.)).child(
                    Button::new("vm-apply", self.t("settings.apply"), &t)
                        .primary()
                        .on_click(cx.listener(|this, _, w, cx| this.apply_vm(w, cx))),
                ),
            )
            .into_any_element()
    }
}
