//! `.check`: a checkbox with its label.

use std::rc::Rc;

use gpui::{AnyElement, App, ElementId, Window, div, prelude::*, px};

use crate::icons::icon;
use crate::theme::Theme;

type Handler = Rc<dyn Fn(&bool, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct Checkbox {
    id: ElementId,
    checked: bool,
    indeterminate: bool,
    disabled: bool,
    label: Option<AnyElement>,
    t: Theme,
    on_toggle: Option<Handler>,
}

impl Checkbox {
    pub fn new(id: impl Into<ElementId>, checked: bool, t: &Theme) -> Self {
        Self {
            id: id.into(),
            checked,
            indeterminate: false,
            disabled: false,
            label: None,
            t: *t,
            on_toggle: None,
        }
    }

    pub fn label(mut self, label: impl IntoElement) -> Self {
        self.label = Some(label.into_any_element());
        self
    }

    /// Unknown yet (`indeterminate`).
    pub fn indeterminate(mut self, on: bool) -> Self {
        self.indeterminate = on;
        self
    }

    pub fn disabled(mut self, disabled: bool) -> Self {
        self.disabled = disabled;
        self
    }

    /// Called with the new value.
    pub fn on_toggle(mut self, f: impl Fn(&bool, &mut Window, &mut App) + 'static) -> Self {
        self.on_toggle = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Checkbox {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let on = self.checked && !self.indeterminate;
        let filled = on || self.indeterminate;
        let enabled = !self.disabled;
        let next = !self.checked;
        let mark = div()
            .flex()
            .flex_none()
            .items_center()
            .justify_center()
            .size(px(16.))
            .rounded(px(4.))
            .border_1()
            .border_color(if filled { t.accent } else { t.muted })
            .bg(if filled { t.accent } else { t.surface })
            .when(on, |d| d.child(icon("check", px(12.), t.accent_ink)))
            .when(self.indeterminate, |d| {
                d.child(div().w(px(8.)).h(px(2.)).bg(t.accent_ink))
            });
        div()
            .id(self.id)
            .flex()
            .items_center()
            .gap(px(7.))
            .when(enabled, |d| d.cursor_pointer())
            .when(!enabled, |d| d.opacity(0.6))
            .child(mark)
            .children(self.label)
            .when_some(self.on_toggle.filter(|_| enabled), |d, f| {
                d.on_click(move |_, w, cx| f(&next, w, cx))
            })
    }
}
