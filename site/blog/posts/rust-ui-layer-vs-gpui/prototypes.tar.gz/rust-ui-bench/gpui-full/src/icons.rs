//! Icons: the SVG symbols of Podbag's `desktop/ui/index.html` (same project, ec551fd),
//! served to GPUI as assets. GPUI draws an SVG as a one-colour mask, so the stroke
//! colour here does not matter; `text_color` sets the colour.

use std::borrow::Cow;

use gpui::prelude::*;
use gpui::{AssetSource, Hsla, Pixels, SharedString, Svg, svg};

const ICONS: &[(&str, &str)] = &[
    (
        "tutorials",
        r##"<path d="M12 6.5C9 4.5 5.5 4.5 2.5 5v13c3-.5 6.5-.5 9.5 1.5 3-2 6.5-2 9.5-1.5V5c-3-.5-6.5-.5-9.5 1.5Zm0 0v13"/>"##,
    ),
    (
        "containers",
        r##"<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>"##,
    ),
    (
        "images",
        r##"<path d="m12 3 9 4.5-9 4.5-9-4.5z"/><path d="m3 12 9 4.5 9-4.5"/><path d="m3 16.5 9 4.5 9-4.5"/>"##,
    ),
    (
        "volumes",
        r##"<ellipse cx="12" cy="5.5" rx="8" ry="2.5"/><path d="M4 5.5v13c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5v-13"/><path d="M4 12c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5"/>"##,
    ),
    (
        "networks",
        r##"<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/><path d="M12 8v4M6 16v-2h12v2"/>"##,
    ),
    (
        "kubernetes",
        r##"<path d="m12 2 8.2 4 2 8.8-5.7 7H7.5l-5.7-7 2-8.8z"/><circle cx="12" cy="12" r="3"/><path d="M12 5.5V9m5.6-.2-3 1.7m3 5-3-1.8M12 18.5V15m-5.6.5 3-1.8m-3-4.9 3 1.7"/>"##,
    ),
    (
        "kube-pods",
        r##"<path d="m12 2 8.5 5v10L12 22l-8.5-5V7z"/><path d="m12 7 4.5 2.5v5L12 17l-4.5-2.5v-5z"/>"##,
    ),
    (
        "kube-services",
        r##"<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="18.5" r="2.5"/><circle cx="19" cy="18.5" r="2.5"/><path d="M12 7.5V12M5 16v-4h14v4"/>"##,
    ),
    (
        "kube-deployments",
        r##"<path d="M4 15V4h12M8 18V8h12"/><rect x="12" y="12" width="10" height="9" rx="1.5"/>"##,
    ),
    (
        "kube-claims",
        r##"<ellipse cx="11" cy="5.5" rx="7.5" ry="3"/><path d="M3.5 5.5v12c0 1.7 3.4 3 7.5 3M18.5 5.5v5M3.5 11.5c0 1.7 3.4 3 7.5 3m2 2.5 3 3 5-6"/>"##,
    ),
    (
        "migration",
        r##"<path d="M3 7h15m-4-4 4 4-4 4M21 17H6m4-4-4 4 4 4"/>"##,
    ),
    (
        "settings",
        r##"<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>"##,
    ),
    ("start", r##"<path d="M7 4.5v15l12-7.5z"/>"##),
    (
        "stop",
        r##"<rect x="6" y="6" width="12" height="12" rx="1.5"/>"##,
    ),
    (
        "restart",
        r##"<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/>"##,
    ),
    ("pause", r##"<path d="M8 5v14M16 5v14"/>"##),
    (
        "remove",
        r##"<path d="M4 7h16M9 7V4.5h6V7M6 7l1 13h10l1-13M10 11v6M14 11v6"/>"##,
    ),
    (
        "logs",
        r##"<path d="M5 4h10l4 4v12H5z"/><path d="M8 11h8M8 14.5h8M8 18h5"/>"##,
    ),
    (
        "shell",
        r##"<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M12.5 15H17"/>"##,
    ),
    (
        "inspect",
        r##"<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>"##,
    ),
    (
        "search",
        r##"<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>"##,
    ),
    (
        "refresh",
        r##"<path d="M4 12a8 8 0 0 1 13.7-5.7L20 8.5M20 4v4.5h-4.5M20 12a8 8 0 0 1-13.7 5.7L4 15.5M4 20v-4.5h4.5"/>"##,
    ),
    ("pull", r##"<path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/>"##),
    (
        "prune",
        r##"<path d="M14 4 9.5 12.5M6 12.5h8.5l1.5 7.5H4.5z"/><path d="M8 16.5v3.5M12 16.5v3.5"/>"##,
    ),
    ("back", r##"<path d="M15 5 8 12l7 7"/>"##),
    (
        "copy",
        r##"<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>"##,
    ),
    (
        "rename",
        r##"<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>"##,
    ),
    (
        "sidebar",
        r##"<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="M9 4.5v15M5.5 8.5h1.5M5.5 11.5h1.5"/>"##,
    ),
    ("forward", r##"<path d="m9 5 7 7-7 7"/>"##),
    (
        "switch",
        r##"<path d="M4 8h15m-4-4 4 4-4 4M20 16H5m4-4-4 4 4 4"/>"##,
    ),
    ("undo", r##"<path d="m9 4-5 5 5 5M5 9h9a6 6 0 0 1 0 12"/>"##),
    (
        "vm",
        r##"<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M10 10h4v4h-4zM9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/>"##,
    ),
    (
        "update",
        r##"<circle cx="12" cy="12" r="9"/><path d="M12 16.5v-9M8 11l4-4 4 4"/>"##,
    ),
    ("power", r##"<path d="M12 3v8m-5-6a8 8 0 1 0 10 0"/>"##),
    (
        "globe",
        r##"<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>"##,
    ),
    (
        "appearance",
        r##"<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="#000" stroke="none"/>"##,
    ),
    (
        "display",
        r##"<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 17v3m-4 0h8"/>"##,
    ),
    (
        "sun",
        r##"<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>"##,
    ),
    (
        "moon",
        r##"<path d="M20.5 14a8.8 8.8 0 0 1-10.5-10.5A9 9 0 1 0 20.5 14z"/>"##,
    ),
    (
        "warning",
        r##"<path d="M12 4 2.5 20h19z"/><path d="M12 10v4.5M12 17.5v.5"/>"##,
    ),
    ("close", r##"<path d="m6 6 12 12M18 6 6 18"/>"##),
    (
        "engine",
        r##"<path d="M4 8h16M4 16h16"/><circle cx="9" cy="8" r="2.2"/><circle cx="15" cy="16" r="2.2"/>"##,
    ),
    (
        "star",
        r##"<path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"/>"##,
    ),
    ("check", r##"<path d="m5 12.5 4.5 4.5L19 7.5"/>"##),
    (
        "key",
        r##"<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2.5 2.5M14 9l2 2"/>"##,
    ),
    (
        "import",
        r##"<path d="M4 14v5h16v-5M12 4v10M8 10l4 4 4-4"/>"##,
    ),
];

const LOGO: &[u8] = include_bytes!("../assets/logo-small.png");

/// Serves `icons/<name>.svg` and `logo-small.png`.
pub struct Assets;

impl AssetSource for Assets {
    fn load(&self, path: &str) -> gpui::Result<Option<Cow<'static, [u8]>>> {
        if path == "logo-small.png" {
            return Ok(Some(Cow::Borrowed(LOGO)));
        }
        let Some(name) = path
            .strip_prefix("icons/")
            .and_then(|p| p.strip_suffix(".svg"))
        else {
            return Ok(None);
        };
        Ok(ICONS.iter().find(|(n, _)| *n == name).map(|(_, inner)| {
            Cow::Owned(
                format!(
                    r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{inner}</svg>"##
                )
                .into_bytes(),
            )
        }))
    }

    fn list(&self, _path: &str) -> gpui::Result<Vec<SharedString>> {
        Ok(ICONS
            .iter()
            .map(|(n, _)| format!("icons/{n}.svg").into())
            .collect())
    }
}

/// An icon of `size` pixels in `color`.
pub fn icon(name: &str, size: Pixels, color: Hsla) -> Svg {
    svg()
        .path(SharedString::from(format!("icons/{name}.svg")))
        .size(size)
        .flex_none()
        .text_color(color)
}
