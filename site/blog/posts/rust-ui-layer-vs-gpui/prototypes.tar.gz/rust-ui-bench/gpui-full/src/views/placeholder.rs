//! Training and Migrate: out of scope for the benchmark, shown as a placeholder.

use gpui::{AnyElement, Context, FontWeight, div, prelude::*, px};

use crate::app::Podbag;
use crate::icons::icon;
use crate::views::resources::{empty_page, heading, toolbar};

impl Podbag {
    pub fn render_placeholder(
        &mut self,
        symbol: &'static str,
        title_key: &str,
        _cx: &mut Context<Self>,
    ) -> AnyElement {
        let t = self.theme;
        div()
            .flex()
            .flex_col()
            .size_full()
            .child(toolbar(&t).child(heading(self.t(title_key))))
            .child(
                empty_page()
                    .child(
                        div()
                            .flex()
                            .items_center()
                            .justify_center()
                            .size(px(64.))
                            .rounded(px(16.))
                            .bg(t.accent_soft)
                            .child(icon(symbol, px(32.), t.accent_text)),
                    )
                    .child(
                        div()
                            .mt(px(12.))
                            .text_size(px(18.))
                            .font_weight(FontWeight::BOLD)
                            .child(self.t(title_key)),
                    )
                    .child(
                        div()
                            .text_color(t.ink2)
                            .child("Out of scope for this benchmark port."),
                    ),
            )
            .into_any_element()
    }
}
