//! `select`: a drop-down list. The owner keeps whether it is open.

use std::rc::Rc;

use gpui::{App, FontWeight, SharedString, Window, anchored, deferred, div, prelude::*, px};

use crate::icons::icon;
use crate::theme::Theme;

pub enum Item {
    Option {
        value: SharedString,
        label: SharedString,
    },
    /// An `optgroup` title.
    Group(SharedString),
}

type Toggle = Rc<dyn Fn(&bool, &mut Window, &mut App)>;
type Pick = Rc<dyn Fn(&SharedString, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct Select {
    id: SharedString,
    items: Vec<Item>,
    value: SharedString,
    open: bool,
    width: f32,
    t: Theme,
    on_toggle: Option<Toggle>,
    on_pick: Option<Pick>,
}

impl Select {
    pub fn new(
        id: impl Into<SharedString>,
        value: impl Into<SharedString>,
        open: bool,
        t: &Theme,
    ) -> Self {
        Self {
            id: id.into(),
            items: Vec::new(),
            value: value.into(),
            open,
            width: 240.,
            t: *t,
            on_toggle: None,
            on_pick: None,
        }
    }

    pub fn option(
        mut self,
        value: impl Into<SharedString>,
        label: impl Into<SharedString>,
    ) -> Self {
        self.items.push(Item::Option {
            value: value.into(),
            label: label.into(),
        });
        self
    }

    pub fn group(mut self, label: impl Into<SharedString>) -> Self {
        self.items.push(Item::Group(label.into()));
        self
    }

    pub fn width(mut self, w: f32) -> Self {
        self.width = w;
        self
    }

    /// Open (true) or close (false).
    pub fn on_toggle(mut self, f: impl Fn(&bool, &mut Window, &mut App) + 'static) -> Self {
        self.on_toggle = Some(Rc::new(f));
        self
    }

    /// An option was chosen (the menu is closed first).
    pub fn on_pick(mut self, f: impl Fn(&SharedString, &mut Window, &mut App) + 'static) -> Self {
        self.on_pick = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Select {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let label = self
            .items
            .iter()
            .find_map(|i| match i {
                Item::Option { value, label } if *value == self.value => Some(label.clone()),
                _ => None,
            })
            .unwrap_or_else(|| self.value.clone());
        let next = !self.open;
        let toggle = self.on_toggle.clone();
        let trigger = div()
            .id(self.id.clone())
            .flex()
            .items_center()
            .justify_between()
            .gap(px(8.))
            .h(px(34.))
            .w(px(self.width))
            .px(px(10.))
            .border_1()
            .border_color(if self.open { t.accent } else { t.line })
            .rounded(px(7.))
            .bg(t.surface)
            .text_color(t.ink)
            .cursor_pointer()
            .child(div().flex_1().min_w_0().truncate().child(label))
            .child(icon("forward", px(13.), t.muted).with_transformation(
                gpui::Transformation::rotate(gpui::radians(std::f32::consts::FRAC_PI_2)),
            ))
            .when_some(toggle, |d, f| d.on_click(move |_, w, cx| f(&next, w, cx)));
        let menu = self.open.then(|| {
            let close = self.on_toggle.clone();
            let id = self.id.clone();
            let rows =
                self.items
                    .into_iter()
                    .enumerate()
                    .map(|(i, item)| match item {
                        Item::Group(text) => div()
                            .px(px(8.))
                            .pt(px(6.))
                            .pb(px(2.))
                            .text_size(px(11.5))
                            .font_weight(FontWeight::SEMIBOLD)
                            .text_color(t.muted)
                            .child(text)
                            .into_any_element(),
                        Item::Option { value, label } => {
                            let chosen = value == self.value;
                            let pick = self.on_pick.clone();
                            let close = self.on_toggle.clone();
                            div()
                                .id(SharedString::from(format!("{id}-{i}")))
                                .flex()
                                .items_center()
                                .gap(px(6.))
                                .px(px(8.))
                                .py(px(5.))
                                .rounded(px(6.))
                                .cursor_pointer()
                                .text_color(t.ink)
                                .hover(move |s| s.bg(t.hover))
                                .child(div().w(px(15.)).when(chosen, |d| {
                                    d.child(icon("check", px(14.), t.accent_text))
                                }))
                                .child(div().flex_1().truncate().child(label))
                                .on_click(move |_, w, cx| {
                                    if let Some(f) = &close {
                                        f(&false, w, cx);
                                    }
                                    if let Some(f) = &pick {
                                        f(&value, w, cx);
                                    }
                                })
                                .into_any_element()
                        }
                    });
            deferred(
                anchored()
                    .offset(gpui::point(px(0.), px(38.)))
                    .snap_to_window_with_margin(px(8.))
                    .child(
                        div()
                            .id(SharedString::from(format!("{}-menu", self.id)))
                            .occlude()
                            .min_w(px(self.width))
                            .max_h(px(360.))
                            .overflow_y_scroll()
                            .p(px(4.))
                            .bg(t.surface)
                            .border_1()
                            .border_color(t.line)
                            .rounded(px(8.))
                            .shadow_lg()
                            .children(rows)
                            .on_mouse_down_out(move |_, w, cx| {
                                if let Some(f) = &close {
                                    f(&false, w, cx);
                                }
                            }),
                    ),
            )
            .with_priority(1)
        });
        div()
            .flex()
            .flex_col()
            .flex_none()
            .child(trigger)
            .children(menu)
    }
}
