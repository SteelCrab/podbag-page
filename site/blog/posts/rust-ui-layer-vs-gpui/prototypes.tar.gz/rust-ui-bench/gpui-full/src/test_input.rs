//! Test hooks on stdin, for driving the window without the real keyboard:
//! `key <keystroke>` ("escape", "cmd-shift-p"), `type <text>`. They go through GPUI's
//! normal key dispatch. (Mouse input cannot be injected: `Window::dispatch_event`
//! returns a private type in gpui 0.2.2. Clicks are `do …` commands, see test_hooks.rs.)

use gpui::{App, Keystroke, Modifiers, Window};

pub enum TestInput {
    Key(Keystroke),
}

pub fn parse(line: &str) -> Option<Vec<TestInput>> {
    let line = line.trim_end();
    if let Some(k) = line.strip_prefix("key ") {
        return Keystroke::parse(k.trim())
            .ok()
            .map(|k| vec![TestInput::Key(k)]);
    }
    if let Some(text) = line.strip_prefix("type ") {
        return Some(
            text.chars()
                .map(|c| {
                    TestInput::Key(Keystroke {
                        modifiers: Modifiers::default(),
                        key: c.to_string(),
                        key_char: Some(c.to_string()),
                    })
                })
                .collect(),
        );
    }
    None
}

pub fn dispatch(input: TestInput, window: &mut Window, cx: &mut App) {
    let TestInput::Key(k) = input;
    window.dispatch_keystroke(k, cx);
    window.refresh();
}
