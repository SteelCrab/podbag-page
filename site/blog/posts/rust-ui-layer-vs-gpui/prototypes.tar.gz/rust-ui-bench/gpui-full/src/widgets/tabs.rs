//! `.tabs` / `.tab`: a row of tabs with an underline on the chosen one.

use std::rc::Rc;

use gpui::{
    AnyElement, App, ClickEvent, Div, ElementId, FontWeight, SharedString, Window, div, prelude::*,
    px,
};

use crate::theme::Theme;

#[derive(IntoElement)]
pub struct Tab {
    id: ElementId,
    label: SharedString,
    selected: bool,
    t: Theme,
    on_click: Option<Rc<dyn Fn(&ClickEvent, &mut Window, &mut App)>>,
}

impl Tab {
    pub fn new(
        id: impl Into<ElementId>,
        label: impl Into<SharedString>,
        selected: bool,
        t: &Theme,
    ) -> Self {
        Self {
            id: id.into(),
            label: label.into(),
            selected,
            t: *t,
            on_click: None,
        }
    }

    pub fn on_click(mut self, f: impl Fn(&ClickEvent, &mut Window, &mut App) + 'static) -> Self {
        self.on_click = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Tab {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        div()
            .id(self.id)
            .px(px(12.))
            .pt(px(10.))
            .pb(px(9.))
            .mb(px(-1.))
            .border_b_2()
            .border_color(if self.selected {
                t.accent
            } else {
                gpui::transparent_black()
            })
            .text_color(if self.selected { t.accent_text } else { t.ink2 })
            .font_weight(FontWeight::MEDIUM)
            .cursor_pointer()
            .hover(move |s| {
                if self.selected {
                    s
                } else {
                    s.text_color(t.ink)
                }
            })
            .child(self.label)
            .when_some(self.on_click, |d, f| {
                d.on_click(move |e, w, cx| f(e, w, cx))
            })
    }
}

/// The tab row (`.tabs`), with optional extra content at its end.
pub fn tab_bar(t: &Theme, tabs: impl IntoIterator<Item = Tab>, end: Option<AnyElement>) -> Div {
    div()
        .flex()
        .flex_none()
        .items_center()
        .gap(px(4.))
        .px(px(20.))
        .border_b_1()
        .border_color(t.line)
        .children(tabs)
        .children(end.map(|e| div().ml_auto().py(px(6.)).child(e)))
}
