//! Podbag Desktop's window in GPUI, on the shared mock backend (bench-api).
//!
//! Usage: gpui-full [--rows N]   (see bench-api's README for BENCH_* variables)
//! stdout: `READY <ms since main>`, `RENDER <ms>`, `FILTER <ms> <visible rows>`, `VIEW <name> <ms>`.
//! stdin: `filter <text>`, `nav <view>`, `quit`. BENCH_NO_FOCUS: do not focus the search box.

mod app;
mod bench;
mod icons;
mod shell;
mod test_hooks;
mod test_input;
mod theme;
mod views;
mod widgets;

use std::io::BufRead;
use std::time::Instant;

use futures::StreamExt;
use futures::channel::mpsc;
use gpui::{
    App, Application, Bounds, Focusable, KeyBinding, Window, WindowBounds, WindowOptions,
    prelude::*, px, size,
};

use app::{Back, Escape, FocusSearch, Forward, OpenPull, OpenSettings, Podbag, ToggleSidebar};
use bench::{T0, log_enabled};

/// GPUI logs through the `log` crate; with BENCH_LOG set, print its messages to stderr.
struct StderrLog;

impl log::Log for StderrLog {
    fn enabled(&self, _: &log::Metadata) -> bool {
        true
    }
    fn log(&self, record: &log::Record) {
        eprintln!(
            "[{}] {}: {}",
            record.level(),
            record.target(),
            record.args()
        );
    }
    fn flush(&self) {}
}

fn bind_keys(cx: &mut App) {
    widgets::input::bind_keys(cx);
    let mac = cfg!(target_os = "macos");
    cx.bind_keys([
        KeyBinding::new(if mac { "cmd-[" } else { "alt-left" }, Back, None),
        KeyBinding::new(if mac { "cmd-]" } else { "alt-right" }, Forward, None),
        KeyBinding::new(
            if mac { "ctrl-cmd-s" } else { "ctrl-b" },
            ToggleSidebar,
            None,
        ),
        KeyBinding::new("secondary-f", FocusSearch, None),
        KeyBinding::new("secondary-k", FocusSearch, None),
        KeyBinding::new("escape", Escape, None),
        KeyBinding::new("secondary-shift-p", OpenPull, None),
        KeyBinding::new(if mac { "cmd-," } else { "ctrl-," }, OpenSettings, None),
    ]);
}

fn main() {
    T0.set(Instant::now()).unwrap();
    if log_enabled() {
        static LOGGER: StderrLog = StderrLog;
        let _ = log::set_logger(&LOGGER);
        log::set_max_level(log::LevelFilter::Info);
    }
    let (api, events) = bench_api::Backend::new(bench_api::Options::from_env());

    // stdin commands and backend events reach the UI through channels.
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded::<String>();
    std::thread::spawn(move || {
        for line in std::io::stdin().lock().lines() {
            let Ok(line) = line else { break };
            if cmd_tx.unbounded_send(line).is_err() {
                break;
            }
        }
    });
    let (ev_tx, mut ev_rx) = mpsc::unbounded::<bench_api::Event>();
    std::thread::spawn(move || {
        while let Ok(e) = events.recv() {
            if ev_tx.unbounded_send(e).is_err() {
                break;
            }
        }
    });

    Application::new()
        .with_assets(icons::Assets)
        .run(move |cx: &mut App| {
            bind_keys(cx);
            let bounds = Bounds::centered(None, size(px(1200.), px(800.)), cx);
            let shot = std::env::var_os("BENCH_SHOT").is_some();
            let window = cx
                .open_window(
                    WindowOptions {
                        window_bounds: Some(WindowBounds::Windowed(bounds)),
                        titlebar: Some(gpui::TitlebarOptions {
                            title: Some("podbag (GPUI full)".into()),
                            ..Default::default()
                        }),
                        window_min_size: Some(size(px(640.), px(480.))),
                        // BENCH_SHOT: a floating panel that never takes the keyboard, so Stage
                        // Manager leaves it on screen for screenshots. Not used by the benchmark.
                        kind: if shot {
                            gpui::WindowKind::PopUp
                        } else {
                            gpui::WindowKind::Normal
                        },
                        focus: !shot,
                        ..Default::default()
                    },
                    |window, cx| cx.new(|cx| Podbag::new(api, window, cx)),
                )
                .unwrap();
            window
                .update(cx, |v, window, cx| {
                    // BENCH_NO_FOCUS: same switch as the prototypes.
                    if shot {
                        return;
                    }
                    if std::env::var_os("BENCH_NO_FOCUS").is_none() {
                        window.focus(&v.search[0].focus_handle(cx));
                    } else {
                        window.focus(&v.focus);
                    }
                    let accent = v.theme.accent;
                    for s in &v.search {
                        s.update(cx, |i, _| i.accent = accent);
                    }
                    cx.activate(true);
                })
                .unwrap();
            if log_enabled() {
                fn tick(window: &mut Window, count: u64, last: Instant) {
                    let (count, last) = if last.elapsed().as_secs_f64() >= 1.0 {
                        eprintln!("frames in last second: {count}");
                        (0, Instant::now())
                    } else {
                        (count + 1, last)
                    };
                    window.on_next_frame(move |w, _| tick(w, count, last));
                }
                window
                    .update(cx, |_, window, _| tick(window, 0, Instant::now()))
                    .unwrap();
            }
            let any_window: gpui::AnyWindowHandle = window.into();
            cx.spawn(async move |cx| {
                while let Some(line) = cmd_rx.next().await {
                    // Test input (`click`, `key`, `type`) goes through the window like real input.
                    if let Some(events) = test_input::parse(&line) {
                        for e in events {
                            let _ = any_window
                                .update(cx, |_, window, cx| test_input::dispatch(e, window, cx));
                        }
                        continue;
                    }
                    let _ = window.update(cx, |v, window, cx| v.command(&line, window, cx));
                }
            })
            .detach();
            cx.spawn(async move |cx| {
                while let Some(e) = ev_rx.next().await {
                    let _ = window.update(cx, |v, window, cx| v.on_event(e, window, cx));
                }
            })
            .detach();
        });
}
