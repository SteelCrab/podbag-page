//! Images: columns, cells, the Info fields, and "Import from Docker".
//! The pull panel is in pull.rs.

use gpui::{AnyElement, Context, FontWeight, Window, div, prelude::*, px};

use crate::app::*;
use crate::theme::MONO;
use crate::views::resources::Width;
use crate::widgets::dialog::{self, Modal as ModalBox};
use crate::widgets::fields::Fields;
use crate::widgets::table::Column;
use crate::widgets::{Button, Checkbox};

impl Podbag {
    pub fn image_columns(&self, w: Width) -> Vec<Column> {
        let mut cols = vec![Column::flex(self.t("col.name"))];
        if w > Width::Narrow {
            cols.push(Column::fixed(self.t("col.id"), 130.));
        }
        cols.push(Column::fixed(self.t("col.size"), 110.));
        cols.push(Column::fixed(self.t("col.created"), 150.));
        cols
    }

    pub fn image_cells(&self, i: usize, w: Width) -> Vec<AnyElement> {
        let t = self.theme;
        let img = &self.lists.images[i];
        let mut cells = vec![
            div()
                .truncate()
                .font_weight(FontWeight::SEMIBOLD)
                .child(img.name().to_string())
                .into_any_element(),
        ];
        if w > Width::Narrow {
            cells.push(
                div()
                    .truncate()
                    .font_family(MONO)
                    .text_size(px(12.5))
                    .text_color(t.ink2)
                    .child(bench_api::short_id(&img.id).to_string())
                    .into_any_element(),
            );
        }
        cells.push(
            div()
                .child(bench_api::fmt::size(img.size, self.lang()))
                .into_any_element(),
        );
        cells.push(
            div()
                .truncate()
                .text_color(t.ink2)
                .child(self.ago(img.created))
                .into_any_element(),
        );
        cells
    }

    pub fn image_info(&self, i: usize) -> Fields {
        let img = &self.lists.images[i];
        let none = self.tr.t("detail.none");
        let users: Vec<&str> = self
            .lists
            .containers
            .iter()
            .filter(|c| img.repo_tags.contains(&c.image) || c.image == img.id)
            .map(|c| c.name())
            .collect();
        Fields::new(&self.theme)
            .text(self.t("col.id"), img.id.clone(), &none, true)
            .text(
                self.t("detail.tags"),
                img.repo_tags.join(", "),
                &none,
                false,
            )
            .text(
                self.t("col.size"),
                bench_api::fmt::size(img.size, self.lang()),
                &none,
                false,
            )
            .text(self.t("col.created"), self.ago(img.created), &none, false)
            .text(self.t("detail.used"), users.join(", "), &none, false)
    }

    /// images.js `importFromDocker`: choose Docker Desktop images to copy.
    pub fn open_import(&mut self, cx: &mut Context<Self>) {
        let items = self
            .api
            .docker_images()
            .into_iter()
            .map(|d| (d, false))
            .collect();
        self.modal = Some(Modal::Import {
            items,
            status: "".into(),
            busy: false,
        });
        cx.notify();
    }

    fn run_import(&mut self, cx: &mut Context<Self>) {
        let Some(Modal::Import { items, .. }) = &self.modal else {
            return;
        };
        let names: Vec<String> = items
            .iter()
            .filter(|(_, on)| *on)
            .map(|(d, _)| d.name.clone())
            .collect();
        if names.is_empty() {
            return;
        }
        match self.api.import_images(&names) {
            Ok(()) => {
                let msg = self.tv("import.done", &[("n", &names.len())]);
                self.toast(msg, false, cx);
                self.refresh_soon(cx);
                self.modal = None;
            }
            Err(e) => {
                if let Some(Modal::Import { status, busy, .. }) = &mut self.modal {
                    *status = e.into();
                    *busy = false;
                }
            }
        }
        cx.notify();
    }

    pub fn render_import(&self, window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let Some(Modal::Import {
            items,
            status,
            busy,
        }) = &self.modal
        else {
            return div().into_any_element();
        };
        let have: Vec<&String> = self
            .lists
            .images
            .iter()
            .flat_map(|i| i.repo_tags.iter())
            .collect();
        let lang = self.lang();
        let rows = items.iter().enumerate().map(|(n, (d, on))| {
            let note = if have.contains(&&d.name) {
                self.tr.t("import.have")
            } else {
                bench_api::fmt::size(d.size, lang)
            };
            div()
                .flex()
                .items_center()
                .gap(px(8.))
                .px(px(8.))
                .py(px(6.))
                .rounded(px(6.))
                .hover(move |s| s.bg(t.hover))
                .child(
                    Checkbox::new(("import", n), *on, &t)
                        .disabled(*busy)
                        .label(div().flex_1().min_w_0().truncate().child(d.name.clone()))
                        .on_toggle(cx.listener(move |this, v: &bool, _, cx| {
                            if let Some(Modal::Import { items, .. }) = &mut this.modal {
                                items[n].1 = *v;
                            }
                            cx.notify();
                        })),
                )
                .child(div().ml_auto().text_color(t.ink2).child(note))
        });
        let body = dialog::form(&t)
            .child(dialog::title(self.t("import.title")))
            .child(dialog::text(self.t("import.text"), &t))
            .child(if items.is_empty() {
                dialog::text(self.t("import.none"), &t)
            } else {
                div().child(
                    div()
                        .id("import-list")
                        .flex()
                        .flex_col()
                        .gap(px(2.))
                        .max_h(px(320.))
                        .overflow_y_scroll()
                        .p(px(4.))
                        .border_1()
                        .border_color(t.line)
                        .rounded(px(8.))
                        .children(rows),
                )
            })
            .child(
                div()
                    .min_h(px(18.))
                    .font_family(MONO)
                    .text_size(px(12.5))
                    .child(status.clone()),
            )
            .child(
                dialog::buttons()
                    .child(
                        Button::new("import-cancel", self.t("action.cancel"), &t)
                            .on_click(cx.listener(|this, _, w, cx| this.close_modal(w, cx))),
                    )
                    .child(
                        Button::new("import-copy", self.t("import.copy"), &t)
                            .primary()
                            .disabled(items.is_empty() || *busy)
                            .on_click(cx.listener(|this, _, _, cx| this.run_import(cx))),
                    ),
            );
        let _ = window;
        ModalBox::new(body, &t)
            .width(520.)
            .on_dismiss(cx.listener(|this, _, w, cx| this.close_modal(w, cx)))
            .into_any_element()
    }
}
