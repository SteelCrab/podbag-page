//! `do …` on stdin: the same calls the buttons make, for driving the app in tests and
//! screenshots without the real mouse. Not part of the benchmark protocol.

use bench_api::{Kind, KubeKind};
use gpui::{Context, Window};

use crate::app::*;

fn kind(s: &str) -> Option<Kind> {
    Kind::ALL.into_iter().find(|k| k.as_str() == s)
}

impl Podbag {
    fn find_named(&self, kind: Kind, name: &str) -> Option<String> {
        (0..self.lists.len(kind))
            .find(|&i| self.lists.name(kind, i) == name)
            .map(|i| self.lists.id(kind, i).to_string())
    }

    pub fn test_command(&mut self, line: &str, window: &mut Window, cx: &mut Context<Self>) {
        let w: Vec<&str> = line.split_whitespace().collect();
        match w.as_slice() {
            // open <kind> <name> [info|logs|inspect]
            ["open", k, name, rest @ ..] => {
                let Some(k) = kind(k) else { return };
                let Some(id) = self.find_named(k, name) else {
                    return;
                };
                let tab = match rest.first() {
                    Some(&"logs") => DetailTab::Logs,
                    Some(&"inspect") => DetailTab::Inspect,
                    _ => DetailTab::Info,
                };
                self.open_detail(k, id, tab, window, cx);
            }
            ["act", name, action] => {
                let action: &'static str = match *action {
                    "start" => "start",
                    "stop" => "stop",
                    "restart" => "restart",
                    "pause" => "pause",
                    "unpause" => "unpause",
                    _ => return,
                };
                if let Some(id) = self.find_named(Kind::Containers, name) {
                    self.act(id, action, cx);
                }
            }
            ["remove", k, name] => {
                if let Some(k) = kind(k) {
                    if let Some(id) = self.find_named(k, name) {
                        self.remove(k, id, cx);
                    }
                }
            }
            ["prune", k] => {
                if let Some(k) = kind(k) {
                    self.prune(k, cx);
                }
            }
            ["rename", name] => {
                if let Some(id) = self.find_named(Kind::Containers, name) {
                    self.rename(id, window, cx);
                }
            }
            ["shell", name] => {
                if let Some(id) = self.find_named(Kind::Containers, name) {
                    self.shell(id, cx);
                }
            }
            ["answer", rest @ ..] => self.answer(rest.first().copied().unwrap_or(""), window, cx),
            ["submit"] => self.submit_ask(window, cx),
            ["close"] => self.close_modal(window, cx),
            ["back"] => self.travel(-1, window, cx),
            ["forward"] => self.travel(1, window, cx),
            ["tab", t] => {
                let tab = match *t {
                    "logs" => DetailTab::Logs,
                    "inspect" => DetailTab::Inspect,
                    _ => DetailTab::Info,
                };
                self.set_tab(tab, window, cx);
            }
            ["pull"] => self.open_pull(window, cx),
            ["import"] => self.open_import(cx),
            ["create-volume"] => self.create_volume(window, cx),
            ["sidebar"] => self.toggle_sidebar(cx),
            ["menu", name] => {
                self.menu = match *name {
                    "language" => Some("language"),
                    "engine-picker" => Some("engine-picker"),
                    "kube-context" => Some("kube-context"),
                    _ => None,
                };
            }
            ["lang", l] => {
                self.settings.language = l.to_string();
                self.save_settings();
                self.apply_language(cx);
            }
            ["theme", th] => {
                self.settings.theme = th.to_string();
                self.apply_theme(window);
                self.save_settings();
            }
            ["section", id] => {
                let id: &'static str = match *id {
                    "engine" => "engine-settings",
                    "vm" => "vm-settings",
                    _ => "about-settings",
                };
                if !self.settings_ui.open.remove(id) {
                    self.settings_ui.open.insert(id);
                }
            }
            ["kube", k] => {
                if let Some(k) = KubeKind::ALL.into_iter().find(|x| x.as_str() == *k) {
                    self.go_kube(k, window, cx);
                }
            }
            ["kube-inspect", row] => {
                if let Some(&(ix, _)) = row
                    .parse::<usize>()
                    .ok()
                    .and_then(|r| self.kube.rows.get(r))
                {
                    self.inspect_kube(ix, cx);
                }
            }
            ["kube-all", on] => {
                self.kube.all = *on == "on";
                self.refresh_kube_counts();
                self.kube_reload(cx);
            }
            ["vm", action] => {
                let a: &'static str = match *action {
                    "start" => "start",
                    "stop" => "stop",
                    _ => "restart",
                };
                self.vm_action(a, cx);
            }
            ["docker", to] => self
                .api
                .docker_switch(if *to == "use" { "use" } else { "back" }),
            ["engine", name] => self.switch_engine(name.to_string(), window, cx),
            _ => eprintln!("do: unknown command {line}"),
        }
        cx.notify();
    }
}
