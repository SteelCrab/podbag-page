//! `.chip` (a state pill with a dot), `.dot` and `.tag`.

use gpui::{Div, FontWeight, Hsla, SharedString, div, prelude::*, px};

use crate::theme::Theme;

/// The colours of a state: running green, paused and restarting amber, dead red, else gray.
pub fn state_colors(state: &str, t: &Theme) -> (Hsla, Hsla) {
    match state {
        "running" => (t.green, t.green_soft),
        "paused" | "restarting" => (t.amber, t.amber_soft),
        "dead" => (t.red, t.red_soft),
        _ => (t.ink2, t.gray_soft),
    }
}

/// A pill with a dot and a label, in the colours of `state`.
pub fn chip(state: &str, label: impl Into<SharedString>, t: &Theme) -> Div {
    let (fg, bg) = state_colors(state, t);
    div()
        .flex()
        .flex_none()
        .items_center()
        .gap(px(6.))
        .pl(px(7.))
        .pr(px(9.))
        .py(px(2.))
        .rounded_full()
        .bg(bg)
        .text_color(fg)
        .text_size(px(12.5))
        .font_weight(FontWeight::SEMIBOLD)
        .whitespace_nowrap()
        .child(dot(fg, 7.))
        .child(label.into())
}

/// A round dot.
pub fn dot(color: Hsla, size: f32) -> Div {
    div().flex_none().size(px(size)).rounded_full().bg(color)
}

/// `.tag`: a small gray label ("Built in", "Official").
pub fn tag(label: impl Into<SharedString>, fg: Hsla, bg: Hsla) -> Div {
    div()
        .flex_none()
        .px(px(6.))
        .rounded(px(4.))
        .text_size(px(11.))
        .text_color(fg)
        .bg(bg)
        .child(label.into())
}
