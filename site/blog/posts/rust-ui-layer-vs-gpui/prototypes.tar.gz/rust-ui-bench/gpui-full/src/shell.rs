//! The window frame: top bar, sidebar (nav, VM card, engine state), status bar,
//! the main page, toasts and dialogs.

use bench_api::{Kind, KubeKind};
use gpui::{
    AnyElement, Context, CursorStyle, Div, FontWeight, Hsla, MouseButton, SharedString, Stateful,
    Window, div, prelude::*, px, relative,
};

use crate::app::*;
use crate::icons::icon;
use crate::theme::{Theme, UI_FONT};
use crate::widgets::chip::dot;
use crate::widgets::{Button, IconButton};

/// app.js `engineState`: (class, text).
pub fn engine_state(app: &Podbag) -> (&'static str, SharedString) {
    let Some(e) = &app.engine else {
        return ("checking", app.t("engine.checking"));
    };
    if e.engine != "podbag" {
        return if e.reachable {
            ("ok", app.t("engine.running"))
        } else {
            ("down", app.t("engine.down"))
        };
    }
    match (e.vm.as_deref(), e.reachable) {
        (Some("running"), _) => ("ok", app.t("engine.vmRunning")),
        (Some(_), false) => ("off", app.t("engine.vmStopped")),
        (_, true) => ("ok", app.t("engine.running")),
        _ => ("down", app.t("engine.down")),
    }
}

pub fn state_color(cls: &str, t: &Theme) -> Hsla {
    match cls {
        "ok" => t.green,
        "down" => t.red,
        "checking" => t.amber,
        _ => t.muted,
    }
}

pub fn vm_state_key(state: &str) -> &'static str {
    match state {
        "running" => "running",
        "standby" => "standby",
        "starting" => "starting",
        "stopped" => "stopped",
        "not set up" => "notSetUp",
        _ => "unknown",
    }
}

impl Podbag {
    fn nav_item(
        &self,
        id: impl Into<SharedString>,
        symbol: &'static str,
        label: SharedString,
        count: Option<usize>,
        current: bool,
        sub: bool,
    ) -> Stateful<Div> {
        let t = self.theme;
        let rail = self.sidebar_width() == SIDEBAR_RAIL;
        let fg = if current { t.accent_text } else { t.ink2 };
        let id: SharedString = id.into();
        div()
            .id(id)
            .flex()
            .items_center()
            .gap(px(10.))
            .w_full()
            .min_w_0()
            .px(px(if rail { 0. } else { 10. }))
            .py(px(if sub { 5. } else { 7. }))
            .when(rail, |d| d.justify_center())
            .rounded(px(7.))
            .cursor_pointer()
            .text_color(fg)
            .when(current, |d| {
                d.bg(t.accent_soft).font_weight(FontWeight::SEMIBOLD)
            })
            .when(!current, |d| {
                d.hover(move |s| s.bg(t.hover).text_color(t.ink))
            })
            .child(icon(symbol, px(18.), fg))
            .when(!rail, |d| {
                d.child(div().flex_1().min_w_0().child(label.clone()))
                    .children(count.map(|n| {
                        div()
                            .flex_none()
                            .text_size(px(12.))
                            .text_color(if current { t.accent_text } else { t.muted })
                            .child(n.to_string())
                    }))
            })
            .tooltip({
                let text: SharedString = match count {
                    Some(n) => format!("{label} ({n})").into(),
                    None => label,
                };
                move |_, cx| crate::widgets::tooltip::Tooltip::view(text.clone(), &t, cx)
            })
    }

    fn sidebar(&self, cx: &mut Context<Self>) -> Stateful<Div> {
        let t = self.theme;
        let width = self.sidebar_width();
        let rail = width == SIDEBAR_RAIL;
        let detail_free = self.detail.is_none();
        let count = |kind: Kind| {
            (self.loaded && self.list_errors[kind_ix(kind)].is_none()).then(|| self.lists.len(kind))
        };
        let mut nav = div().flex().flex_col().gap(px(2.)).w_full();
        nav = nav.child(
            self.nav_item(
                "nav-migration",
                "migration",
                self.t("migration.title"),
                None,
                self.view == View::Migration,
                false,
            )
            .on_click(cx.listener(|this, _, w, cx| this.go(View::Migration, w, cx))),
        );
        for (kind, view) in [
            (Kind::Containers, View::Containers),
            (Kind::Images, View::Images),
            (Kind::Volumes, View::Volumes),
            (Kind::Networks, View::Networks),
        ] {
            nav = nav.child(
                self.nav_item(
                    format!("nav-{}", kind.as_str()),
                    kind.as_str(),
                    self.t(&format!("nav.{}", kind.as_str())),
                    count(kind),
                    self.view == view,
                    false,
                )
                .on_click(cx.listener(move |this, _, w, cx| this.go(view, w, cx))),
            );
        }
        nav = nav.child(
            self.nav_item(
                "nav-training",
                "tutorials",
                self.t("nav.tutorials"),
                None,
                self.view == View::Training,
                false,
            )
            .on_click(cx.listener(|this, _, w, cx| this.go(View::Training, w, cx))),
        );
        // Kubernetes: the page, a disclosure button and the resources with counts.
        let kube_active = self.view == View::Kubernetes;
        let counts = self.kube.counts;
        let expanded = self.kube.expanded;
        let header = div()
            .flex()
            .items_center()
            .when(rail, |d| d.flex_col())
            .child(
                self.nav_item(
                    "nav-kube-open",
                    "kubernetes",
                    self.t("nav.kubernetes"),
                    counts.map(|c| c.total()),
                    kube_active && !expanded,
                    false,
                )
                .flex_1()
                .on_click(cx.listener(|this, _, w, cx| this.go(View::Kubernetes, w, cx))),
            )
            .child(
                IconButton::new("nav-kube-toggle", "back", self.t("kube.resources"), &t)
                    .rotate(if expanded { -90. } else { 180. })
                    .size(if rail { 24. } else { 30. })
                    .on_click(cx.listener(|this, _, _, cx| {
                        this.kube.expanded = !this.kube.expanded;
                        if this.kube.expanded {
                            this.refresh_kube_counts();
                        }
                        cx.notify();
                    })),
            );
        nav = nav.child(header);
        if expanded {
            let mut sub = div()
                .flex()
                .flex_col()
                .gap(px(2.))
                .mt(px(2.))
                .when(!rail, |d| {
                    d.ml(px(18.)).pl(px(10.)).border_l_1().border_color(t.line)
                });
            for kind in KubeKind::ALL {
                let current = kube_active && detail_free && self.kube.kind == kind;
                sub = sub.child(
                    self.nav_item(
                        format!("nav-kube-{}", kind.as_str()),
                        kube_icon(kind),
                        self.t(&format!("kube.{}", kind.as_str())),
                        counts.map(|c| c.get(kind)),
                        current,
                        true,
                    )
                    .on_click(cx.listener(move |this, _, w, cx| this.go_kube(kind, w, cx))),
                );
            }
            nav = nav.child(sub);
        }
        let bottom = self
            .nav_item(
                "nav-settings",
                "settings",
                self.t("nav.settings"),
                None,
                self.view == View::Settings,
                false,
            )
            .on_click(cx.listener(|this, _, w, cx| this.go(View::Settings, w, cx)));
        let vm_card = self.vm_card(cx);
        let show_engine = vm_card.is_none();
        div()
            .id("sidebar")
            .flex()
            .flex_col()
            .flex_none()
            .w(px(width))
            .h_full()
            .gap(px(4.))
            .py(px(12.))
            .px(px(if rail { 4. } else { 8. }))
            .border_r_1()
            .border_color(t.line)
            .bg(t.page)
            .overflow_y_scroll()
            .child(nav)
            .child(div().flex_1())
            .child(bottom)
            .children(vm_card)
            .when(show_engine, |d| d.child(self.engine_status()))
    }

    fn engine_status(&self) -> Div {
        let t = self.theme;
        let (cls, text) = engine_state(self);
        let name = self
            .engine
            .as_ref()
            .map(|e| e.engine_name.clone())
            .unwrap_or_else(|| "podbag".into());
        let rail = self.sidebar_width() == SIDEBAR_RAIL;
        div()
            .flex()
            .items_center()
            .gap(px(8.))
            .pt(px(10.))
            .px(px(if rail { 0. } else { 10. }))
            .pb(px(2.))
            .mt(px(6.))
            .when(rail, |d| d.justify_center())
            .border_t_1()
            .border_color(t.line)
            .text_color(t.ink2)
            .text_size(px(13.))
            .child(dot(state_color(cls, &t), 8.))
            .when(!rail, |d| {
                d.child(div().min_w_0().child(format!("{name} · {text}")))
            })
    }

    /// app.js `renderVmCard`.
    fn vm_card(&self, cx: &mut Context<Self>) -> Option<AnyElement> {
        let vm = self.vm.as_ref().filter(|_| self.has_vm())?;
        let t = self.theme;
        let lang = self.lang();
        let running = vm.state == "running";
        let stoppable = running || vm.state == "standby" || vm.state == "starting";
        let state_text = self.t(&format!("vm.state.{}", vm_state_key(&vm.state)));
        let on = if running { t.green } else { t.muted };
        if self.sidebar_width() == SIDEBAR_RAIL {
            let label: SharedString = format!("{}: {state_text}", self.t("vm.title")).into();
            return Some(
                div()
                    .relative()
                    .flex()
                    .justify_center()
                    .mt(px(8.))
                    .child(
                        IconButton::new("vm-rail", "vm", label, &t).on_click(cx.listener(
                            |this, _, w, cx| {
                                this.go(View::Settings, w, cx);
                                this.settings_ui.open.insert("vm-settings");
                            },
                        )),
                    )
                    .child(
                        dot(on, 7.)
                            .absolute()
                            .right(px(10.))
                            .bottom(px(3.))
                            .border_2()
                            .border_color(t.page),
                    )
                    .into_any_element(),
            );
        }
        let mut rows: Vec<(SharedString, String)> = Vec::new();
        if vm.containers.is_some() || running {
            rows.push((
                self.t("vm.containers"),
                vm.containers.unwrap_or(0).to_string(),
            ));
        }
        if vm.cpu_percent.is_some() || vm.in_use.is_some() {
            let mut parts = Vec::new();
            if let Some(p) = vm.cpu_percent {
                parts.push(bench_api::fmt::percent(p, lang));
            }
            if let Some(c) = vm.in_use.and_then(|u| u.cpus) {
                parts.push(c.to_string());
            }
            rows.push((self.t("vm.cpu"), parts.join(" · ")));
        }
        let mut meter = None;
        if let Some(total) = vm.memory_total_mib.filter(|m| *m > 0) {
            let used = vm.memory_used_mib.unwrap_or(0);
            rows.push((
                self.t("vm.memory"),
                format!(
                    "{} / {}",
                    bench_api::fmt::mib(Some(used), lang),
                    bench_api::fmt::mib(Some(total), lang)
                ),
            ));
            let frac = (used as f32 / total as f32).min(1.);
            meter = Some(
                div()
                    .h(px(4.))
                    .rounded(px(2.))
                    .bg(t.sunken)
                    .overflow_hidden()
                    .child(
                        div()
                            .h_full()
                            .w(relative(frac))
                            .rounded(px(2.))
                            .bg(t.accent),
                    ),
            );
        }
        let button = if stoppable {
            Button::new("vm-card-stop", self.t("action.stopVm"), &t)
                .on_click(cx.listener(|this, _, _, cx| this.vm_action("stop", cx)))
        } else {
            Button::new("vm-card-start", self.t("action.startVm"), &t)
                .primary()
                .on_click(cx.listener(|this, _, _, cx| this.vm_action("start", cx)))
        };
        Some(
            div()
                .mt(px(8.))
                .pt(px(10.))
                .px(px(12.))
                .pb(px(12.))
                .border_1()
                .border_color(t.line)
                .rounded(px(10.))
                .bg(t.surface)
                .flex()
                .flex_col()
                .gap(px(8.))
                .child(
                    div()
                        .flex()
                        .items_center()
                        .gap(px(7.))
                        .text_size(px(13.))
                        .child(dot(on, 8.))
                        .child(
                            div()
                                .flex_1()
                                .min_w_0()
                                .font_weight(FontWeight::SEMIBOLD)
                                .child(self.t("vm.title")),
                        )
                        .child(
                            div()
                                .text_color(t.ink2)
                                .text_size(px(12.5))
                                .child(state_text),
                        ),
                )
                .when(!rows.is_empty(), |d| {
                    d.child(
                        div()
                            .flex()
                            .flex_col()
                            .gap(px(3.))
                            .text_size(px(12.5))
                            .children(rows.into_iter().map(|(k, v)| {
                                div()
                                    .flex()
                                    .justify_between()
                                    .gap(px(6.))
                                    .child(div().text_color(t.ink2).child(k))
                                    .child(div().child(v))
                            })),
                    )
                })
                .children(meter)
                .child(
                    button
                        .full_width()
                        .disabled(self.vm_busy || vm.state == "not set up"),
                )
                .into_any_element(),
        )
    }

    fn topbar(&self, cx: &mut Context<Self>) -> Div {
        let t = self.theme;
        let collapsed = self.sidebar_width() == SIDEBAR_RAIL;
        let mac = cfg!(target_os = "macos");
        let keys = if mac {
            ["⌘[", "⌘]"]
        } else {
            ["Alt+←", "Alt+→"]
        };
        let toggle_label: SharedString = format!(
            "{} ({})",
            self.t(if collapsed {
                "sidebar.show"
            } else {
                "sidebar.hide"
            }),
            if mac { "⌃⌘S" } else { "Ctrl+B" }
        )
        .into();
        div()
            .flex()
            .flex_none()
            .items_center()
            .gap(px(2.))
            .h(px(40.))
            .px(px(10.))
            .border_b_1()
            .border_color(t.line)
            .bg(t.page)
            .child(
                IconButton::new("sidebar-toggle", "sidebar", toggle_label, &t)
                    .on_click(cx.listener(|this, _, _, cx| this.toggle_sidebar(cx))),
            )
            .child(
                IconButton::new(
                    "nav-back",
                    "back",
                    SharedString::from(format!("{} ({})", self.t("action.back"), keys[0])),
                    &t,
                )
                .disabled(!self.can_travel(-1))
                .on_click(cx.listener(|this, _, w, cx| this.travel(-1, w, cx))),
            )
            .child(
                IconButton::new(
                    "nav-forward",
                    "forward",
                    SharedString::from(format!("{} ({})", self.t("action.forward"), keys[1])),
                    &t,
                )
                .disabled(!self.can_travel(1))
                .on_click(cx.listener(|this, _, w, cx| this.travel(1, w, cx))),
            )
            .child(div().flex_1())
            .child(
                IconButton::new("topbar-settings", "settings", self.t("nav.settings"), &t)
                    .selected(self.view == View::Settings)
                    .on_click(cx.listener(|this, _, w, cx| this.go(View::Settings, w, cx))),
            )
    }

    /// app.js `renderStatusbar`.
    fn statusbar(&self, cx: &mut Context<Self>) -> Div {
        let t = self.theme;
        let lang = self.lang();
        let item = |id: &'static str| {
            div()
                .id(id)
                .flex()
                .flex_none()
                .items_center()
                .gap(px(5.))
                .h(px(20.))
                .px(px(7.))
                .rounded(px(5.))
                .whitespace_nowrap()
        };
        let sep = || div().w(px(1.)).h(px(12.)).bg(t.line).flex_none();
        let mut left = div().flex().items_center().gap(px(2.)).flex_none();
        if let Some(u) = &self.updates {
            left = left.child(item("status-version").child(format!("podbag {}", u.engine)));
        }
        left = left.child(
            item("status-terminal")
                .cursor_pointer()
                .hover(move |s| s.bg(t.hover).text_color(t.ink))
                .child(icon("shell", px(13.), t.ink2))
                .child(self.t("status.terminal"))
                .on_click(cx.listener(|this, _, _, cx| this.open_terminal(cx))),
        );
        let mut right: Vec<AnyElement> = Vec::new();
        let vm = self.vm.as_ref().filter(|_| self.has_vm());
        let (cls, text) = match vm {
            Some(vm) => (
                if vm.state == "running" { "ok" } else { "off" },
                SharedString::from(format!(
                    "{}: {}",
                    self.t("vm.title"),
                    self.t(&format!("vm.state.{}", vm_state_key(&vm.state)))
                )),
            ),
            None => {
                let (cls, text) = engine_state(self);
                let name = self
                    .engine
                    .as_ref()
                    .map(|e| e.engine_name.clone())
                    .unwrap_or_else(|| "podbag".into());
                (cls, SharedString::from(format!("{name}: {text}")))
            }
        };
        right.push(
            item("status-engine")
                .child(dot(state_color(cls, &t), 8.))
                .child(text)
                .into_any_element(),
        );
        if self.loaded {
            let total = self.lists.containers.len();
            let running = self
                .lists
                .containers
                .iter()
                .filter(|c| c.state == "running")
                .count();
            right.push(
                item("status-running")
                    .child(self.tv("status.running", &[("n", &running), ("total", &total)]))
                    .into_any_element(),
            );
        }
        if let Some(total) = vm.and_then(|v| v.memory_total_mib) {
            let used = bench_api::fmt::mib(vm.and_then(|v| v.memory_used_mib).or(Some(0)), lang);
            right.push(
                item("status-memory")
                    .child(format!(
                        "{used} / {}",
                        bench_api::fmt::mib(Some(total), lang)
                    ))
                    .into_any_element(),
            );
        }
        if let Some(d) = &self.docker {
            right.push(self.docker_item(d, cx));
        }
        let mut right_box = div()
            .flex()
            .items_center()
            .justify_end()
            .gap(px(2.))
            .min_w_0()
            .overflow_hidden();
        for (i, el) in right.into_iter().enumerate() {
            if i > 0 {
                right_box = right_box.child(sep());
            }
            right_box = right_box.child(el);
        }
        div()
            .flex()
            .flex_none()
            .items_center()
            .justify_between()
            .gap(px(12.))
            .min_h(px(26.))
            .py(px(2.))
            .px(px(8.))
            .border_t_1()
            .border_color(t.line)
            .bg(t.page)
            .text_size(px(12.))
            .text_color(t.ink2)
            .overflow_hidden()
            .child(left)
            .child(right_box)
    }

    /// images.js `dockerCommandItem`: where `docker` goes.
    fn docker_item(&self, d: &bench_api::DockerCommand, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        if !d.installed {
            return div()
                .child(self.t("docker.missingShort"))
                .into_any_element();
        }
        div()
            .flex()
            .items_center()
            .gap(px(6.))
            .px(px(7.))
            .whitespace_nowrap()
            .child(self.t("docker.command"))
            .child(self.docker_route(d))
            .child(match self.docker_switch_button(d, true, cx) {
                Some(b) => b.size(24.),
                None => IconButton::new(
                    "status-docker-settings",
                    "settings",
                    self.t("nav.settings"),
                    &t,
                )
                .size(24.)
                .on_click(cx.listener(|this, _, w, cx| {
                    this.go(View::Settings, w, cx);
                    this.settings_ui.open.insert("engine-settings");
                })),
            })
            .into_any_element()
    }

    /// images.js `dockerSwitchButton`: point docker at podbag, or back. `confirm`: ask first.
    pub fn docker_switch_button(
        &self,
        d: &bench_api::DockerCommand,
        confirm: bool,
        cx: &mut Context<Self>,
    ) -> Option<IconButton> {
        if d.is_podbag && d.previous.is_none() {
            return None;
        }
        let t = self.theme;
        let previous = d.previous.clone().unwrap_or_default();
        let (symbol, label, to, question) = if d.is_podbag {
            (
                "undo",
                self.tv("docker.back", &[("name", &previous)]),
                "back",
                self.tv("docker.askBack", &[("name", &previous)]),
            )
        } else {
            (
                "switch",
                self.t("docker.use"),
                "use",
                self.tv("docker.askUse", &[("name", &d.name)]),
            )
        };
        let yes = label.clone();
        Some(
            IconButton::new(
                SharedString::from(format!("docker-switch-{confirm}")),
                symbol,
                label,
                &t,
            )
            .disabled(self.docker_switch_to.is_some())
            .on_click(cx.listener(move |this, _, _, cx| {
                if confirm {
                    this.confirm(
                        question.clone(),
                        Some(yes.clone()),
                        crate::widgets::Tone::Primary,
                        cx,
                        move |this, _, _| this.api.docker_switch(to),
                    );
                } else {
                    this.api.docker_switch(to);
                }
            })),
        )
    }

    /// images.js `renderBanner`: docker goes to another engine.
    fn banner(&self, cx: &mut Context<Self>) -> Option<Div> {
        let d = self.docker.as_ref()?;
        if self.banner_closed
            || !d.installed
            || d.is_podbag
            || !self.is_podbag()
            || !self.reachable()
        {
            return None;
        }
        let t = self.theme;
        let message = match &self.docker_switch_to {
            Some(_) => self.docker_route(d).into_any_element(),
            None => div()
                .font_weight(FontWeight::BOLD)
                .truncate()
                .child(self.tv("docker.banner", &[("name", &d.name)]))
                .into_any_element(),
        };
        Some(
            div()
                .flex()
                .flex_none()
                .items_center()
                .gap(px(10.))
                .pl(px(16.))
                .pr(px(10.))
                .py(px(7.))
                .border_t_1()
                .border_color(t.line)
                .bg(t.amber_soft)
                .text_size(px(13.))
                .child(icon("warning", px(18.), t.amber))
                .child(div().flex_1().min_w_0().child(message))
                .children(self.docker_switch_button(d, false, cx))
                .child(
                    IconButton::new("banner-close", "close", self.t("pull.close"), &t).on_click(
                        cx.listener(|this, _, _, cx| {
                            this.banner_closed = true;
                            cx.notify();
                        }),
                    ),
                ),
        )
    }

    /// The docker route: a mark (pending, applied, other) and its text.
    pub fn docker_route(&self, d: &bench_api::DockerCommand) -> Div {
        let t = self.theme;
        let (text, mark): (SharedString, Div) = if let Some(to) = &self.docker_switch_to {
            let name = if to == "use" {
                "podbag".to_string()
            } else {
                d.previous.clone().unwrap_or_else(|| "default".into())
            };
            (
                self.tv("docker.switching", &[("name", &name)]),
                div()
                    .size(px(14.))
                    .rounded_full()
                    .border_2()
                    .border_color(t.accent_text),
            )
        } else if d.is_podbag {
            (
                self.t("docker.applied"),
                div()
                    .flex()
                    .items_center()
                    .justify_center()
                    .size(px(14.))
                    .rounded_full()
                    .bg(t.green)
                    .child(icon("check", px(11.), t.page)),
            )
        } else {
            (
                self.tv("docker.using", &[("name", &d.name)]),
                div()
                    .size(px(14.))
                    .rounded_full()
                    .border_1()
                    .border_color(t.muted),
            )
        };
        div()
            .flex()
            .items_center()
            .gap(px(6.))
            .min_w_0()
            .child(mark.flex_none())
            .child(div().truncate().child(text))
    }

    fn main_page(&mut self, window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        match self.view {
            View::Settings => self.render_settings(window, cx),
            View::Kubernetes => self.render_kubernetes(window, cx),
            View::Migration => self.render_placeholder("migration", "migration.title", cx),
            View::Training => self.render_placeholder("tutorials", "nav.tutorials", cx),
            _ if !self.reachable() => self.render_offline(cx),
            _ if self.detail.is_some() => self.render_detail(window, cx),
            view => self.render_list(view.kind().unwrap(), window, cx),
        }
    }
}

pub fn kube_icon(kind: KubeKind) -> &'static str {
    match kind {
        KubeKind::Pods => "kube-pods",
        KubeKind::Services => "kube-services",
        KubeKind::Deployments => "kube-deployments",
        KubeKind::Claims => "kube-claims",
    }
}

impl Render for Podbag {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        if crate::bench::log_enabled() {
            eprintln!(
                "render at {:.1} ms",
                crate::bench::ms(*crate::bench::T0.get().unwrap())
            );
        }
        let visible = self.lists.visible[0].len();
        self.bench.on_render(window, visible);
        let t = self.theme;
        let dragging = self.sidebar.drag.is_some();
        let main = self.main_page(window, cx);
        let modal = self.render_modal(window, cx);
        let banner = self.banner(cx);
        div()
            .id("podbag")
            .key_context("Podbag")
            .track_focus(&self.focus)
            .size_full()
            .relative()
            .flex()
            .flex_col()
            .bg(t.page)
            .text_color(t.ink)
            .font_family(UI_FONT)
            .text_size(px(14.))
            .line_height(relative(1.45))
            .on_action(cx.listener(|this, _: &Back, w, cx| this.travel(-1, w, cx)))
            .on_action(cx.listener(|this, _: &Forward, w, cx| this.travel(1, w, cx)))
            .on_action(cx.listener(|this, _: &ToggleSidebar, _, cx| this.toggle_sidebar(cx)))
            .on_action(cx.listener(|this, _: &FocusSearch, w, cx| this.focus_search(w, cx)))
            .on_action(cx.listener(|this, _: &Escape, w, cx| this.on_escape(w, cx)))
            .on_action(cx.listener(|this, _: &OpenPull, w, cx| {
                if this.modal.is_none() {
                    this.open_pull(w, cx);
                }
            }))
            .on_action(cx.listener(|this, _: &OpenSettings, w, cx| this.go(View::Settings, w, cx)))
            .when(dragging, |d| {
                d.cursor(CursorStyle::ResizeLeftRight)
                    .on_mouse_move(cx.listener(|this, e: &gpui::MouseMoveEvent, _, cx| {
                        this.drag_sidebar(f32::from(e.position.x), cx)
                    }))
                    .on_mouse_up(
                        MouseButton::Left,
                        cx.listener(|this, _, _, cx| this.end_drag(cx)),
                    )
            })
            .on_mouse_down(
                MouseButton::Navigate(gpui::NavigationDirection::Back),
                cx.listener(|this, _, w, cx| this.travel(-1, w, cx)),
            )
            .on_mouse_down(
                MouseButton::Navigate(gpui::NavigationDirection::Forward),
                cx.listener(|this, _, w, cx| this.travel(1, w, cx)),
            )
            .child(self.topbar(cx))
            .child(
                div()
                    .flex()
                    .flex_1()
                    .min_h_0()
                    .child(self.sidebar(cx))
                    .child(
                        div()
                            .id("splitter")
                            .w(px(5.))
                            .ml(px(-3.))
                            .h_full()
                            .flex_none()
                            .cursor(CursorStyle::ResizeLeftRight)
                            .when(dragging, |d| d.bg(t.accent))
                            .hover(move |s| s.bg(t.accent))
                            .on_mouse_down(
                                MouseButton::Left,
                                cx.listener(|this, e: &gpui::MouseDownEvent, _, cx| {
                                    let w = this.sidebar_width();
                                    this.sidebar.drag = Some((f32::from(e.position.x), w, w));
                                    cx.notify();
                                }),
                            )
                            .on_click(cx.listener(|this, e: &gpui::ClickEvent, _, cx| {
                                if e.click_count() == 2 {
                                    this.sidebar.collapsed = false;
                                    this.sidebar.width = 216.;
                                    this.save_settings();
                                    cx.notify();
                                }
                            })),
                    )
                    .child(
                        div()
                            .flex()
                            .flex_col()
                            .flex_1()
                            .min_w_0()
                            .h_full()
                            .bg(t.page)
                            .child(div().flex().flex_col().flex_1().min_h_0().child(main))
                            .children(banner),
                    ),
            )
            .child(self.statusbar(cx))
            .children(self.toasts.render(&t))
            .children(modal)
    }
}
