//! Containers: columns, cells, actions (start, stop, restart, pause, logs, shell,
//! rename), the Info fields with top and stats, and the rename dialog.

use std::rc::Rc;

use bench_api::Kind;
use gpui::{AnyElement, Context, FontWeight, SharedString, Window, div, prelude::*, px};

use crate::app::*;
use crate::theme::MONO;
use crate::views::resources::Width;
use crate::widgets::fields::Fields;
use crate::widgets::table::Column;
use crate::widgets::{IconButton, IconTone};

impl Podbag {
    pub fn container_columns(&self, w: Width) -> Vec<Column> {
        let mut cols = vec![
            Column::flex(self.t("col.name")),
            Column::flex(self.t("col.image")),
            Column::fixed(self.t("col.state"), 128.),
        ];
        if w > Width::Narrow {
            cols.push(Column::fixed(self.t("col.ports"), 130.));
        }
        if w > Width::Medium {
            cols.push(Column::fixed(self.t("col.created"), 124.));
        }
        cols
    }

    pub fn container_cells(&self, i: usize, w: Width) -> Vec<AnyElement> {
        let t = self.theme;
        let c = &self.lists.containers[i];
        let mut cells = vec![
            div()
                .w_full()
                .child(
                    div()
                        .truncate()
                        .font_weight(FontWeight::SEMIBOLD)
                        .child(c.name().to_string()),
                )
                .child(
                    div()
                        .truncate()
                        .text_size(px(12.))
                        .text_color(t.ink2)
                        .font_family(MONO)
                        .child(bench_api::short_id(&c.id).to_string()),
                )
                .into_any_element(),
            div().truncate().child(c.image.clone()).into_any_element(),
            div()
                .flex()
                .child(self.state_chip(&c.state))
                .into_any_element(),
        ];
        if w > Width::Narrow {
            let ports = c.ports_text();
            let ports = if ports.is_empty() {
                "—".to_string()
            } else {
                ports
            };
            cells.push(
                div()
                    .truncate()
                    .font_family(MONO)
                    .text_size(px(12.5))
                    .child(ports)
                    .into_any_element(),
            );
        }
        if w > Width::Medium {
            cells.push(
                div()
                    .truncate()
                    .text_color(t.ink2)
                    .child(self.ago(c.created))
                    .into_any_element(),
            );
        }
        cells
    }

    /// The container's buttons before Remove. In the detail page Logs is a tab instead,
    /// and Rename joins when the engine can rename.
    pub fn container_actions(
        &self,
        i: usize,
        in_detail: bool,
        cx: &mut Context<Self>,
    ) -> Vec<IconButton> {
        let t = self.theme;
        let c = &self.lists.containers[i];
        let id = c.id.clone();
        let mut out = Vec::new();
        let act = |name: &'static str,
                   symbol: &'static str,
                   key: &str,
                   tone: IconTone,
                   cx: &mut Context<Self>| {
            let id = id.clone();
            IconButton::new(
                SharedString::from(format!("{name}-{id}")),
                symbol,
                self.t(key),
                &t,
            )
            .tone(tone)
            .on_click(cx.listener(move |this, _, _, cx| this.act(id.clone(), name, cx)))
        };
        match c.state.as_str() {
            "running" | "restarting" => {
                out.push(act("stop", "stop", "action.stop", IconTone::Normal, cx));
                out.push(act(
                    "restart",
                    "restart",
                    "action.restart",
                    IconTone::Normal,
                    cx,
                ));
                if self.features.pause {
                    out.push(act("pause", "pause", "action.pause", IconTone::Normal, cx));
                }
            }
            "paused" => {
                if self.features.pause {
                    out.push(act(
                        "unpause",
                        "start",
                        "action.resume",
                        IconTone::Normal,
                        cx,
                    ));
                }
                out.push(act("stop", "stop", "action.stop", IconTone::Normal, cx));
            }
            _ => out.push(act("start", "start", "action.start", IconTone::Accent, cx)),
        }
        if !in_detail {
            let lid = id.clone();
            out.push(
                IconButton::new(
                    SharedString::from(format!("logs-{id}")),
                    "logs",
                    self.t("action.logs"),
                    &t,
                )
                .on_click(cx.listener(move |this, _, w, cx| {
                    this.open_detail(Kind::Containers, lid.clone(), DetailTab::Logs, w, cx)
                })),
            );
        }
        if c.state == "running" {
            let sid = id.clone();
            out.push(
                IconButton::new(
                    SharedString::from(format!("shell-{id}")),
                    "shell",
                    self.t("action.shell"),
                    &t,
                )
                .on_click(cx.listener(move |this, _, _, cx| this.shell(sid.clone(), cx))),
            );
        }
        if in_detail && self.features.rename {
            let rid = id.clone();
            out.push(
                IconButton::new(
                    SharedString::from(format!("rename-{id}")),
                    "rename",
                    self.t("action.rename"),
                    &t,
                )
                .on_click(cx.listener(move |this, _, w, cx| this.rename(rid.clone(), w, cx))),
            );
        }
        out
    }

    pub fn container_info(&self, i: usize) -> Fields {
        let c = &self.lists.containers[i];
        let none = self.tr.t("detail.none");
        Fields::new(&self.theme)
            .text(self.t("col.id"), c.id.clone(), &none, true)
            .text(self.t("col.image"), c.image.clone(), &none, false)
            .text(self.t("detail.command"), c.command.clone(), &none, true)
            .text(self.t("detail.status"), c.status.clone(), &none, false)
            .text(self.t("col.ports"), c.ports_text(), &none, false)
            .text(self.t("col.created"), self.ago(c.created), &none, false)
    }

    /// The processes and usage of a running container, when the engine has them.
    pub fn load_extra(&mut self, _cx: &mut Context<Self>) {
        let Some(d) = &self.detail else { return };
        if d.kind != Kind::Containers {
            return;
        }
        let Some(i) = self.lists.find(Kind::Containers, &d.id) else {
            return;
        };
        if self.lists.containers[i].state != "running" {
            return;
        }
        let id = d.id.clone();
        let mut extra = Vec::new();
        for (on, what, key) in [
            (self.features.top, "top", "detail.processes"),
            (self.features.stats, "stats", "detail.usage"),
        ] {
            if on {
                let text = match self.api.container_json(&id, what) {
                    Ok(v) => bench_api::pretty_json(&v),
                    Err(e) => e,
                };
                extra.push((key, SharedString::from(text)));
            }
        }
        if let Some(d) = &mut self.detail {
            d.extra = extra;
        }
    }

    /// app.js `rename`.
    pub fn rename(&mut self, id: String, window: &mut Window, cx: &mut Context<Self>) {
        let Some(i) = self.lists.find(Kind::Containers, &id) else {
            return;
        };
        let name = self.lists.containers[i].name().to_string();
        let work: AskWork = Rc::new(move |this, name, _, cx| {
            this.api.rename(&id, &name)?;
            let msg = this.tv("done.rename", &[("name", &name)]);
            this.toast(msg, false, cx);
            this.refresh_soon(cx);
            Ok(())
        });
        self.ask(
            self.t("rename.title"),
            self.t("rename.label"),
            &name,
            "",
            self.t("action.rename"),
            window,
            cx,
            work,
        );
    }
}
