//! `dialog`: a modal window over a dimmed backdrop, and its parts.

use std::rc::Rc;

use gpui::{
    AnyElement, App, ClickEvent, Div, FontWeight, SharedString, Window, div, prelude::*, px,
};

use crate::theme::Theme;

/// Where the dialog sits.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Place {
    Center,
    /// The pull panel: near the top right corner.
    TopRight,
}

#[derive(IntoElement)]
pub struct Modal {
    body: AnyElement,
    width: f32,
    place: Place,
    t: Theme,
    on_dismiss: Option<Rc<dyn Fn(&ClickEvent, &mut Window, &mut App)>>,
}

impl Modal {
    pub fn new(body: impl IntoElement, t: &Theme) -> Self {
        Self {
            body: body.into_any_element(),
            width: 440.,
            place: Place::Center,
            t: *t,
            on_dismiss: None,
        }
    }

    pub fn width(mut self, w: f32) -> Self {
        self.width = w;
        self
    }

    pub fn place(mut self, place: Place) -> Self {
        self.place = place;
        self
    }

    /// A click on the backdrop.
    pub fn on_dismiss(mut self, f: impl Fn(&ClickEvent, &mut Window, &mut App) + 'static) -> Self {
        self.on_dismiss = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Modal {
    fn render(self, window: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let vp = window.viewport_size();
        let width = self.width.min(f32::from(vp.width) - 48.);
        let max_h = f32::from(vp.height)
            - if self.place == Place::TopRight {
                104.
            } else {
                48.
            };
        let dismiss = self.on_dismiss;
        let panel = div()
            .id("modal-panel")
            .occlude()
            .w(px(width))
            .max_h(px(max_h.min(if self.place == Place::TopRight {
                560.
            } else {
                10_000.
            })))
            .flex()
            .flex_col()
            .bg(t.surface)
            .text_color(t.ink)
            .border_1()
            .border_color(t.line)
            .rounded(px(12.))
            .shadow_lg()
            .overflow_hidden()
            .on_click(|_, _, cx| cx.stop_propagation())
            .child(self.body);
        div()
            .id("modal-backdrop")
            .occlude()
            .absolute()
            .inset_0()
            .flex()
            .bg(t.backdrop)
            .map(|d| match self.place {
                Place::Center => d.items_center().justify_center(),
                Place::TopRight => d.items_start().justify_end().pt(px(72.)).pr(px(24.)),
            })
            .when_some(dismiss, |d, f| d.on_click(move |e, w, cx| f(e, w, cx)))
            .child(panel)
    }
}

/// `dialog form`: the padded column of a simple dialog.
pub fn form(t: &Theme) -> Div {
    let _ = t;
    div()
        .flex()
        .flex_col()
        .gap(px(10.))
        .pt(px(20.))
        .px(px(22.))
        .pb(px(18.))
}

/// `dialog h2`.
pub fn title(text: impl Into<SharedString>) -> Div {
    div()
        .text_size(px(16.))
        .font_weight(FontWeight::BOLD)
        .child(text.into())
}

/// `dialog p`.
pub fn text(content: impl Into<SharedString>, t: &Theme) -> Div {
    div().text_color(t.ink2).child(content.into())
}

/// `.buttons`: the right-aligned button row.
pub fn buttons() -> Div {
    div()
        .flex()
        .justify_end()
        .flex_wrap()
        .gap(px(8.))
        .mt(px(6.))
}
