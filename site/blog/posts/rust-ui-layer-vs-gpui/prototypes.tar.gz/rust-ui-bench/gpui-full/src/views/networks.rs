//! Networks: columns, cells (built-in networks get a tag and no Remove) and the
//! Info fields.

use gpui::{AnyElement, FontWeight, div, prelude::*, px};

use crate::app::*;
use crate::theme::MONO;
use crate::views::resources::Width;
use crate::widgets::chip::tag;
use crate::widgets::fields::Fields;
use crate::widgets::table::Column;

impl Podbag {
    pub fn network_columns(&self, w: Width) -> Vec<Column> {
        let mut cols = vec![
            Column::flex(self.t("col.name")),
            Column::fixed(self.t("col.driver"), 110.),
            Column::flex(self.t("col.subnet")),
        ];
        if w > Width::Narrow {
            cols.push(Column::fixed(self.t("col.id"), 130.));
        }
        cols
    }

    pub fn network_cells(&self, i: usize, w: Width) -> Vec<AnyElement> {
        let t = self.theme;
        let n = &self.lists.networks[i];
        let subnet = if n.subnet().is_empty() {
            "—".to_string()
        } else {
            n.subnet().to_string()
        };
        let mut cells = vec![
            div()
                .flex()
                .items_center()
                .gap(px(8.))
                .w_full()
                .min_w_0()
                .child(
                    div()
                        .truncate()
                        .font_weight(FontWeight::SEMIBOLD)
                        .child(n.name.clone()),
                )
                .when(n.builtin(), |d| {
                    d.child(tag(self.t("state.builtin"), t.ink2, t.gray_soft))
                })
                .into_any_element(),
            div().child(n.driver.clone()).into_any_element(),
            div()
                .truncate()
                .font_family(MONO)
                .text_size(px(12.5))
                .child(subnet)
                .into_any_element(),
        ];
        if w > Width::Narrow {
            cells.push(
                div()
                    .truncate()
                    .font_family(MONO)
                    .text_size(px(12.5))
                    .text_color(t.ink2)
                    .child(bench_api::short_id(&n.id).to_string())
                    .into_any_element(),
            );
        }
        cells
    }

    pub fn network_info(&self, i: usize) -> Fields {
        let n = &self.lists.networks[i];
        let none = self.tr.t("detail.none");
        Fields::new(&self.theme)
            .text(self.t("col.id"), n.id.clone(), &none, true)
            .text(self.t("col.driver"), n.driver.clone(), &none, false)
            .text(self.t("col.subnet"), n.subnet().to_string(), &none, true)
            .text(
                self.t("detail.gateway"),
                n.gateway().to_string(),
                &none,
                true,
            )
            .text(self.t("detail.scope"), n.scope.clone(), &none, false)
    }
}
