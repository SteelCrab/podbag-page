//! What the four engine lists share (app.js): the toolbar, the table, the empty and
//! offline pages, and the detail page with its Info, Logs and Inspect tabs.
//! The columns, cells and actions of each kind are in containers.rs, images.rs, …

use bench_api::Kind;
use gpui::{
    AnyElement, Context, Div, Entity, Focusable, FontWeight, ImageSource, SharedString, Window,
    div, img, prelude::*, px,
};

use crate::app::*;
use crate::icons::icon;
use crate::widgets::chip::{chip, dot};
use crate::widgets::code::{code_line, pre};
use crate::widgets::table::{self, Column};
use crate::widgets::tabs::{Tab, tab_bar};
use crate::widgets::{Button, Checkbox, IconButton, TextInput};

/// How narrow the window is (style.css media queries at 1060 and 880 px).
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Width {
    Narrow,
    Medium,
    Wide,
}

pub fn width_class(window: &Window) -> Width {
    let w = f32::from(window.viewport_size().width);
    if w <= 880. {
        Width::Narrow
    } else if w <= 1060. {
        Width::Medium
    } else {
        Width::Wide
    }
}

/// The page title bar (`header.toolbar`).
pub fn toolbar(t: &crate::theme::Theme) -> Div {
    div()
        .flex()
        .flex_none()
        .items_center()
        .gap(px(12.))
        .min_h(px(62.))
        .px(px(20.))
        .py(px(14.))
        .border_b_1()
        .border_color(t.line)
}

/// `h1`.
pub fn heading(text: impl Into<SharedString>) -> Div {
    div()
        .flex_none()
        .text_size(px(18.))
        .font_weight(FontWeight::BOLD)
        .mr(px(12.))
        .child(text.into())
}

/// `.search-box`: a search icon and the input.
pub fn search_box(input: &Entity<TextInput>, focused: bool, t: &crate::theme::Theme) -> Div {
    div()
        .flex()
        .items_center()
        .gap(px(6.))
        .flex_shrink()
        .w(px(280.))
        .min_w(px(120.))
        .px(px(10.))
        .h(px(32.))
        .border_1()
        .border_color(if focused { t.accent } else { t.line })
        .rounded(px(7.))
        .bg(t.surface)
        .child(icon("search", px(18.), t.muted))
        .child(div().flex_1().min_w_0().child(input.clone()))
}

/// `.content`: the scrolling page body.
pub fn content() -> Div {
    div()
        .flex()
        .flex_col()
        .flex_1()
        .min_h_0()
        .px(px(20.))
        .pt(px(8.))
        .pb(px(24.))
}

impl Podbag {
    pub fn columns(&self, kind: Kind, w: Width) -> (Vec<Column>, f32, f32) {
        match kind {
            Kind::Containers => (self.container_columns(w), 164., 57.),
            Kind::Images => (self.image_columns(w), 56., 39.),
            Kind::Volumes => (self.volume_columns(), 56., 39.),
            Kind::Networks => (self.network_columns(w), 56., 39.),
        }
    }

    fn cells(&self, kind: Kind, i: usize, w: Width) -> Vec<AnyElement> {
        match kind {
            Kind::Containers => self.container_cells(i, w),
            Kind::Images => self.image_cells(i, w),
            Kind::Volumes => self.volume_cells(i),
            Kind::Networks => self.network_cells(i, w),
        }
    }

    /// app.js `rowActions`: icon buttons, all disabled while the object is busy.
    pub fn row_actions(
        &self,
        kind: Kind,
        i: usize,
        in_detail: bool,
        cx: &mut Context<Self>,
    ) -> Div {
        let t = self.theme;
        let id = self.lists.id(kind, i).to_string();
        let busy = self.busy.contains(&id);
        let mut out: Vec<IconButton> = match kind {
            Kind::Containers => self.container_actions(i, in_detail, cx),
            _ => Vec::new(),
        };
        let builtin = kind == Kind::Networks && self.lists.networks[i].builtin();
        if !builtin {
            let rid = id.clone();
            out.push(
                IconButton::new(
                    SharedString::from(format!("remove-{id}")),
                    "remove",
                    self.t("action.remove"),
                    &t,
                )
                .tone(crate::widgets::IconTone::Danger)
                .on_click(cx.listener(move |this, _, _, cx| this.remove(kind, rid.clone(), cx))),
            );
        }
        div()
            .flex()
            .justify_end()
            .gap(px(2.))
            .children(out.into_iter().map(|b| b.disabled(busy)))
    }

    /// The list page of a kind.
    pub fn render_list(
        &mut self,
        kind: Kind,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> AnyElement {
        let t = self.theme;
        let input = self.search[kind_ix(kind)].clone();
        let focused = input.read(cx).focus_handle(cx).is_focused(window);
        let live = div()
            .flex()
            .items_center()
            .gap(px(6.))
            .text_size(px(12.5))
            .text_color(if self.live { t.green } else { t.muted })
            .child(dot(if self.live { t.green } else { t.muted }, 8.))
            .when(self.live && width_class(window) != Width::Narrow, |d| {
                d.child(self.t("live.on"))
            });
        let mut tools = div()
            .ml_auto()
            .flex()
            .flex_none()
            .items_center()
            .gap(px(8.))
            .child(live);
        if kind == Kind::Images
            && self.is_podbag()
            && self.docker.as_ref().is_some_and(|d| d.installed)
        {
            tools = tools.child(
                Button::new("import", self.t("import.button"), &t)
                    .icon("import")
                    .on_click(cx.listener(|this, _, _, cx| this.open_import(cx))),
            );
        }
        if kind == Kind::Images {
            tools = tools.child(
                Button::new("pull", self.t("action.pull"), &t)
                    .icon("pull")
                    .primary()
                    .on_click(cx.listener(|this, _, w, cx| this.open_pull(w, cx))),
            );
        }
        if kind == Kind::Volumes {
            tools = tools.child(
                Button::new("create-volume", self.t("volume.create"), &t)
                    .primary()
                    .on_click(cx.listener(|this, _, w, cx| this.create_volume(w, cx))),
            );
        }
        tools = tools
            .child(
                Button::new("prune", self.t("action.prune"), &t)
                    .icon("prune")
                    .on_click(cx.listener(move |this, _, _, cx| this.prune(kind, cx))),
            )
            .child(
                IconButton::new("refresh", "refresh", self.t("action.refresh"), &t)
                    .on_click(cx.listener(|this, _, _, cx| this.refresh(cx))),
            );
        let bar = toolbar(&t)
            .child(heading(self.t(&format!("nav.{}", kind.as_str()))))
            .child(search_box(&input, focused, &t))
            .child(tools);
        div()
            .flex()
            .flex_col()
            .size_full()
            .child(bar)
            .child(self.list_content(kind, window, cx))
            .into_any_element()
    }

    fn list_content(
        &mut self,
        kind: Kind,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> AnyElement {
        let t = self.theme;
        let ix = kind_ix(kind);
        if !self.loaded {
            return content()
                .child(
                    div()
                        .py(px(24.))
                        .px(px(10.))
                        .text_color(t.ink2)
                        .child(self.t("engine.checking")),
                )
                .into_any_element();
        }
        if let Some(e) = &self.list_errors[ix] {
            return content()
                .child(div().text_color(t.red).child(e.clone()))
                .child(
                    div().child(
                        Button::new("retry", self.t("action.retry"), &t)
                            .icon("refresh")
                            .on_click(cx.listener(|this, _, _, cx| this.refresh(cx))),
                    ),
                )
                .into_any_element();
        }
        if self.lists.len(kind) == 0 {
            return self.empty_state(kind, cx);
        }
        let count = self.lists.visible[ix].len();
        if count == 0 {
            let q = self.queries[ix].trim().to_string();
            return content()
                .child(
                    div()
                        .py(px(24.))
                        .px(px(10.))
                        .text_color(t.ink2)
                        .child(self.tv("empty.search", &[("q", &q)])),
                )
                .into_any_element();
        }
        let w = width_class(window);
        let (cols, actions_w, height) = self.columns(kind, w);
        let header = table::header(&cols, Some(actions_w), &t);
        let body = table::body(
            SharedString::from(format!("rows-{}", kind.as_str())),
            count,
            &self.scroll[ix],
            cx.processor(move |this, range: std::ops::Range<usize>, window, cx| {
                let w = width_class(window);
                let (cols, actions_w, height) = this.columns(kind, w);
                range
                    .map(|row| {
                        let i = this.lists.visible[ix][row];
                        let id = this.lists.id(kind, i).to_string();
                        let actions = this.row_actions(kind, i, false, cx).into_any_element();
                        table::row(
                            SharedString::from(format!("row-{id}")),
                            &cols,
                            this.cells(kind, i, w),
                            Some((actions_w, actions)),
                            height,
                            &this.theme,
                        )
                        .on_click(cx.listener(move |this, _, w, cx| {
                            this.open_detail(kind, id.clone(), DetailTab::Info, w, cx)
                        }))
                    })
                    .collect::<Vec<_>>()
            }),
        );
        let _ = height;
        content().child(header).child(body).into_any_element()
    }

    /// app.js `emptyState`.
    fn empty_state(&mut self, kind: Kind, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let podbag = self.is_podbag();
        let docker = self.engine.as_ref().is_some_and(|e| e.engine == "docker");
        let cmd = if podbag { "podbag" } else { "docker" };
        let command = match kind {
            Kind::Containers => Some(format!("{cmd} run -d --name web -p 8080:80 nginx:alpine")),
            Kind::Volumes => Some(format!("{cmd} volume create data")),
            Kind::Networks => Some(format!("{cmd} network create app")),
            Kind::Images => None,
        };
        let mut page = empty_page()
            .child(
                div()
                    .flex()
                    .items_center()
                    .justify_center()
                    .size(px(64.))
                    .rounded(px(16.))
                    .bg(t.accent_soft)
                    .child(icon(kind.as_str(), px(32.), t.accent_text)),
            )
            .child(
                div()
                    .mt(px(12.))
                    .mb(px(2.))
                    .text_size(px(18.))
                    .font_weight(FontWeight::BOLD)
                    .child(self.t(&format!("empty.{}.title", kind.as_str()))),
            );
        if podbag || docker || kind == Kind::Images {
            page = page.child(
                div()
                    .my(px(4.))
                    .text_color(t.ink2)
                    .child(self.t(&format!("empty.{}.text", kind.as_str()))),
            );
        }
        if let Some(c) = command.filter(|_| podbag || docker) {
            page = page.child(self.code(format!("empty-{}", kind.as_str()), c, cx));
        }
        if kind == Kind::Images {
            page = page.child(
                div().mt(px(14.)).child(
                    Button::new("empty-pull", self.t("action.pull"), &t)
                        .icon("pull")
                        .primary()
                        .on_click(cx.listener(|this, _, w, cx| this.open_pull(w, cx))),
                ),
            );
        }
        div().flex_1().child(page).into_any_element()
    }

    /// A command with a copy button that says "Copied".
    pub fn code(&self, id: String, text: String, cx: &mut Context<Self>) -> Div {
        let entity = cx.entity().downgrade();
        code_line(
            SharedString::from(id),
            text,
            self.t("action.copy"),
            &self.theme,
            move |_, cx| {
                let _ = entity.update(cx, |this, cx| {
                    let msg = this.t("action.copied");
                    this.toast(msg, false, cx);
                });
            },
        )
    }

    /// app.js `offline`: the engine does not answer.
    pub fn render_offline(&mut self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let e = self
            .engine
            .clone()
            .unwrap_or_else(|| bench_api::EngineInfo {
                platform: "linux".into(),
                engine: "podbag".into(),
                engine_name: "podbag".into(),
                shell: false,
                endpoint: String::new(),
                reachable: false,
                vm: None,
                version: None,
                error: None,
            });
        let title = |text: SharedString| {
            div()
                .mt(px(12.))
                .mb(px(2.))
                .text_size(px(18.))
                .font_weight(FontWeight::BOLD)
                .child(text)
        };
        let para = |text: SharedString| div().my(px(4.)).text_color(t.ink2).child(text);
        let logo = || {
            img(ImageSource::Resource(gpui::Resource::Embedded(
                "logo-small.png".into(),
            )))
            .size(px(72.))
        };
        let retry = Button::new("retry", self.t("action.retry"), &t)
            .icon("refresh")
            .primary()
            .on_click(cx.listener(|this, _, _, cx| this.connect(false, cx)));
        let mut page = empty_page();
        if e.engine == "docker" {
            page = page
                .child(
                    div()
                        .flex()
                        .items_center()
                        .justify_center()
                        .size(px(64.))
                        .rounded(px(16.))
                        .bg(t.accent_soft)
                        .child(icon("engine", px(32.), t.accent_text)),
                )
                .child(title(self.t("offline.dockerTitle")));
            page = if e.platform == "linux" {
                page.child(para(self.t("offline.dockerLinux")))
                    .child(self.code(
                        "offline-docker".into(),
                        "sudo systemctl start docker".into(),
                        cx,
                    ))
            } else {
                page.child(para(self.t("offline.dockerText")))
            };
            let switch = Button::new(
                "use-podbag",
                self.tv("switch.to", &[("name", &"podbag")]),
                &t,
            )
            .on_click(cx.listener(|this, _, w, cx| this.switch_engine("podbag".into(), w, cx)));
            return div()
                .flex_1()
                .child(
                    page.child(
                        div()
                            .flex()
                            .gap(px(8.))
                            .mt(px(14.))
                            .child(retry)
                            .child(switch),
                    ),
                )
                .into_any_element();
        }
        if !self.connection.local {
            return div()
                .flex_1()
                .child(
                    page.child(title(self.t("engine.down")))
                        .child(
                            div()
                                .text_color(t.red)
                                .font_family(crate::theme::MONO)
                                .text_size(px(12.5))
                                .child(e.error.clone().unwrap_or(e.endpoint.clone())),
                        )
                        .child(div().mt(px(14.)).child(retry)),
                )
                .into_any_element();
        }
        let vm_off = e.error.as_deref() == Some("vm-stopped")
            || e.vm.as_deref().is_some_and(|v| v != "running");
        if vm_off {
            let start = Button::new("start-vm", self.t("action.startVm"), &t)
                .icon("start")
                .primary()
                .disabled(self.vm_busy)
                .on_click(cx.listener(|this, _, _, cx| {
                    this.vm_busy = true;
                    this.connect(true, cx);
                    this.vm_busy = false;
                }));
            return div()
                .flex_1()
                .child(
                    page.child(logo())
                        .child(title(self.t("offline.vmTitle")))
                        .child(para(self.t("offline.vmText")))
                        .child(div().mt(px(14.)).child(start)),
                )
                .into_any_element();
        }
        let hint = if e.platform == "linux" {
            "podbag system service"
        } else {
            "podbag vm start"
        };
        page = page
            .child(logo())
            .child(title(self.t("offline.title")))
            .child(para(self.t("offline.text")));
        if let Some(err) = e.error.as_ref().filter(|e| *e != "vm-stopped") {
            page = page.child(
                div()
                    .my(px(4.))
                    .text_color(t.red)
                    .font_family(crate::theme::MONO)
                    .text_size(px(12.5))
                    .child(err.clone()),
            );
        }
        page = page
            .child(para(self.t("offline.hint")))
            .child(self.code("offline-hint".into(), hint.into(), cx))
            .child(div().mt(px(14.)).child(retry));
        div().flex_1().child(page).into_any_element()
    }

    /// app.js `renderDetail`: the header, the tabs and the chosen panel.
    pub fn render_detail(&mut self, window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let Some(d) = &self.detail else {
            return div().into_any_element();
        };
        let (kind, tab) = (d.kind, d.tab);
        let Some(i) = self.lists.find(kind, &d.id) else {
            return div().into_any_element();
        };
        let name: SharedString = self.lists.name(kind, i).to_string().into();
        let mut bar = toolbar(&t)
            .child(
                div().ml(px(-8.)).child(
                    IconButton::new("detail-back", "back", self.t("action.back"), &t)
                        .on_click(cx.listener(|this, _, _, cx| this.close_detail(false, cx))),
                ),
            )
            .child(heading(name));
        if kind == Kind::Containers {
            let state = self.lists.containers[i].state.clone();
            bar = bar.child(self.state_chip(&state));
        }
        bar = bar.child(div().ml_auto().child(self.row_actions(kind, i, true, cx)));
        let tabs: &[DetailTab] = if kind == Kind::Containers {
            &[DetailTab::Info, DetailTab::Logs, DetailTab::Inspect]
        } else {
            &[DetailTab::Info, DetailTab::Inspect]
        };
        let tab_row = tab_bar(
            &t,
            tabs.iter().map(|&tb| {
                let key = match tb {
                    DetailTab::Info => "detail.info",
                    DetailTab::Logs => "detail.logs",
                    DetailTab::Inspect => "detail.inspect",
                };
                Tab::new(
                    SharedString::from(format!("tab-{key}")),
                    self.t(key),
                    tb == tab,
                    &t,
                )
                .on_click(cx.listener(move |this, _, w, cx| this.set_tab(tb, w, cx)))
            }),
            None,
        );
        let panel: AnyElement = match tab {
            DetailTab::Info => {
                let fields = match kind {
                    Kind::Containers => self.container_info(i),
                    Kind::Images => self.image_info(i),
                    Kind::Volumes => self.volume_info(i),
                    Kind::Networks => self.network_info(i),
                };
                let extra = self
                    .detail
                    .as_ref()
                    .map(|d| d.extra.clone())
                    .unwrap_or_default();
                div()
                    .id("info-panel")
                    .flex_1()
                    .min_h_0()
                    .overflow_y_scroll()
                    .pt(px(18.))
                    .px(px(20.))
                    .pb(px(24.))
                    .child(fields)
                    .children(extra.into_iter().enumerate().flat_map(|(n, (key, text))| {
                        [
                            div()
                                .mt(px(22.))
                                .mb(px(8.))
                                .font_weight(FontWeight::BOLD)
                                .child(self.t(key))
                                .into_any_element(),
                            pre(("extra", n), text, &t)
                                .max_h(px(260.))
                                .into_any_element(),
                        ]
                    }))
                    .into_any_element()
            }
            DetailTab::Logs => {
                let follow = self
                    .logs
                    .as_ref()
                    .map(|(_, v)| v.read(cx).follow)
                    .unwrap_or(true);
                let view = self.logs.as_ref().map(|(_, v)| v.clone());
                div()
                    .flex()
                    .flex_col()
                    .flex_1()
                    .min_h_0()
                    .gap(px(8.))
                    .pt(px(18.))
                    .px(px(20.))
                    .pb(px(24.))
                    .child(
                        div().flex().justify_end().child(
                            Checkbox::new("follow", follow, &t)
                                .label(self.t("action.follow"))
                                .on_toggle(cx.listener(|this, on: &bool, _, cx| {
                                    if let Some((_, v)) = &this.logs {
                                        let on = *on;
                                        v.update(cx, |v, cx| v.set_follow(on, cx));
                                    }
                                })),
                        ),
                    )
                    .children(view)
                    .into_any_element()
            }
            DetailTab::Inspect => {
                let text = self
                    .detail
                    .as_ref()
                    .and_then(|d| d.inspect.clone())
                    .unwrap_or_default();
                div()
                    .flex()
                    .flex_col()
                    .flex_1()
                    .min_h_0()
                    .pt(px(18.))
                    .px(px(20.))
                    .pb(px(24.))
                    .child(pre("inspect", text, &t))
                    .into_any_element()
            }
        };
        let _ = window;
        div()
            .flex()
            .flex_col()
            .size_full()
            .child(bar)
            .child(tab_row)
            .child(panel)
            .into_any_element()
    }

    /// app.js `stateChip`.
    pub fn state_chip(&self, state: &str) -> Div {
        let known = [
            "running",
            "exited",
            "created",
            "paused",
            "restarting",
            "dead",
        ];
        let s = if known.contains(&state) {
            state
        } else {
            "created"
        };
        chip(s, self.t(&format!("state.{s}")), &self.theme)
    }
}

/// `.empty`: a centred column.
pub fn empty_page() -> Div {
    div()
        .flex()
        .flex_col()
        .items_center()
        .gap(px(4.))
        .max_w(px(520.))
        .mx_auto()
        .my(px(56.))
        .text_center()
}
