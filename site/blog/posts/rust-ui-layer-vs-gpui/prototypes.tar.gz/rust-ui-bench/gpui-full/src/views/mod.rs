//! The pages. Each file adds an `impl Podbag` block for one area.

pub mod containers;
pub mod dialogs;
pub mod images;
pub mod kubernetes;
pub mod networks;
pub mod placeholder;
pub mod pull;
pub mod resources;
pub mod settings;
pub mod volumes;
