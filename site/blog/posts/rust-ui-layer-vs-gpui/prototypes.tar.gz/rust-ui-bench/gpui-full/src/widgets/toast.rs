//! `.toasts`: short messages in the bottom right corner. They go after 4 s (8 s for errors).

use std::time::{Duration, Instant};

use gpui::{Div, SharedString, div, prelude::*, px};

use crate::theme::Theme;

pub struct Toast {
    pub text: SharedString,
    pub error: bool,
    pub until: Instant,
}

#[derive(Default)]
pub struct Toasts {
    pub items: Vec<Toast>,
}

impl Toasts {
    /// Add one; returns how long it stays.
    pub fn push(&mut self, text: impl Into<SharedString>, error: bool) -> Duration {
        let stay = Duration::from_secs(if error { 8 } else { 4 });
        self.items.push(Toast {
            text: text.into(),
            error,
            until: Instant::now() + stay,
        });
        stay
    }

    /// Drop the expired ones; true if any went.
    pub fn expire(&mut self) -> bool {
        let n = self.items.len();
        let now = Instant::now();
        self.items.retain(|t| t.until > now);
        n != self.items.len()
    }

    /// The stack, or None when empty. `extra` goes above the toasts (notices).
    pub fn render(&self, t: &Theme) -> Option<Div> {
        if self.items.is_empty() {
            return None;
        }
        Some(
            div()
                .absolute()
                .bottom(px(18. + 26.))
                .right(px(18.))
                .max_w(px(420.))
                .flex()
                .flex_col()
                .items_end()
                .gap(px(8.))
                .children(self.items.iter().map(|toast| {
                    let (bg, fg) = if toast.error {
                        (t.danger_bg, gpui::white())
                    } else {
                        (t.ink, t.page)
                    };
                    div()
                        .px(px(14.))
                        .py(px(10.))
                        .rounded(px(9.))
                        .bg(bg)
                        .text_color(fg)
                        .text_size(px(13.5))
                        .shadow_lg()
                        .child(toast.text.clone())
                })),
        )
    }
}
