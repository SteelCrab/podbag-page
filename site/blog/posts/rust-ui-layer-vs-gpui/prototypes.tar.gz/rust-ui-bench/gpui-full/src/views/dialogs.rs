//! The app's dialogs: confirm, ask (one line of text) and choose, and the dispatch
//! to the others (pull panel, import, Kubernetes object).

use gpui::{AnyElement, Context, SharedString, Window, div, prelude::*, px};

use crate::app::*;
use crate::theme::MONO;
use crate::widgets::Button;
use crate::widgets::dialog::{self, Modal as ModalBox};

impl Podbag {
    pub fn render_modal(
        &mut self,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Option<AnyElement> {
        let t = self.theme;
        let dismiss = cx.listener(|this, _, w, cx| this.close_modal(w, cx));
        Some(match self.modal.as_ref()? {
            Modal::Confirm {
                title,
                text,
                yes,
                cancel,
                tone,
                ..
            } => {
                let body = dialog::form(&t)
                    .child(dialog::title(title.clone()))
                    .child(dialog::text(text.clone(), &t))
                    .child(
                        dialog::buttons()
                            .child(
                                Button::new("confirm-cancel", cancel.clone(), &t)
                                    .on_click(cx.listener(|this, _, w, cx| this.answer("", w, cx))),
                            )
                            .child(
                                Button::new("confirm-yes", yes.clone(), &t)
                                    .tone(*tone)
                                    .on_click(
                                        cx.listener(|this, _, w, cx| this.answer("yes", w, cx)),
                                    ),
                            ),
                    );
                ModalBox::new(body, &t)
                    .on_dismiss(dismiss)
                    .into_any_element()
            }
            Modal::Ask {
                title,
                label,
                ok,
                input,
                progress,
                ..
            } => {
                let body = dialog::form(&t)
                    .child(dialog::title(title.clone()))
                    .child(
                        div()
                            .text_size(px(13.))
                            .font_weight(gpui::FontWeight::SEMIBOLD)
                            .child(label.clone()),
                    )
                    .child(
                        div()
                            .h(px(34.))
                            .px(px(10.))
                            .flex()
                            .items_center()
                            .border_1()
                            .border_color(t.accent)
                            .rounded(px(7.))
                            .bg(t.surface)
                            .child(input.clone()),
                    )
                    .child(
                        div()
                            .min_h(px(18.))
                            .font_family(MONO)
                            .text_size(px(12.5))
                            .text_color(t.ink2)
                            .child(progress.clone()),
                    )
                    .child(
                        dialog::buttons()
                            .child(
                                Button::new("ask-cancel", self.t("action.cancel"), &t).on_click(
                                    cx.listener(|this, _, w, cx| this.close_modal(w, cx)),
                                ),
                            )
                            .child(
                                Button::new("ask-ok", ok.clone(), &t)
                                    .primary()
                                    .on_click(cx.listener(|this, _, w, cx| this.submit_ask(w, cx))),
                            ),
                    );
                ModalBox::new(body, &t)
                    .on_dismiss(dismiss)
                    .into_any_element()
            }
            Modal::Choose {
                title,
                text,
                buttons,
                ..
            } => {
                let row = dialog::buttons().children(buttons.iter().enumerate().map(
                    |(i, (value, label, tone))| {
                        let value: SharedString = value.clone();
                        Button::new(("choose", i), label.clone(), &t)
                            .tone(*tone)
                            .on_click(cx.listener(move |this, _, w, cx| this.answer(&value, w, cx)))
                    },
                ));
                let body = dialog::form(&t)
                    .child(dialog::title(title.clone()))
                    .child(dialog::text(text.clone(), &t))
                    .child(row);
                ModalBox::new(body, &t)
                    .on_dismiss(cx.listener(|this, _, w, cx| this.answer("", w, cx)))
                    .into_any_element()
            }
            Modal::KubeObject { .. } => self.render_kube_object(cx),
            Modal::Pull => self.render_pull(window, cx),
            Modal::Import { .. } => self.render_import(window, cx),
        })
    }
}
