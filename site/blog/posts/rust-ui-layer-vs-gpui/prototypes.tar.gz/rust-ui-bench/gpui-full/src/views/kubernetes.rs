//! Kubernetes (kubernetes.js): the context menu, the all-namespaces switch, the
//! resource tabs, a table of the chosen resource, and the object's JSON on click.

use bench_api::serde_json::Value;
use bench_api::{KubeCounts, KubeKind};
use gpui::{
    AnyElement, Context, Entity, Focusable, FontWeight, SharedString, Subscription,
    UniformListScrollHandle, Window, div, prelude::*, px,
};

use crate::app::*;
use crate::views::resources::{content, heading, search_box, toolbar};
use crate::widgets::code::pre;
use crate::widgets::dialog::{self, Modal as ModalBox};
use crate::widgets::select::Select;
use crate::widgets::table::{self, Column};
use crate::widgets::tabs::{Tab, tab_bar};
use crate::widgets::{Button, Checkbox, IconButton, InputEvent, TextInput};

pub struct Kube {
    pub kind: KubeKind,
    pub counts: Option<KubeCounts>,
    pub all: bool,
    /// "" is the current context.
    pub context: String,
    pub contexts: Vec<String>,
    pub expanded: bool,
    pub items: Vec<Value>,
    /// The context and namespace of the loaded list.
    pub list_context: String,
    pub namespace: String,
    pub error: Option<String>,
    pub search: Entity<TextInput>,
    pub query: String,
    /// Rows that match the search: (item index, cells).
    pub rows: Vec<(usize, Vec<String>)>,
    pub scroll: UniformListScrollHandle,
}

impl Kube {
    pub fn new(cx: &mut Context<Podbag>, subs: &mut Vec<Subscription>) -> Self {
        let search = cx.new(|cx| TextInput::new(cx, "Search"));
        subs.push(cx.subscribe(&search, |this, input, e: &InputEvent, cx| {
            if *e == InputEvent::Changed {
                this.kube.query = input.read(cx).content.to_string();
                this.kube_filter();
                cx.notify();
            }
        }));
        Kube {
            kind: KubeKind::Pods,
            counts: None,
            all: false,
            context: String::new(),
            contexts: Vec::new(),
            expanded: false,
            items: Vec::new(),
            list_context: String::new(),
            namespace: String::new(),
            error: None,
            search,
            query: String::new(),
            rows: Vec::new(),
            scroll: UniformListScrollHandle::new(),
        }
    }
}

/// The column keys after Name and Namespace.
fn columns(kind: KubeKind) -> [&'static str; 3] {
    match kind {
        KubeKind::Pods => ["kube.phase", "kube.ready", "kube.node"],
        KubeKind::Services => ["kube.type", "kube.address", "col.ports"],
        KubeKind::Deployments => ["kube.ready", "col.image", ""],
        KubeKind::Claims => ["kube.phase", "kube.capacity", "kube.storageClass"],
    }
}

fn s(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Null => String::new(),
        other => other.to_string(),
    }
}

fn arr(v: &Value) -> &[Value] {
    v.as_array().map(Vec::as_slice).unwrap_or(&[])
}

/// kubernetes.js `kubeCells`.
pub fn cells(kind: KubeKind, item: &Value) -> Vec<String> {
    let (meta, spec, status) = (&item["metadata"], &item["spec"], &item["status"]);
    let mut out = vec![s(&meta["name"]), s(&meta["namespace"])];
    match kind {
        KubeKind::Pods => {
            let sidecars = arr(&spec["initContainers"])
                .iter()
                .filter(|c| c["restartPolicy"] == "Always");
            let containers: Vec<&Value> = arr(&spec["containers"]).iter().chain(sidecars).collect();
            let ready: Vec<String> = arr(&status["containerStatuses"])
                .iter()
                .chain(arr(&status["initContainerStatuses"]))
                .filter(|c| c["ready"] == true)
                .map(|c| s(&c["name"]))
                .collect();
            let count = containers
                .iter()
                .filter(|c| ready.contains(&s(&c["name"])))
                .count();
            out.extend([
                s(&status["phase"]),
                format!("{count}/{}", containers.len()),
                s(&spec["nodeName"]),
            ]);
        }
        KubeKind::Deployments => {
            let images: Vec<String> = arr(&spec["template"]["spec"]["containers"])
                .iter()
                .map(|c| s(&c["image"]))
                .collect();
            let ready = status["readyReplicas"].as_i64().unwrap_or(0);
            let want = spec["replicas"].as_i64().unwrap_or(1);
            out.extend([format!("{ready}/{want}"), images.join(", ")]);
        }
        KubeKind::Claims => out.extend([
            s(&status["phase"]),
            s(&status["capacity"]["storage"]),
            s(&spec["storageClassName"]),
        ]),
        KubeKind::Services => {
            let ports: Vec<String> = arr(&spec["ports"])
                .iter()
                .map(|p| {
                    let node = p["nodePort"]
                        .as_i64()
                        .map(|n| format!(":{n}"))
                        .unwrap_or_default();
                    let proto = p["protocol"].as_str().unwrap_or("TCP");
                    format!("{}{node}/{proto}", s(&p["port"]))
                })
                .collect();
            let ips: Vec<String> = arr(&spec["clusterIPs"]).iter().map(s).collect();
            let address = if let Some(e) = spec["externalName"].as_str() {
                e.to_string()
            } else if !ips.is_empty() {
                ips.join(", ")
            } else {
                s(&spec["clusterIP"])
            };
            out.extend([s(&spec["type"]), address, ports.join(", ")]);
        }
    }
    out
}

impl Podbag {
    /// app.js `refreshKubeCounts`: counts for the sidebar (blank when unknown).
    pub fn refresh_kube_counts(&mut self) {
        let ctx = (!self.kube.context.is_empty()).then_some(self.kube.context.as_str());
        self.kube.counts = self.api.kube_counts(ctx, self.kube.all).ok();
    }

    /// The Refresh button: counts, contexts, the list.
    pub fn kube_reload(&mut self, cx: &mut Context<Self>) {
        self.refresh_kube_counts();
        if let Ok(c) = self.api.kube_contexts() {
            self.kube.contexts = c;
        }
        self.kube_load(cx);
    }

    /// A new resource: clear the search and load.
    pub fn kube_switch(&mut self, cx: &mut Context<Self>) {
        self.kube.search.update(cx, |i, cx| i.set_content("", cx));
        self.kube.query.clear();
        self.kube_load(cx);
    }

    fn kube_load(&mut self, cx: &mut Context<Self>) {
        let ctx = (!self.kube.context.is_empty()).then_some(self.kube.context.as_str());
        match self.api.kube_list(self.kube.kind, self.kube.all, ctx) {
            Ok(list) => {
                self.kube.items = list.items;
                self.kube.list_context = list.context;
                self.kube.namespace = list.namespace;
                self.kube.error = None;
            }
            Err(e) => {
                self.kube.items.clear();
                self.kube.error = Some(if e == "kubectl-missing" {
                    self.tr.t("kube.missing")
                } else {
                    e
                });
            }
        }
        self.kube_filter();
        cx.notify();
    }

    fn kube_filter(&mut self) {
        let q = self.kube.query.trim().to_lowercase();
        let kind = self.kube.kind;
        self.kube.rows = self
            .kube
            .items
            .iter()
            .enumerate()
            .map(|(i, item)| (i, cells(kind, item)))
            .filter(|(_, c)| q.is_empty() || c.iter().any(|v| v.to_lowercase().contains(&q)))
            .collect();
    }

    pub fn inspect_kube(&mut self, ix: usize, cx: &mut Context<Self>) {
        let Some(item) = self.kube.items.get(ix) else {
            return;
        };
        let title: SharedString = format!(
            "{} / {}",
            s(&item["metadata"]["namespace"]),
            s(&item["metadata"]["name"])
        )
        .into();
        let context = self.tv("kube.context", &[("context", &self.kube.list_context)]);
        self.modal = Some(Modal::KubeObject {
            title,
            context,
            json: bench_api::pretty_json(item).into(),
        });
        cx.notify();
    }

    pub fn render_kubernetes(&mut self, window: &mut Window, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let focused = self
            .kube
            .search
            .read(cx)
            .focus_handle(cx)
            .is_focused(window);
        let bar = toolbar(&t)
            .child(heading(self.t("nav.kubernetes")))
            .child(search_box(&self.kube.search, focused, &t))
            .child(
                div().ml_auto().child(
                    IconButton::new("kube-refresh", "refresh", self.t("action.refresh"), &t)
                        .on_click(cx.listener(|this, _, _, cx| this.kube_reload(cx))),
                ),
            );
        let tabs = KubeKind::ALL.map(|kind| {
            Tab::new(
                SharedString::from(format!("kube-{}", kind.as_str())),
                self.t(&format!("kube.{}", kind.as_str())),
                kind == self.kube.kind,
                &t,
            )
            .on_click(cx.listener(move |this, _, w, cx| this.go_kube(kind, w, cx)))
        });
        let all = Checkbox::new("kube-all", self.kube.all, &t)
            .label(self.t("kube.allNamespaces"))
            .on_toggle(cx.listener(|this, on: &bool, _, cx| {
                this.kube.all = *on;
                this.refresh_kube_counts();
                this.kube_load(cx);
            }));
        let tab_row = tab_bar(&t, tabs, Some(all.into_any_element())).flex_wrap();
        let mut select = Select::new(
            "kube-context",
            self.kube.context.clone(),
            self.menu == Some("kube-context"),
            &t,
        )
        .width(260.)
        .option("", self.t("kube.current"));
        let mut names: Vec<String> = self.kube.contexts.clone();
        if !self.kube.context.is_empty() && !names.contains(&self.kube.context) {
            names.push(self.kube.context.clone());
        }
        for n in names {
            select = select.option(n.clone(), n);
        }
        let select = select
            .on_toggle(cx.listener(|this, open: &bool, _, cx| {
                this.menu = open.then_some("kube-context");
                cx.notify();
            }))
            .on_pick(cx.listener(|this, v: &SharedString, _, cx| {
                this.kube.context = v.to_string();
                this.refresh_kube_counts();
                this.kube_load(cx);
            }));
        let cluster = div()
            .flex()
            .items_center()
            .gap(px(10.))
            .mt(px(12.))
            .mx(px(20.))
            .text_size(px(13.))
            .child(self.t("kube.cluster"))
            .child(select);
        let scope = if self.kube.error.is_none() && !self.kube.list_context.is_empty() {
            let ns = if self.kube.all {
                self.tr.t("kube.allNamespaces")
            } else {
                self.kube.namespace.clone()
            };
            Some(
                div()
                    .mt(px(10.))
                    .mx(px(20.))
                    .text_size(px(12.5))
                    .text_color(t.ink2)
                    .child(format!(
                        "{} · {ns}",
                        self.tr
                            .tv("kube.context", &[("context", &self.kube.list_context)])
                    )),
            )
        } else {
            None
        };
        div()
            .flex()
            .flex_col()
            .size_full()
            .child(bar)
            .child(tab_row)
            .child(cluster)
            .children(scope)
            .child(self.kube_content(cx))
            .into_any_element()
    }

    fn kube_content(&mut self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let kind = self.kube.kind;
        if let Some(e) = &self.kube.error {
            return content()
                .child(
                    crate::views::resources::empty_page()
                        .child(
                            div()
                                .text_size(px(18.))
                                .font_weight(FontWeight::BOLD)
                                .child(self.t("kube.error")),
                        )
                        .child(
                            div()
                                .text_color(t.red)
                                .font_family(crate::theme::MONO)
                                .text_size(px(12.5))
                                .child(e.clone()),
                        )
                        .child(
                            div().mt(px(14.)).child(
                                Button::new("kube-retry", self.t("action.retry"), &t)
                                    .icon("refresh")
                                    .on_click(cx.listener(|this, _, _, cx| this.kube_reload(cx))),
                            ),
                        ),
                )
                .into_any_element();
        }
        if self.kube.rows.is_empty() {
            let text = if self.kube.items.is_empty() {
                self.t(&format!("kube.empty.{}", kind.as_str()))
            } else {
                self.tv("empty.search", &[("q", &self.kube.query.trim())])
            };
            return content()
                .child(div().py(px(24.)).px(px(10.)).text_color(t.ink2).child(text))
                .into_any_element();
        }
        let mut cols = vec![
            Column::flex(self.t("col.name")),
            Column::flex(self.t("kube.namespace")),
        ];
        cols.extend(
            columns(kind)
                .iter()
                .filter(|k| !k.is_empty())
                .map(|k| Column::flex(self.t(k))),
        );
        let header = table::header(&cols, None, &t);
        let body = table::body(
            "kube-rows",
            self.kube.rows.len(),
            &self.kube.scroll,
            cx.processor(move |this, range: std::ops::Range<usize>, _, cx| {
                let t = this.theme;
                let mut cols = vec![Column::flex(""), Column::flex("")];
                cols.extend(
                    columns(kind)
                        .iter()
                        .filter(|k| !k.is_empty())
                        .map(|_| Column::flex("")),
                );
                range
                    .map(|r| {
                        let (ix, values) = &this.kube.rows[r];
                        let ix = *ix;
                        let cells = values
                            .iter()
                            .enumerate()
                            .map(|(n, v)| {
                                let text = if v.is_empty() {
                                    "—".to_string()
                                } else {
                                    v.clone()
                                };
                                div()
                                    .truncate()
                                    .when(n == 0, |d| d.font_weight(FontWeight::SEMIBOLD))
                                    .child(text)
                                    .into_any_element()
                            })
                            .collect();
                        table::row(("kube-row", r), &cols, cells, None, 39., &t)
                            .on_click(cx.listener(move |this, _, _, cx| this.inspect_kube(ix, cx)))
                    })
                    .collect::<Vec<_>>()
            }),
        );
        content()
            .min_w(px(510.))
            .child(header)
            .child(body)
            .into_any_element()
    }

    /// kubernetes.js `inspectKubeObject`.
    pub fn render_kube_object(&self, cx: &mut Context<Self>) -> AnyElement {
        let t = self.theme;
        let Some(Modal::KubeObject {
            title,
            context,
            json,
        }) = &self.modal
        else {
            return div().into_any_element();
        };
        let body = dialog::form(&t)
            .child(dialog::title(title.clone()))
            .child(dialog::text(context.clone(), &t))
            .child(pre("kube-json", json.clone(), &t).max_h(px(420.)))
            .child(
                dialog::buttons().child(
                    Button::new("kube-back", self.t("action.back"), &t)
                        .on_click(cx.listener(|this, _, w, cx| this.close_modal(w, cx))),
                ),
            );
        ModalBox::new(body, &t)
            .width(720.)
            .on_dismiss(cx.listener(|this, _, w, cx| this.close_modal(w, cx)))
            .into_any_element()
    }
}
