//! `pre.logs`: a growing list of log lines that wrap, kept at the end while following.
//! Keeps the last 5,000 lines (app.js trims at 6,000).

use std::rc::Rc;

use gpui::{Context, ListAlignment, ListState, SharedString, Window, div, list, prelude::*, px};

use crate::theme::{MONO, Theme};

pub struct LogView {
    lines: Rc<Vec<SharedString>>,
    state: ListState,
    pub follow: bool,
    /// Shown while there are no lines.
    pub empty_text: SharedString,
    pub t: Theme,
}

impl LogView {
    pub fn new(t: Theme) -> Self {
        Self {
            lines: Rc::new(Vec::new()),
            state: ListState::new(0, ListAlignment::Top, px(400.)),
            follow: true,
            empty_text: "".into(),
            t,
        }
    }

    pub fn push(&mut self, new: impl IntoIterator<Item = String>, cx: &mut Context<Self>) {
        let lines = Rc::make_mut(&mut self.lines);
        let old = lines.len();
        lines.extend(new.into_iter().map(SharedString::from));
        if lines.len() > 6000 {
            let cut = lines.len() - 5000;
            lines.drain(..cut);
            self.state.reset(lines.len());
        } else {
            self.state.splice(old..old, lines.len() - old);
        }
        self.scroll_end();
        cx.notify();
    }

    pub fn set_follow(&mut self, on: bool, cx: &mut Context<Self>) {
        self.follow = on;
        self.scroll_end();
        cx.notify();
    }

    fn scroll_end(&self) {
        if self.follow && !self.lines.is_empty() {
            self.state.scroll_to_reveal_item(self.lines.len() - 1);
        }
    }
}

impl Render for LogView {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let t = self.t;
        let lines = self.lines.clone();
        let frame = div()
            .flex_1()
            .min_h_0()
            .flex()
            .flex_col()
            .py(px(12.))
            .px(px(14.))
            .rounded(px(8.))
            .bg(t.surface)
            .border_1()
            .border_color(t.line)
            .font_family(MONO)
            .text_size(px(12.5))
            .line_height(px(19.))
            .text_color(t.ink);
        if lines.is_empty() {
            return frame.child(div().text_color(t.ink2).child(self.empty_text.clone()));
        }
        frame.child(
            list(self.state.clone(), move |ix, _, _| {
                div().w_full().child(lines[ix].clone()).into_any_element()
            })
            .flex_1()
            .size_full(),
        )
    }
}
