//! `.segments`: a radio group drawn as joined segments (the theme choice).

use std::rc::Rc;

use gpui::{App, SharedString, Window, div, prelude::*, px};

use crate::icons::icon;
use crate::theme::Theme;

type Handler = Rc<dyn Fn(&usize, &mut Window, &mut App)>;

#[derive(IntoElement)]
pub struct Segmented {
    id: SharedString,
    /// (icon, label) per option.
    options: Vec<(&'static str, SharedString)>,
    selected: usize,
    t: Theme,
    on_select: Option<Handler>,
}

impl Segmented {
    pub fn new(id: impl Into<SharedString>, selected: usize, t: &Theme) -> Self {
        Self {
            id: id.into(),
            options: Vec::new(),
            selected,
            t: *t,
            on_select: None,
        }
    }

    pub fn option(mut self, icon: &'static str, label: impl Into<SharedString>) -> Self {
        self.options.push((icon, label.into()));
        self
    }

    pub fn on_select(mut self, f: impl Fn(&usize, &mut Window, &mut App) + 'static) -> Self {
        self.on_select = Some(Rc::new(f));
        self
    }
}

impl RenderOnce for Segmented {
    fn render(self, _: &mut Window, _: &mut App) -> impl IntoElement {
        let t = self.t;
        let id = self.id.clone();
        div()
            .id(self.id)
            .flex()
            .flex_wrap()
            .p(px(2.))
            .gap(px(2.))
            .rounded(px(8.))
            .border_1()
            .border_color(t.line)
            .bg(t.sunken)
            .children(
                self.options
                    .into_iter()
                    .enumerate()
                    .map(|(i, (name, label))| {
                        let on = i == self.selected;
                        let f = self.on_select.clone();
                        let fg = if on { t.accent_text } else { t.ink2 };
                        div()
                            .id(SharedString::from(format!("{id}-{i}")))
                            .flex()
                            .flex_auto()
                            .items_center()
                            .justify_center()
                            .gap(px(6.))
                            .px(px(9.))
                            .py(px(4.))
                            .rounded(px(6.))
                            .cursor_pointer()
                            .text_color(fg)
                            .when(on, |d| d.bg(t.surface).shadow_sm())
                            .when(!on, |d| d.hover(move |s| s.bg(t.hover)))
                            .child(icon(name, px(15.), fg))
                            .child(label)
                            .when_some(f, |d, f| d.on_click(move |_, w, cx| f(&i, w, cx)))
                    }),
            )
    }
}
