//! Benchmark prototype: a Podbag-like containers screen in GPUI.
//!
//! Usage: gpui-app [--rows N] [--source synthetic|engine]
//! (`--source engine` needs the `engine` cargo feature: real containers via `podbag::client`.)
//! stdout: `READY <ms since main>`, `RENDER <ms>`, `FILTER <ms> <visible rows>`.
//! stdin commands: `filter <text>`, `quit`.

mod data;
mod input;

use std::io::{BufRead, Write};
use std::sync::OnceLock;
use std::time::Instant;

use futures::StreamExt;
use futures::channel::mpsc;
use gpui::{
    App, Application, Bounds, Context, Entity, Focusable, FontWeight, Hsla, SharedString, Window,
    WindowBounds, WindowOptions, div, prelude::*, px, relative, rgb, size, uniform_list,
};

use data::Row;
use input::TextInput;

static T0: OnceLock<Instant> = OnceLock::new();

const NAV: [&str; 8] = [
    "Containers", "Images", "Volumes", "Networks", "Training", "Kubernetes", "Migrate", "Settings",
];
const COLS: [(&str, f32); 5] = [
    ("Name", 0.22),
    ("Image", 0.30),
    ("State", 0.12),
    ("Ports", 0.22),
    ("Created", 0.14),
];
const ROW_H: f32 = 36.;

fn emit(line: String) {
    let mut out = std::io::stdout().lock();
    let _ = writeln!(out, "{line}");
    let _ = out.flush();
}

fn ms(since: Instant) -> f64 {
    since.elapsed().as_secs_f64() * 1000.0
}

enum Pending {
    FirstFrame(Instant),
    Filter(Instant),
}

struct Bench {
    rows: Vec<Row>,
    visible: Vec<usize>,
    query: String,
    search: Entity<TextInput>,
    nav: usize,
    pending: Option<Pending>,
    filter_started: Option<Instant>,
}

impl Bench {
    fn new(rows: Vec<Row>, cx: &mut Context<Self>) -> Self {
        // The rows are in the UI layer from here on; RENDER counts from this point.
        let start = Instant::now();
        let search = cx.new(|cx| TextInput::new(cx, "Search"));
        cx.observe(&search, |this, search, cx| {
            let q = search.read(cx).content.to_string();
            if q != this.query {
                let start = this.filter_started.take().unwrap_or_else(Instant::now);
                this.apply_filter(q, start, cx);
            }
        })
        .detach();
        Self {
            visible: (0..rows.len()).collect(),
            rows,
            query: String::new(),
            search,
            nav: 0,
            pending: Some(Pending::FirstFrame(start)),
            filter_started: None,
        }
    }

    fn apply_filter(&mut self, q: String, start: Instant, cx: &mut Context<Self>) {
        let needle = q.trim().to_lowercase();
        self.visible = self
            .rows
            .iter()
            .enumerate()
            .filter(|(_, r)| needle.is_empty() || r.hay.contains(&needle))
            .map(|(i, _)| i)
            .collect();
        self.query = q;
        self.pending = Some(Pending::Filter(start));
        cx.notify();
    }

    fn command(&mut self, line: &str, cx: &mut Context<Self>) {
        let line = line.trim();
        if line == "quit" {
            cx.quit();
        } else if let Some(q) = line.strip_prefix("filter ") {
            self.filter_started = Some(Instant::now());
            let q = q.to_string();
            self.search.update(cx, |s, cx| s.set_content(&q, cx));
        }
    }

    fn row(&self, ix: usize) -> impl IntoElement + use<> {
        let r = &self.rows[self.visible[ix]];
        let (state, fg, bg): (&str, Hsla, Hsla) = if r.running {
            ("running", rgb(0x1a7f37).into(), rgb(0xdafbe1).into())
        } else {
            ("exited", rgb(0x57606a).into(), rgb(0xeaeef2).into())
        };
        div()
            .id(ix)
            .flex()
            .flex_row()
            .w_full()
            .items_center()
            .h(px(ROW_H))
            .px(px(12.))
            .border_b_1()
            .border_color(rgb(0xeceef1))
            .hover(|s| s.bg(rgb(0xf3f5f8)))
            .child(cell(COLS[0].1).font_weight(FontWeight::MEDIUM).child(SharedString::from(r.name.clone())))
            .child(cell(COLS[1].1).text_color(rgb(0x57606a)).child(r.image))
            .child(
                cell(COLS[2].1).child(
                    div()
                        .px(px(8.))
                        .py(px(2.))
                        .rounded(px(10.))
                        .text_size(px(12.))
                        .text_color(fg)
                        .bg(bg)
                        .child(state),
                ),
            )
            .child(cell(COLS[3].1).child(SharedString::from(r.ports.clone())))
            .child(cell(COLS[4].1).text_color(rgb(0x57606a)).child(SharedString::from(r.created.clone())))
    }
}

fn cell(w: f32) -> gpui::Div {
    div().w(relative(w)).pr(px(10.)).overflow_hidden().whitespace_nowrap().text_ellipsis()
}

impl Render for Bench {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        if debug_enabled() {
            eprintln!(
                "render at {:.1} ms, {} visible, viewport {:?}",
                ms(*T0.get().unwrap()),
                self.visible.len(),
                window.viewport_size()
            );
        }
        // Report once the frame with this content has been presented: the next frame
        // callback runs at the start of the following frame.
        if let Some(p) = self.pending.take() {
            let visible = self.visible.len();
            window.on_next_frame(move |_, _| match p {
                Pending::FirstFrame(start) => {
                    let render = ms(start);
                    emit(format!("READY {:.1}", ms(*T0.get().unwrap())));
                    emit(format!("RENDER {render:.1}"));
                }
                Pending::Filter(start) => emit(format!("FILTER {:.1} {visible}", ms(start))),
            });
        }

        let sidebar = div()
            .flex()
            .flex_col()
            .w(px(216.))
            .h_full()
            .pt(px(44.))
            .px(px(10.))
            .gap(px(2.))
            .bg(rgb(0xf3f4f6))
            .border_r_1()
            .border_color(rgb(0xe3e5e8))
            .children(NAV.iter().enumerate().map(|(i, label)| {
                let selected = i == self.nav;
                div()
                    .id(("nav", i))
                    .px(px(10.))
                    .py(px(7.))
                    .rounded(px(7.))
                    .when(selected, |d| d.bg(rgb(0xdfe3ea)).font_weight(FontWeight::SEMIBOLD))
                    .hover(|s| s.bg(rgb(0xe8ebf0)))
                    .on_click(cx.listener(move |this, _, _, cx| {
                        this.nav = i;
                        cx.notify();
                    }))
                    .child(*label)
            }));

        let toolbar = div()
            .flex()
            .flex_row()
            .items_center()
            .justify_between()
            .h(px(56.))
            .px(px(16.))
            .border_b_1()
            .border_color(rgb(0xe3e5e8))
            .child(
                div()
                    .flex()
                    .flex_row()
                    .items_baseline()
                    .gap(px(8.))
                    .child(div().text_size(px(18.)).font_weight(FontWeight::SEMIBOLD).child("Containers"))
                    .child(
                        div()
                            .text_color(rgb(0x6e7781))
                            .child(format!("{} of {}", self.visible.len(), self.rows.len())),
                    ),
            )
            .child(
                div()
                    .w(px(260.))
                    .px(px(10.))
                    .py(px(6.))
                    .rounded(px(7.))
                    .border_1()
                    .border_color(rgb(0xd0d7de))
                    .bg(rgb(0xffffff))
                    .child(self.search.clone()),
            );

        let header = div()
            .flex()
            .flex_row()
            .items_center()
            .h(px(32.))
            .px(px(12.))
            .border_b_1()
            .border_color(rgb(0xe3e5e8))
            .text_size(px(12.))
            .font_weight(FontWeight::SEMIBOLD)
            .text_color(rgb(0x6e7781))
            .children(COLS.iter().map(|(label, w)| cell(*w).child(*label)));

        let list = uniform_list(
            "rows",
            self.visible.len(),
            cx.processor(|this, range: std::ops::Range<usize>, _, _| {
                range.map(|ix| this.row(ix)).collect::<Vec<_>>()
            }),
        )
        .flex_1();

        div()
            .flex()
            .flex_row()
            .size_full()
            .bg(rgb(0xffffff))
            .text_color(rgb(0x1f2328))
            .text_size(px(13.))
            .child(sidebar)
            .child(
                div()
                    .flex()
                    .flex_col()
                    .flex_1()
                    .h_full()
                    .child(toolbar)
                    .child(div().flex().flex_col().flex_1().px(px(8.)).child(header).child(list)),
            )
    }
}

/// GPUI logs through the `log` crate; with BENCH_LOG set, print its messages to stderr.
struct StderrLog;

impl log::Log for StderrLog {
    fn enabled(&self, _: &log::Metadata) -> bool {
        true
    }
    fn log(&self, record: &log::Record) {
        eprintln!("[{}] {}: {}", record.level(), record.target(), record.args());
    }
    fn flush(&self) {}
}

fn debug_enabled() -> bool {
    std::env::var_os("BENCH_LOG").is_some()
}

fn load_rows(n: usize) -> Vec<Row> {
    let args: Vec<String> = std::env::args().collect();
    let engine = args.windows(2).any(|w| w[0] == "--source" && w[1] == "engine");
    if !engine {
        return data::rows(n);
    }
    #[cfg(feature = "engine")]
    {
        data::from_engine().unwrap_or_else(|e| {
            eprintln!("engine: {e}");
            Vec::new()
        })
    }
    #[cfg(not(feature = "engine"))]
    {
        eprintln!("--source engine needs a build with `--features engine`");
        std::process::exit(2);
    }
}

fn arg_rows() -> usize {
    let args: Vec<String> = std::env::args().collect();
    args.iter()
        .position(|a| a == "--rows")
        .and_then(|i| args.get(i + 1))
        .and_then(|v| v.parse().ok())
        .or_else(|| std::env::var("BENCH_ROWS").ok().and_then(|v| v.parse().ok()))
        .unwrap_or(1000)
}

fn main() {
    T0.set(Instant::now()).unwrap();
    if debug_enabled() {
        static LOGGER: StderrLog = StderrLog;
        let _ = log::set_logger(&LOGGER);
        log::set_max_level(log::LevelFilter::Info);
    }
    let n = arg_rows();
    let rows = load_rows(n);

    let (tx, mut rx) = mpsc::unbounded::<String>();
    std::thread::spawn(move || {
        for line in std::io::stdin().lock().lines() {
            let Ok(line) = line else { break };
            if tx.unbounded_send(line).is_err() {
                break;
            }
        }
    });

    Application::new().run(move |cx: &mut App| {
        input::bind_keys(cx);
        let bounds = Bounds::centered(None, size(px(1200.), px(800.)), cx);
        let window = cx
            .open_window(
                WindowOptions {
                    window_bounds: Some(WindowBounds::Windowed(bounds)),
                    titlebar: Some(gpui::TitlebarOptions {
                        title: Some("podbag-bench (GPUI)".into()),
                        ..Default::default()
                    }),
                    ..Default::default()
                },
                |_, cx| cx.new(|cx| Bench::new(rows, cx)),
            )
            .unwrap();
        let view = window.update(cx, |_, _, cx| cx.entity()).unwrap();
        window
            .update(cx, |v, window, cx| {
                // BENCH_NO_FOCUS: same switch as the Tauri app.
                if std::env::var_os("BENCH_NO_FOCUS").is_none() {
                    window.focus(&v.search.focus_handle(cx));
                }
                cx.activate(true);
            })
            .unwrap();
        if debug_enabled() {
            fn tick(window: &mut Window, count: u64, last: Instant) {
                let (count, last) = if last.elapsed().as_secs_f64() >= 1.0 {
                    eprintln!("frames in last second: {count}");
                    (0, Instant::now())
                } else {
                    (count + 1, last)
                };
                window.on_next_frame(move |w, _| tick(w, count, last));
            }
            window
                .update(cx, |_, window, _| tick(window, 0, Instant::now()))
                .unwrap();
        }
        cx.spawn(async move |cx| {
            while let Some(line) = rx.next().await {
                let _ = view.update(cx, |v, cx| v.command(&line, cx));
            }
        })
        .detach();
    });
}
