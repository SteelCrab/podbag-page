//! Deterministic synthetic container rows. The Tauri app has the same generator.

pub struct Row {
    pub name: String,
    pub image: &'static str,
    pub running: bool,
    pub ports: String,
    pub created: String,
    /// Lower-case text of all columns, for the search filter.
    pub hay: String,
}

const PREFIXES: [&str; 5] = ["web", "api", "db", "cache", "worker"];
const IMAGES: [&str; 5] = [
    "docker.io/library/nginx:1.27",
    "ghcr.io/example/api:2.3.1",
    "docker.io/library/postgres:16",
    "docker.io/library/redis:7.4",
    "quay.io/example/worker:0.9",
];
const INNER_PORTS: [u32; 5] = [80, 8080, 5432, 6379, 9000];

pub fn rows(n: usize) -> Vec<Row> {
    (0..n)
        .map(|i| {
            let p = i % 5;
            let running = i % 3 != 0;
            let name = format!("{}-{:05}", PREFIXES[p], i);
            let ports = if running {
                format!("127.0.0.1:{}->{}/tcp", 8000 + i % 1000, INNER_PORTS[p])
            } else {
                String::new()
            };
            let created = match i % 4 {
                0 => format!("{} minutes ago", 1 + i % 59),
                1 => format!("{} hours ago", 1 + i % 23),
                2 => format!("{} days ago", 1 + i % 6),
                _ => format!("{} weeks ago", 1 + i % 4),
            };
            let state = if running { "running" } else { "exited" };
            let hay = format!("{name}\n{}\n{state}\n{ports}\n{created}", IMAGES[p]).to_lowercase();
            Row {
                name,
                image: IMAGES[p],
                running,
                ports,
                created,
                hay,
            }
        })
        .collect()
}

/// Real containers through `podbag::client` (feature `engine`). The list is loaded once,
/// so the image names are leaked to fit the `&'static str` field of the synthetic rows.
#[cfg(feature = "engine")]
pub fn from_engine() -> Result<Vec<Row>, String> {
    use podbag::client::{Client, Endpoint, podbag_program};
    let endpoint = Endpoint::find(&podbag_program())?;
    let client = Client::new(endpoint);
    let list = client.containers().map_err(|e| e.to_string())?;
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);
    Ok(list
        .into_iter()
        .map(|c| {
            let name = c.name().to_string();
            let running = c.running();
            let ports = c.ports_text();
            let created = ago(now - c.created);
            let state = c.state.clone();
            let image: &'static str = Box::leak(c.image.into_boxed_str());
            let hay = format!("{name}\n{image}\n{state}\n{ports}\n{created}").to_lowercase();
            Row {
                name,
                image,
                running,
                ports,
                created,
                hay,
            }
        })
        .collect())
}

#[cfg(feature = "engine")]
fn ago(secs: i64) -> String {
    let secs = secs.max(0);
    match secs {
        0..60 => "less than a minute ago".into(),
        60..3600 => format!("{} minutes ago", secs / 60),
        3600..86400 => format!("{} hours ago", secs / 3600),
        86400..604800 => format!("{} days ago", secs / 86400),
        _ => format!("{} weeks ago", secs / 604800),
    }
}
