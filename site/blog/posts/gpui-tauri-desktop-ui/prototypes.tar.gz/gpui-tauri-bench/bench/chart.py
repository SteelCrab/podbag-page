#!/usr/bin/env python3
"""Draw the per-run dot plot for the blog post from results.json (stdlib only).

    python3 bench/chart.py bench/results.json out.svg [lang]

Two panels: startup to the first full frame, and memory with helper processes.
Open circles are runs, diamonds are medians.
"""

import html
import json
import statistics
import sys

LABELS = {
    "en": {
        "title": "GPUI and Tauri prototypes: per-run results",
        "desc": "Startup time and memory of each warm run at 1,000 and 10,000 rows. Open circles are runs, diamonds are medians.",
        "startup": "Start to first full frame (ms)",
        "memory": "Memory, app and WebKit processes (MiB)",
        "rows": "{n} rows",
        "full": "Tauri · full DOM",
        "virtual": "Tauri · virtual list",
    },
    "ko": {
        "title": "GPUI와 Tauri 프로토타입: 실행별 결과",
        "desc": "행 1,000개와 10,000개에서 실행마다 잰 시작 시간과 메모리입니다. 빈 원은 각 실행, 마름모는 중앙값입니다.",
        "startup": "시작부터 첫 전체 프레임까지 (ms)",
        "memory": "메모리, 앱과 WebKit 프로세스 (MiB)",
        "rows": "행 {n}개",
        "full": "Tauri · 전체 DOM",
        "virtual": "Tauri · 가상 목록",
    },
    "ja": {
        "title": "GPUI と Tauri のプロトタイプ: 実行ごとの結果",
        "desc": "1,000 行と 10,000 行での各実行の起動時間とメモリ。白丸は各実行、ひし形は中央値です。",
        "startup": "起動から最初の完全なフレームまで (ms)",
        "memory": "メモリ、アプリと WebKit のプロセス (MiB)",
        "rows": "{n} 行",
        "full": "Tauri · 全 DOM",
        "virtual": "Tauri · 仮想リスト",
    },
    "zh-CN": {
        "title": "GPUI 与 Tauri 原型：每次运行的结果",
        "desc": "1,000 行和 10,000 行时每次运行的启动时间和内存。空心圆为单次运行，菱形为中位数。",
        "startup": "从启动到第一个完整帧 (ms)",
        "memory": "内存，应用与 WebKit 进程 (MiB)",
        "rows": "{n} 行",
        "full": "Tauri · 完整 DOM",
        "virtual": "Tauri · 虚拟列表",
    },
    "fil": {
        "title": "Mga prototype sa GPUI at Tauri: resulta ng bawat run",
        "desc": "Oras ng pagsisimula at memory ng bawat run sa 1,000 at 10,000 row. Ang bilog ay bawat run, ang diamond ay median.",
        "startup": "Mula simula hanggang unang buong frame (ms)",
        "memory": "Memory, app at mga proseso ng WebKit (MiB)",
        "rows": "{n} row",
        "full": "Tauri · buong DOM",
        "virtual": "Tauri · virtual na listahan",
    },
    "es": {
        "title": "Prototipos en GPUI y Tauri: resultados por ejecución",
        "desc": "Tiempo de inicio y memoria de cada ejecución con 1.000 y 10.000 filas. Los círculos son ejecuciones; los rombos, medianas.",
        "startup": "Del inicio al primer fotograma completo (ms)",
        "memory": "Memoria, app y procesos de WebKit (MiB)",
        "rows": "{n} filas",
        "full": "Tauri · DOM completo",
        "virtual": "Tauri · lista virtual",
    },
    "vi": {
        "title": "Bản mẫu GPUI và Tauri: kết quả từng lần chạy",
        "desc": "Thời gian khởi động và bộ nhớ của mỗi lần chạy với 1.000 và 10.000 hàng. Vòng tròn rỗng là từng lần chạy, hình thoi là trung vị.",
        "startup": "Từ khởi động đến khung hình đầy đủ đầu tiên (ms)",
        "memory": "Bộ nhớ, ứng dụng và tiến trình WebKit (MiB)",
        "rows": "{n} hàng",
        "full": "Tauri · DOM đầy đủ",
        "virtual": "Tauri · danh sách ảo",
    },
}
VARIANTS = [("gpui", "GPUI", "#2f6fdf"), ("tauri-full", "Tauri · full DOM", "#c2410c"),
            ("tauri-virtual", "Tauri · virtual list", "#7c3aed")]
ROWS = [1000, 10000]
SEP = {"es": ".", "vi": "."}


def load(path):
    runs = json.load(open(path))["runs"]
    data = {}
    for r in runs:
        if r.get("cold") or r.get("errors"):
            continue
        key = (r["variant"], r["rows"])
        data.setdefault(key, {"startup": [], "memory": []})
        data[key]["startup"].append(r["startup_ms"])
        app = "gpui-app" if r["variant"] == "gpui" else "tauri-app"
        owned = [p["bytes"] for p in r["memory"]["processes"]
                 if p["name"] == app or p["name"].startswith("com.apple.WebKit.")]
        data[key]["memory"].append(sum(owned) / 1024 / 1024)
    return data


def panel(data, metric, label, top, lang, width=760):
    left, right = 210, 30
    height = 14 + len(ROWS) * (16 + 22 * len(VARIANTS)) + 30
    plot_w = width - left - right
    values = [v for k, d in data.items() if k[1] in ROWS for v in d[metric]]
    vmax = max(values) * 1.08
    step = 100 if metric == "startup" else 50
    ticks = list(range(0, int(vmax) + step, step))
    vmax = ticks[-1]
    x = lambda v: left + plot_w * v / vmax
    out = [f'<text class="h" x="{left}" y="{top + 18}">{html.escape(label)}</text>']
    base = top + 34
    for t in ticks:
        out.append(f'<line class="grid" x1="{x(t):.1f}" x2="{x(t):.1f}" y1="{base}" y2="{base + height - 30}"/>')
        out.append(f'<text class="tick" x="{x(t):.1f}" y="{base + height - 14}" text-anchor="middle">{t}</text>')
    y = base + 14
    for n in ROWS:
        count = f"{n:,}".replace(",", SEP.get(lang, ","))
        out.append(f'<text class="group" x="12" y="{y + 4}">{html.escape(LABELS[lang]["rows"].format(n=count))}</text>')
        y += 8
        for key, name, color in VARIANTS:
            d = data.get((key, n))
            if not d:
                continue
            name = {"gpui": "GPUI", "tauri-full": LABELS[lang]["full"],
                    "tauri-virtual": LABELS[lang]["virtual"]}[key]
            out.append(f'<text class="name" x="{left - 10}" y="{y + 4}" text-anchor="end">{html.escape(name)}</text>')
            for v in d[metric]:
                out.append(f'<circle cx="{x(v):.1f}" cy="{y}" r="4.5" fill="none" stroke="{color}" stroke-width="1.6"/>')
            m = statistics.median(d[metric])
            out.append(f'<path d="M{x(m):.1f} {y - 7} l7 7 l-7 7 l-7 -7 z" fill="{color}"/>')
            y += 22
        y += 8
    return out, base + height


def main():
    src, dst = sys.argv[1], sys.argv[2]
    lang = sys.argv[3] if len(sys.argv) > 3 else "en"
    data = load(src)
    width = 760
    a, end = panel(data, "startup", LABELS[lang]["startup"], 10, lang, width)
    b, end = panel(data, "memory", LABELS[lang]["memory"], end + 10, lang, width)
    t = LABELS[lang]
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{end + 10}" '
           f'viewBox="0 0 {width} {end + 10}" role="img" aria-labelledby="c-title c-desc">',
           f'<title id="c-title">{html.escape(t["title"])}</title><desc id="c-desc">{html.escape(t["desc"])}</desc>',
           "<defs><style>text{font-family:system-ui,-apple-system,'Segoe UI',sans-serif;fill:#172b40}"
           ".h{font-weight:650;font-size:16px}.name{font-size:13px;fill:#3e5366}.group{font-weight:650;font-size:13px}"
           ".tick{font-size:12px;fill:#5b6b7a}.grid{stroke:#d9e1e8;stroke-width:1}</style></defs>",
           f'<rect width="{width}" height="{end + 10}" fill="#ffffff" rx="8"/>',
           *a, *b, "</svg>"]
    open(dst, "w").write("\n".join(svg) + "\n")


if __name__ == "__main__":
    main()
