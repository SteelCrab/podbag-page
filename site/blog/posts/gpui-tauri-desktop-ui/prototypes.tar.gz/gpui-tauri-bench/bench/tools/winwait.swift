// Waits until a normal (layer 0) window owned by the given pid is on screen.
// Usage: winwait <pid> [timeout_s]. Prints "WINDOW <ms since start>" or "TIMEOUT".
import CoreGraphics
import Foundation

let args = CommandLine.arguments
guard args.count >= 2, let pid = Int(args[1]) else {
    print("usage: winwait <pid> [timeout_s]")
    exit(2)
}
let timeout = args.count >= 3 ? Double(args[2]) ?? 30 : 30
let start = Date()
while Date().timeIntervalSince(start) < timeout {
    let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly], kCGNullWindowID) as? [[String: Any]] ?? []
    for w in list {
        guard let owner = w[kCGWindowOwnerPID as String] as? Int, owner == pid,
              let layer = w[kCGWindowLayer as String] as? Int, layer == 0 else { continue }
        print(String(format: "WINDOW %.1f", Date().timeIntervalSince(start) * 1000))
        exit(0)
    }
    usleep(5000)
}
print("TIMEOUT")
exit(1)
