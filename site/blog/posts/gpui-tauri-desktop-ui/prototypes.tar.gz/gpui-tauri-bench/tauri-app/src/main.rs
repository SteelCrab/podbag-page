//! Benchmark prototype: a Podbag-like containers screen in Tauri 2 (system WebView).
//!
//! Usage: tauri-app [--rows N] [--mode full|virtual]
//! stdout: `READY <ms since main>`, `RENDER <ms>`, `DATA <ms>`, `FILTER <ms> <visible rows>`.
//! stdin commands: `filter <text>`, `quit`.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#[allow(dead_code)]
mod data;

use std::io::{BufRead, Write};
use std::sync::OnceLock;
use std::time::Instant;

use serde::{Deserialize, Serialize};
use tauri::Manager;

static T0: OnceLock<Instant> = OnceLock::new();

struct Config {
    rows: usize,
    mode: String,
    focus: bool,
}

#[derive(Serialize)]
struct RowOut {
    name: String,
    image: &'static str,
    state: &'static str,
    ports: String,
    created: String,
}

fn emit(line: String) {
    let mut out = std::io::stdout().lock();
    let _ = writeln!(out, "{line}");
    let _ = out.flush();
}

#[tauri::command]
fn config(cfg: tauri::State<'_, Config>) -> serde_json::Value {
    serde_json::json!({ "rows": cfg.rows, "mode": cfg.mode, "focus": cfg.focus })
}

/// The rows as JSON, the way Podbag Desktop gets its lists from Rust.
#[tauri::command]
fn rows(cfg: tauri::State<'_, Config>) -> Vec<RowOut> {
    data::rows(cfg.rows)
        .into_iter()
        .map(|r| RowOut {
            name: r.name,
            image: r.image,
            state: if r.running { "running" } else { "exited" },
            ports: r.ports,
            created: r.created,
        })
        .collect()
}

#[derive(Deserialize)]
struct Report {
    kind: String,
    ms: f64,
    #[serde(default)]
    data_ms: f64,
    #[serde(default)]
    visible: usize,
    #[serde(default)]
    viewport: String,
}

#[tauri::command]
fn report(r: Report) {
    match r.kind.as_str() {
        "ready" => {
            let t0 = T0.get().unwrap();
            emit(format!("READY {:.1}", t0.elapsed().as_secs_f64() * 1000.0));
            emit(format!("RENDER {:.1}", r.ms));
            emit(format!("DATA {:.1}", r.data_ms));
            emit(format!("VIEWPORT {}", r.viewport));
        }
        "filter" => emit(format!("FILTER {:.1} {}", r.ms, r.visible)),
        other => emit(format!("UNKNOWN {other}")),
    }
}

fn arg(name: &str) -> Option<String> {
    let args: Vec<String> = std::env::args().collect();
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).cloned()
}

fn main() {
    T0.set(Instant::now()).unwrap();
    let n_rows = arg("--rows")
        .or_else(|| std::env::var("BENCH_ROWS").ok())
        .and_then(|v| v.parse().ok())
        .unwrap_or(1000);
    let mode = arg("--mode").unwrap_or_else(|| "full".into());

    tauri::Builder::default()
        .manage(Config { rows: n_rows, mode, focus: std::env::var_os("BENCH_NO_FOCUS").is_none() })
        .invoke_handler(tauri::generate_handler![config, rows, report])
        .setup(|app| {
            // Bring the window to the front, like the GPUI app does (cx.activate).
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.set_focus();
            }
            let handle = app.handle().clone();
            std::thread::spawn(move || {
                for line in std::io::stdin().lock().lines() {
                    let Ok(line) = line else { break };
                    let line = line.trim().to_string();
                    if line == "quit" {
                        handle.exit(0);
                        break;
                    } else if let Some(q) = line.strip_prefix("filter ") {
                        if let Some(w) = handle.get_webview_window("main") {
                            let q = serde_json::to_string(q).unwrap();
                            let _ = w.eval(format!("window.__bench.filter({q})"));
                        }
                    }
                }
            });
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
