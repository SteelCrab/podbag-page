"use strict";
// Benchmark prototype: Podbag-like containers screen, DOM built the way Podbag Desktop does.
// Mode "full": all rows into one <table> (Podbag today). Mode "virtual": only visible rows.

const { invoke } = window.__TAURI__.core;

const NAV = ["Containers", "Images", "Volumes", "Networks", "Training", "Kubernetes", "Migrate", "Settings"];
const COLS = [["Name", "name"], ["Image", "image"], ["State", "state"], ["Ports", "ports"], ["Created", "created"]];
const ROW_H = 36;
const OVERSCAN = 8;

const S = { all: [], rows: [], mode: "full", nav: 0, filterStart: null, scroller: null, sizer: null, slice: null };

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "text") el.textContent = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function afterPaint(fn) {
  requestAnimationFrame(() => requestAnimationFrame(fn));
}

function renderSidebar() {
  const nav = document.getElementById("sidebar");
  nav.replaceChildren(...NAV.map((label, i) =>
    h("button", { type: "button", class: i === S.nav ? "nav active" : "nav", text: label,
      onclick: () => { S.nav = i; renderSidebar(); } })));
}

function cells(o) {
  return [
    h("td", { class: "col-name", text: o.name }),
    h("td", { class: "col-image", text: o.image }),
    h("td", { class: "col-state" }, h("span", { class: `chip ${o.state}`, text: o.state })),
    h("td", { class: "col-ports", text: o.ports }),
    h("td", { class: "col-created", text: o.created }),
  ];
}

function rowEl(o) {
  return h("tr", { class: "row" }, cells(o));
}

function head() {
  return h("thead", {}, h("tr", {}, COLS.map(([label, c]) => h("th", { class: `col-${c}`, scope: "col", text: label }))));
}

function renderCount() {
  document.getElementById("count").textContent = `${S.rows.length} of ${S.all.length}`;
}

// Podbag style: rebuild the whole table on every change.
function renderFull() {
  const content = document.getElementById("content");
  const table = h("table", { class: "list full" }, head(), h("tbody", {}, S.rows.map(rowEl)));
  content.replaceChildren(h("div", { class: "scroller" }, table));
}

function renderVirtualSlice() {
  const top = S.scroller.scrollTop;
  const height = S.scroller.clientHeight;
  const start = Math.max(0, Math.floor(top / ROW_H) - OVERSCAN);
  const end = Math.min(S.rows.length, Math.ceil((top + height) / ROW_H) + OVERSCAN);
  if (S.slice && S.slice[0] === start && S.slice[1] === end && S.slice[2] === S.rows) return;
  S.slice = [start, end, S.rows];
  const table = h("table", { class: "list", style: `top:${start * ROW_H}px` },
    h("tbody", {}, S.rows.slice(start, end).map(rowEl)));
  S.sizer.replaceChildren(table);
}

function renderVirtual() {
  if (!S.scroller) {
    const content = document.getElementById("content");
    S.sizer = h("div", { class: "sizer" });
    S.scroller = h("div", { class: "scroller" }, S.sizer);
    let queued = false;
    S.scroller.addEventListener("scroll", () => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; renderVirtualSlice(); });
    });
    content.replaceChildren(h("table", { class: "list" }, head()), S.scroller);
  }
  S.sizer.style.height = `${S.rows.length * ROW_H}px`;
  S.scroller.scrollTop = 0;
  S.slice = null;
  renderVirtualSlice();
}

function renderList() {
  renderCount();
  if (S.mode === "virtual") renderVirtual();
  else renderFull();
}

function onSearch(e) {
  const start = S.filterStart ?? performance.now();
  S.filterStart = null;
  const q = e.target.value.trim().toLowerCase();
  S.rows = q ? S.all.filter((o) => o.hay.includes(q)) : S.all;
  renderList();
  const visible = S.rows.length;
  afterPaint(() => invoke("report", { r: { kind: "filter", ms: performance.now() - start, visible } }));
}

window.__bench = {
  filter(q) {
    const input = document.getElementById("search");
    S.filterStart = performance.now();
    input.value = q;
    input.dispatchEvent(new Event("input"));
  },
};

async function main() {
  renderSidebar();
  const search = document.getElementById("search");
  search.addEventListener("input", onSearch);
  const cfg = await invoke("config");
  // BENCH_NO_FOCUS: no blinking caret, to compare idle CPU without it.
  if (cfg.focus) search.focus();
  S.mode = cfg.mode;
  const dataStart = performance.now();
  const all = await invoke("rows");
  for (const o of all) o.hay = `${o.name}\n${o.image}\n${o.state}\n${o.ports}\n${o.created}`.toLowerCase();
  // The rows are in the UI layer from here on; RENDER counts from this point.
  const start = performance.now();
  const dataMs = start - dataStart;
  S.all = all;
  S.rows = all;
  renderList();
  afterPaint(() => invoke("report", { r: { kind: "ready", ms: performance.now() - start, data_ms: dataMs, viewport: `${innerWidth}x${innerHeight}` } }));
}

main();
